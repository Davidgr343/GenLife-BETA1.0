# made by me ig andd comments made by me 
import pygame as pg
import random


pg.init()
#variables
width, height = 800, 600
screen = pg.display.set_mode((width, height))
pg.display.set_caption("My Pygame Window")

background_color = (255, 255, 255)
wall_color = (80, 80, 80)
wall_thickness = 12
gravity = 1200
bounce = 0.8
clock = pg.time.Clock()
font = pg.font.SysFont(None, 28)
magic_font = pg.font.SysFont("comicsansms", 22, italic=True)

circle_image = pg.image.load("circle.png").convert_alpha()
circle_image = pg.transform.scale(circle_image, (100, 100))
radius = circle_image.get_width() / 2
circles = []

left_wall = pg.Rect(0, 0, wall_thickness, height)
right_wall = pg.Rect(width - wall_thickness, 0, wall_thickness, height)
ground = pg.Rect(0, height - wall_thickness, width, wall_thickness)
#loop
running = True
while running:
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
        elif event.type == pg.KEYDOWN and event.key == pg.K_SPACE:
            x = random.randint(wall_thickness + int(radius), width - wall_thickness - int(radius))
            y = wall_thickness + int(radius)
            circles.append({
                "x": float(x),
                "y": float(y),
                "vx": random.uniform(-180, 180),
                "vy": 0.0,
            })
        elif event.type == pg.MOUSEBUTTONDOWN and event.button == 1:
            mouse_x, mouse_y = event.pos
            for circle in reversed(circles):
                dx = mouse_x - circle["x"]
                dy = mouse_y - circle["y"]
                if dx * dx + dy * dy <= radius * radius:
                    circles.remove(circle)
                    break

    delta_time = clock.tick(60) / 1000

    for circle in circles:
        circle["vy"] += gravity * delta_time
        circle["x"] += circle["vx"] * delta_time
        circle["y"] += circle["vy"] * delta_time

        if circle["x"] - radius < left_wall.right:
            circle["x"] = left_wall.right + radius
            circle["vx"] = abs(circle["vx"]) * bounce
        elif circle["x"] + radius > right_wall.left:
            circle["x"] = right_wall.left - radius
            circle["vx"] = -abs(circle["vx"]) * bounce

        if circle["y"] + radius > ground.top:
            circle["y"] = ground.top - radius
            circle["vy"] = -abs(circle["vy"]) * bounce

    for index, circle in enumerate(circles):
        for other in circles[index + 1:]:
            dx = other["x"] - circle["x"]
            dy = other["y"] - circle["y"]
            distance = (dx * dx + dy * dy) ** 0.5
            overlap = radius * 2 - distance

            if overlap > 0:
                if distance == 0:
                    nx, ny = 1.0, 0.0
                else:
                    nx, ny = dx / distance, dy / distance

                circle["x"] -= nx * overlap / 2
                circle["y"] -= ny * overlap / 2
                other["x"] += nx * overlap / 2
                other["y"] += ny * overlap / 2

                speed = (other["vx"] - circle["vx"]) * nx + (other["vy"] - circle["vy"]) * ny
                if speed < 0:
                    impulse = -(1 + bounce) * speed / 2
                    circle["vx"] -= impulse * nx
                    circle["vy"] -= impulse * ny
                    other["vx"] += impulse * nx
                    other["vy"] += impulse * ny

    screen.fill(background_color)
    pg.draw.rect(screen, wall_color, left_wall)
    pg.draw.rect(screen, wall_color, right_wall)
    pg.draw.rect(screen, wall_color, ground)

    for circle in circles:
        rect = circle_image.get_rect(center=(round(circle["x"]), round(circle["y"])))
        screen.blit(circle_image, rect)

    count_text = font.render(f"circles: {len(circles)}", True, (0, 0, 0))
    screen.blit(count_text, (wall_thickness + 8, 8))
    magic_text = magic_font.render(
        "if you left click a circle it dissapears into magic", True, (0, 0, 0)
    )
    screen.blit(magic_text, (wall_thickness + 8, 38))

    pg.display.flip()


pg.quit()