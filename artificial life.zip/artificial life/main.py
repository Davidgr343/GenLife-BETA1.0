"""A small artificial-life sandbox with a self-learning neural-network brain."""

from __future__ import annotations

import math
import json
import random
from dataclasses import dataclass, fields
from pathlib import Path

import pygame


WINDOW_SIZE = (1100, 720)
SIDEBAR_WIDTH = 270
SEGMENT_SIZE = 14
SEGMENT_GAP = 16
MAX_WORMS = 8
MAX_INSECTS = 100
MAX_PREDATORS = 12
HUNGRY_THRESHOLD = 25
HUMAN_WORLD_SIZE = (6400, 4800)
BIOME_MAP_SCALE = 2.0
MAX_HUMANS = 32
MAX_TERRITORIES_PER_PERSON = 2
MAX_TERRITORY_RADIUS = 400
SAVE_VERSION = 2
SAVE_PATH = Path(__file__).with_name("artificial_life_save.json")

WHITE = (255, 255, 255)
INK = (38, 48, 57)
MUTED = (112, 124, 132)
GREEN = (61, 164, 103)
PALE_GREEN = (224, 243, 230)
RED = (222, 91, 83)
PALE_RED = (252, 231, 228)
GOLD = (235, 174, 62)
PANEL = (247, 249, 250)
LINE = (224, 230, 233)
ACTION_NAMES = (
    "Explore",
    "Turn left",
    "Turn right",
    "Seek food",
    "Flee danger",
    "Seek companion",
    "Rest",
)
HUMAN_ACTION_NAMES = (
    "Explore",
    "Turn left",
    "Turn right",
    "Forage",
    "Gather wood",
    "Gather stone",
    "Bond",
    "Claim land",
    "Fight rival",
    "Flee",
    "Rest",
    "Hunt animal",
    "Threaten predator",
    "Fight predator",
    "Build home",
    "Upgrade home",
    "Fortify",
    "Love",
    "Have child",
    "Raid land",
    "Farm",
    "Craft",
    "Work",
    "Return home",
    "Produce electronics",
    "Start company",
    "Mine ore",
    "Mine gold",
    "Mine silicon",
    "Reject advance",
    "Build",
    "Celebrate",
    "Mourn",
    "Rob",
    "Brawl",
    "Join gang",
    "Form gang",
    "Extort",
    "Craft weapon",
    "Build vehicle",
    "Build power line",
    "Expand territory",
)
BUILDING_COSTS: dict[str, dict[str, int]] = {
    "farm": {"wood": 4, "stone": 1},
    "barn": {"wood": 10, "stone": 6},
    "craft table": {"wood": 5, "stone": 2},
    "workshop": {"wood": 8, "stone": 6},
    "heater": {"wood": 3, "stone": 2},
    "sofa": {"wood": 4},
    "lamp": {"wood": 2, "ore": 1},
    "torch": {"wood": 1},
    "clinic": {"wood": 7, "stone": 4},
    "market": {"wood": 7, "stone": 5},
    "electronics lab": {"wood": 8, "stone": 8, "gold": 3},
    "factory": {"wood": 12, "stone": 12, "electronics": 4},
    "company": {"wood": 8, "stone": 4, "gold": 4, "electronics": 3},
    "bank": {"wood": 10, "stone": 8, "gold": 5},
    "cemetery": {"wood": 4, "stone": 6},
    "cottage": {"wood": 5, "stone": 2},
    "cabin": {"wood": 6, "stone": 1},
    "townhouse": {"wood": 8, "stone": 5},
    "manor": {"wood": 14, "stone": 12},
    "villa": {"wood": 12, "stone": 8, "gold": 2},
    "farmhouse": {"wood": 8, "stone": 4},
    "longhouse": {"wood": 10, "stone": 5},
    "garage": {"wood": 9, "stone": 5},
    "armory": {"wood": 7, "stone": 7, "ore": 3},
    "vehicle workshop": {"wood": 10, "stone": 8, "ore": 4},
    "weaponsmith": {"wood": 6, "stone": 5, "ore": 4},
    "stable": {"wood": 8, "stone": 2},
    "depot": {"wood": 9, "stone": 5},
    "restaurant": {"wood": 7, "stone": 4},
    "university": {"wood": 12, "stone": 10},
    "hotel": {"wood": 10, "stone": 6},
    "radio station": {"wood": 10, "stone": 7, "gold": 2},
    "observatory": {"wood": 8, "stone": 12, "silicon": 2},
    "museum": {"wood": 9, "stone": 8},
    "rail station": {"wood": 11, "stone": 10, "ore": 3},
    "harbor": {"wood": 10, "stone": 8},
    "monument": {"wood": 5, "stone": 12},
    "town center": {"wood": 12, "stone": 12},
    "windmill": {"wood": 10, "stone": 5},
    "pharmacy": {"wood": 7, "stone": 5},
    "firehouse": {"wood": 8, "stone": 6},
    "power station": {"wood": 14, "stone": 16, "ore": 6},
    "wind turbine": {"wood": 8, "stone": 4, "ore": 2},
    "power line": {"wood": 2, "ore": 1},
    "substation": {"wood": 8, "stone": 8, "ore": 3},
    "solar farm": {"wood": 10, "stone": 6, "silicon": 2},
    "wind farm": {"wood": 9, "stone": 7, "ore": 2},
    "server farm": {"wood": 14, "stone": 10, "silicon": 5},
    "data center": {"wood": 16, "stone": 12, "silicon": 8},
    "cloud company": {"wood": 12, "stone": 8, "electronics": 4},
    "black market": {"wood": 10, "stone": 8, "gold": 6, "electronics": 2, "compute": 8},
    "delivery depot": {"wood": 8, "stone": 5},
    "distribution center": {"wood": 12, "stone": 8},
    "freight yard": {"wood": 10, "stone": 7, "ore": 2},
    "electric workshop": {"wood": 9, "stone": 6, "ore": 2},
    "water treatment": {"wood": 10, "stone": 12},
    "sewage plant": {"wood": 10, "stone": 12},
    "communications tower": {"wood": 7, "stone": 8, "ore": 2},
    "broadcast studio": {"wood": 9, "stone": 6, "electronics": 2},
    "repair shop": {"wood": 8, "stone": 5, "ore": 2},
    "recycling center": {"wood": 10, "stone": 7},
    "cold storage": {"wood": 9, "stone": 7, "ore": 2},
    "greenhouse": {"wood": 8, "stone": 4},
    "fishery": {"wood": 8, "stone": 3},
    "sawmill": {"wood": 10, "stone": 6},
    "brickworks": {"wood": 8, "stone": 9},
    "steel mill": {"wood": 12, "stone": 12, "ore": 6},
    "cement works": {"wood": 9, "stone": 12},
    "textile mill": {"wood": 10, "stone": 7},
    "tailor": {"wood": 6, "stone": 3},
    "hospital": {"wood": 14, "stone": 14, "gold": 3},
    "medical center": {"wood": 12, "stone": 10, "gold": 2},
    "post office": {"wood": 7, "stone": 4},
    "courier hub": {"wood": 8, "stone": 5},
    "bus station": {"wood": 10, "stone": 8, "ore": 2},
    "parking garage": {"wood": 12, "stone": 12},
    "airfield": {"wood": 16, "stone": 10, "ore": 6},
    "shipyard": {"wood": 15, "stone": 12, "ore": 5},
    "logistics center": {"wood": 12, "stone": 8},
    "battery plant": {"wood": 12, "stone": 10, "silicon": 4},
}
BUILDING_TYPES = (
    "farm", "orchard", "ranch", "bakery", "butcher", "mill", "well",
    "granary", "kitchen", "market", "shop", "inn", "clinic", "school",
    "library", "nursery", "theater", "park", "temple", "town hall",
    "courthouse", "police station", "fire station", "barracks", "workshop",
    "smithy", "mine", "lumberyard", "quarry", "warehouse", "research lab",
    "factory", "apartment", "house", "bridge", "power plant", "bank",
    "cemetery", "cottage", "cabin", "townhouse", "manor", "villa",
    "farmhouse", "longhouse", "garage", "armory", "vehicle workshop", "weaponsmith",
    "stable", "depot", "restaurant", "university", "hotel",
    "radio station", "observatory", "museum", "rail station", "harbor",
    "monument", "town center", "windmill", "pharmacy", "firehouse",
    "power station", "power line", "substation", "solar farm", "wind farm",
    "server farm", "data center", "cloud company", "delivery depot",
    "distribution center", "freight yard", "electric workshop",
    "water treatment", "sewage plant", "communications tower",
    "broadcast studio", "repair shop", "recycling center", "cold storage",
    "greenhouse", "fishery", "sawmill", "brickworks", "steel mill",
    "cement works", "textile mill", "tailor", "hospital", "post office",
    "courier hub", "bus station", "parking garage", "airfield", "shipyard",
    "logistics center", "battery plant",
)
_EARLY_BUILDING_LEVEL_NAMES = (
    "Small", "Village", "Town", "City", "Regional", "Grand", "Modern",
    "Advanced", "Industrial", "Civic", "Riverside", "Highland", "Solar",
    "Stone", "Metropolitan",
)
BUILDING_LEVEL_NAMES = (
    *_EARLY_BUILDING_LEVEL_NAMES,
    *(f"Era {tier}" for tier in range(len(_EARLY_BUILDING_LEVEL_NAMES) + 1, 101)),
)
BUILDING_CATALOG: dict[str, tuple[str, int]] = {
    f"{level} {building.title()}": (building, tier)
    for building in BUILDING_TYPES
    for tier, level in enumerate(BUILDING_LEVEL_NAMES, 1)
}
JOB_FAMILIES = (
    ("Black Market Broker", "data center"),
    ("Farmer", "farm"), ("Orchardist", "orchard"), ("Rancher", "ranch"),
    ("Baker", "bakery"), ("Butcher", "butcher"), ("Miller", "mill"),
    ("Well Keeper", "well"), ("Cook", "kitchen"), ("Merchant", "market"),
    ("Innkeeper", "inn"), ("Medic", "clinic"), ("Teacher", "school"),
    ("Librarian", "library"), ("Caretaker", "nursery"), ("Actor", "theater"),
    ("Gardener", "park"), ("Artisan", "workshop"), ("Blacksmith", "smithy"),
    ("Miner", "mine"), ("Lumberjack", "lumberyard"), ("Quarry Worker", "quarry"),
    ("Researcher", "research lab"), ("Engineer", "factory"),
    ("Power Technician", "power plant"), ("Civic Planner", "town hall"),
    ("Granary Keeper", "granary"), ("Shopkeeper", "shop"),
    ("Temple Keeper", "temple"), ("Judge", "courthouse"),
    ("Guard", "police station"), ("Firefighter", "fire station"),
    ("Soldier", "barracks"), ("Storekeeper", "warehouse"),
    ("Caretaker", "apartment"), ("Homekeeper", "house"),
    ("Bridge Engineer", "bridge"),
    ("Banker", "bank"), ("Security Guard", "bank"),
    ("Funeral Director", "cemetery"),
    ("Carpenter", "house"), ("Builder", "workshop"),
    ("Mechanic", "garage"), ("Vehicle Engineer", "vehicle workshop"),
    ("Armorer", "weaponsmith"), ("Stable Keeper", "stable"),
    ("Courier", "depot"), ("Chef", "restaurant"),
    ("Professor", "university"), ("Hotelier", "hotel"),
    ("Broadcaster", "radio station"), ("Astronomer", "observatory"),
    ("Curator", "museum"), ("Station Manager", "rail station"),
    ("Harbor Master", "harbor"), ("Monument Keeper", "monument"),
    ("Town Planner", "town center"), ("Mill Operator", "windmill"),
    ("Pharmacist", "pharmacy"), ("Fire Chief", "firehouse"),
    ("Electrician", "power station"), ("Line Engineer", "power line"),
    ("Grid Technician", "substation"), ("Solar Engineer", "solar farm"),
    ("Wind Turbine Technician", "wind farm"), ("Server Engineer", "server farm"),
    ("Network Administrator", "data center"), ("Cloud Developer", "cloud company"),
    ("Delivery Driver", "delivery depot"), ("Logistics Manager", "distribution center"),
    ("Freight Handler", "freight yard"), ("Electrical Mechanic", "electric workshop"),
    ("Water Engineer", "water treatment"), ("Sanitation Worker", "sewage plant"),
    ("Telecom Engineer", "communications tower"), ("Broadcaster", "broadcast studio"),
    ("Repair Technician", "repair shop"), ("Recycling Worker", "recycling center"),
    ("Cold Chain Operator", "cold storage"), ("Greenhouse Grower", "greenhouse"),
    ("Fisher", "fishery"), ("Sawmill Operator", "sawmill"),
    ("Brickmaker", "brickworks"), ("Steelworker", "steel mill"),
    ("Cement Worker", "cement works"), ("Textile Worker", "textile mill"),
    ("Tailor", "tailor"), ("Hospital Medic", "hospital"),
    ("Postal Worker", "post office"), ("Courier", "courier hub"),
    ("Bus Operator", "bus station"), ("Parking Attendant", "parking garage"),
    ("Pilot", "airfield"), ("Shipwright", "shipyard"),
    ("Supply Planner", "logistics center"), ("Battery Engineer", "battery plant"),
    ("Power Plant Operator", "power station"), ("Power Line Installer", "power line"),
    ("Substation Operator", "substation"), ("Solar Panel Installer", "solar farm"),
    ("Wind Farm Operator", "wind farm"), ("Server Technician", "server farm"),
    ("Data Center Operator", "data center"), ("Cloud Systems Engineer", "cloud company"),
    ("Delivery Coordinator", "delivery depot"), ("Distribution Planner", "distribution center"),
    ("Freight Dispatcher", "freight yard"), ("Electrical Assembler", "electric workshop"),
    ("Water Treatment Operator", "water treatment"), ("Sewage Technician", "sewage plant"),
    ("Communications Technician", "communications tower"), ("Studio Technician", "broadcast studio"),
    ("Repair Technician", "repair shop"), ("Recycling Sorter", "recycling center"),
    ("Cold Storage Technician", "cold storage"), ("Greenhouse Worker", "greenhouse"),
    ("Fishery Worker", "fishery"), ("Sawmill Worker", "sawmill"),
    ("Brickmaker", "brickworks"), ("Steelworker", "steel mill"),
    ("Cement Worker", "cement works"), ("Textile Worker", "textile mill"),
    ("Tailor", "tailor"), ("Hospital Medic", "hospital"),
    ("Postal Worker", "post office"), ("Courier", "courier hub"),
    ("Bus Operator", "bus station"), ("Parking Attendant", "parking garage"),
    ("Pilot", "airfield"), ("Shipwright", "shipyard"),
    ("Logistics Analyst", "logistics center"), ("Battery Technician", "battery plant"),
    ("Forager", "farm"), ("Builder", "workshop"),
    ("Power Plant Operator", "power station"), ("Power Line Installer", "power line"),
    ("Substation Operator", "substation"), ("Solar Panel Installer", "solar farm"),
    ("Wind Farm Operator", "wind farm"), ("Server Technician", "server farm"),
    ("Data Center Operator", "data center"), ("Cloud Systems Engineer", "cloud company"),
    ("Delivery Coordinator", "delivery depot"), ("Distribution Planner", "distribution center"),
    ("Freight Dispatcher", "freight yard"), ("Electrical Assembler", "electric workshop"),
    ("Water Treatment Operator", "water treatment"), ("Sewage Technician", "sewage plant"),
    ("Communications Technician", "communications tower"), ("Studio Technician", "broadcast studio"),
    ("Repair Technician", "repair shop"), ("Recycling Sorter", "recycling center"),
    ("Cold Storage Technician", "cold storage"), ("Greenhouse Worker", "greenhouse"),
    ("Fishery Worker", "fishery"), ("Sawmill Worker", "sawmill"),
    ("Brickmaker", "brickworks"), ("Steelworker", "steel mill"),
    ("Cement Worker", "cement works"), ("Textile Worker", "textile mill"),
    ("Tailor", "tailor"), ("Hospital Medic", "hospital"),
    ("Postal Worker", "post office"), ("Courier", "courier hub"),
    ("Bus Operator", "bus station"), ("Parking Attendant", "parking garage"),
    ("Pilot", "airfield"), ("Shipwright", "shipyard"),
    ("Logistics Analyst", "logistics center"), ("Battery Technician", "battery plant"),
    ("Forager", "farm"), ("Builder", "workshop"),
)
JOB_RANKS = ("Apprentice", "Junior", "Skilled", "Senior", "Master")
JOB_CATALOG = tuple(
    f"{rank} {profession}"
    for profession, _building in JOB_FAMILIES
    for rank in JOB_RANKS
)
GANG_NAMES = (
    "Iron Vipers", "Red Lanterns", "River Syndicate", "Night Owls",
    "Stone Wolves", "Copper Kings", "Ash Street Crew", "Black Pines",
)
BIOME_COLORS = {
    "ocean": (91, 166, 192),
    "coast": (214, 203, 158),
    "plains": (224, 238, 210),
    "forest": (170, 207, 159),
    "desert": (225, 203, 151),
    "mountains": (188, 195, 190),
    "wetlands": (169, 205, 190),
}
CRAFT_COSTS: dict[str, dict[str, int]] = {
    "clothes": {"wood": 2},
    "torch": {"wood": 1},
    "sofa": {"wood": 4},
    "heater": {"wood": 3, "stone": 2},
    "lamp": {"wood": 2, "ore": 1},
    "electronics": {"gold": 2, "silicon": 3, "ore": 1},
    "spear": {"wood": 2, "ore": 1},
    "bow": {"wood": 3},
    "car": {"wood": 8, "ore": 5, "gold": 1},
    "cart": {"wood": 5, "ore": 2},
}
GIRL_COLOR = (232, 113, 165)
BOY_COLOR = (74, 139, 220)
ADULT_AGE = 90.0
LOVE_THRESHOLD = 34.0
HUMAN_HUNGER_RATE = 0.38
DAY_LENGTH = 180.0
HUMAN_SIMULATION_SPEED = 0.85
HUMAN_WORKDAY_LENGTH = 60.0
HUMAN_WORK_SHIFT_LENGTH = 36.0
HUMAN_DECISION_INTERVAL = 1.4
SMALL_CONSTRUCTION_INTERVAL = 60.0
MAJOR_CONSTRUCTION_INTERVAL = 120.0
WAR_INTERVAL = 240.0
WAR_DURATION = 90.0
SMALL_BUILDINGS = ("torch", "sofa", "lamp", "heater")
NIGHT_COLOR = (23, 31, 57)
TERRAIN_TILE_CACHE: dict[tuple[int, int, int], pygame.Surface] = {}
PERSON_NAMES = (
    "Ava", "Mia", "Lena", "Nora", "Zoe", "Iris", "Ruby", "Tess",
    "Leo", "Noah", "Eli", "Milo", "Kai", "Ezra", "Theo", "Jude",
)
PERSON_NICKNAMES = (
    "Sparrow", "Sunny", "Pip", "River", "Scout", "Blue", "Ash", "Fox",
    "Bee", "Wren", "Skye", "Moss", "Comet", "Finch", "Red", "Echo",
)


def human_identity(person_id: int) -> tuple[str, str]:
    index = (person_id - 1) % len(PERSON_NAMES)
    generation = (person_id - 1) // len(PERSON_NAMES)
    suffix = f" {generation + 2}" if generation else ""
    name = f"{PERSON_NAMES[index]}{suffix}"
    nickname = PERSON_NICKNAMES[(person_id - 1) % len(PERSON_NICKNAMES)]
    if generation:
        nickname = f"{nickname} {generation + 2}"
    return name, nickname


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def unit_vector(vector: pygame.Vector2) -> pygame.Vector2:
    if vector.length_squared() < 0.001:
        return pygame.Vector2(1, 0)
    return vector.normalize()


def nearest(
    position: pygame.Vector2,
    things: list[object],
    maximum_distance: float = float("inf"),
) -> tuple[object | None, float]:
    closest = None
    closest_distance = maximum_distance
    for thing in things:
        distance = position.distance_to(thing.pos)  # type: ignore[attr-defined]
        if distance < closest_distance:
            closest = thing
            closest_distance = distance
    return closest, closest_distance


class NeuralBrain:
    """A tiny Q-learning neural network using only Python's standard library."""

    def __init__(
        self,
        input_count: int = 10,
        action_names: tuple[str, ...] = ACTION_NAMES,
    ) -> None:
        self.input_count = input_count
        self.hidden_count = 12
        self.action_names = action_names
        self.output_count = len(action_names)
        self.input_weights = [
            [random.uniform(-0.2, 0.2) for _ in range(self.input_count)]
            for _ in range(self.hidden_count)
        ]
        self.hidden_biases = [0.0] * self.hidden_count
        self.output_weights = [
            [random.uniform(-0.2, 0.2) for _ in range(self.hidden_count)]
            for _ in range(self.output_count)
        ]
        self.output_biases = [0.0] * self.output_count
        self.learning_rate = 0.012
        self.discount = 0.92
        self.exploration = 0.3
        self.learning_steps = 0

    def mutated_copy(self, other_parent: NeuralBrain | None = None) -> NeuralBrain:
        child = NeuralBrain(self.input_count, self.action_names)
        child.input_weights = [
            [
                (
                    other_parent.input_weights[row_index][index]
                    if other_parent is not None and random.random() < 0.5
                    else weight
                ) + random.gauss(0, 0.035)
                for index, weight in enumerate(row)
            ]
            for row_index, row in enumerate(self.input_weights)
        ]
        child.hidden_biases = [
            (
                other_parent.hidden_biases[index]
                if other_parent is not None and random.random() < 0.5
                else value
            ) + random.gauss(0, 0.025)
            for index, value in enumerate(self.hidden_biases)
        ]
        child.output_weights = [
            [
                (
                    other_parent.output_weights[row_index][index]
                    if other_parent is not None and random.random() < 0.5
                    else weight
                ) + random.gauss(0, 0.035)
                for index, weight in enumerate(row)
            ]
            for row_index, row in enumerate(self.output_weights)
        ]
        child.output_biases = [
            (
                other_parent.output_biases[index]
                if other_parent is not None and random.random() < 0.5
                else value
            ) + random.gauss(0, 0.025)
            for index, value in enumerate(self.output_biases)
        ]
        child.exploration = 0.3
        return child

    def values(self, senses: list[float]) -> tuple[list[float], list[float]]:
        hidden = [
            math.tanh(
                sum(weight * sense for weight, sense in zip(weights, senses))
                + bias
            )
            for weights, bias in zip(self.input_weights, self.hidden_biases)
        ]
        outputs = [
            sum(weight * activation for weight, activation in zip(weights, hidden)) + bias
            for weights, bias in zip(self.output_weights, self.output_biases)
        ]
        return hidden, outputs

    def choose(
        self,
        senses: list[float],
        explore: bool = True,
        preferences: list[float] | None = None,
    ) -> int:
        _, values = self.values(senses)
        if preferences is not None:
            values = [value + preference for value, preference in zip(values, preferences)]
        if explore and random.random() < self.exploration:
            return random.randrange(self.output_count)
        return max(range(self.output_count), key=values.__getitem__)

    def learn(
        self,
        senses: list[float],
        action: int,
        reward: float,
        next_senses: list[float],
    ) -> None:
        hidden, values = self.values(senses)
        _, next_values = self.values(next_senses)
        target = reward + self.discount * max(next_values)
        error = clamp(target - values[action], -2.0, 2.0)
        old_output_weights = self.output_weights[action][:]

        for index, activation in enumerate(hidden):
            self.output_weights[action][index] += (
                self.learning_rate * error * activation
            )
        self.output_biases[action] += self.learning_rate * error

        for hidden_index, activation in enumerate(hidden):
            gradient = (
                error
                * old_output_weights[hidden_index]
                * (1 - activation * activation)
            )
            for input_index, sense in enumerate(senses):
                self.input_weights[hidden_index][input_index] += (
                    self.learning_rate * gradient * sense
                )
            self.hidden_biases[hidden_index] += self.learning_rate * gradient

        self.learning_steps += 1
        self.exploration = max(0.08, self.exploration * 0.9997)


@dataclass
class Insect:
    pos: pygame.Vector2
    direction: pygame.Vector2
    turn_timer: float = 0.0
    size: int = 7

    def update(
        self,
        dt: float,
        bounds: pygame.Rect,
        worms: list[Worm],
        predators: list[Predator],
    ) -> None:
        self.turn_timer -= dt
        nearby_threats: list[object] = [
            thing
            for thing in [*worms, *predators]
            if self.pos.distance_to(thing.pos) < 105
        ]
        if nearby_threats:
            threat, _ = nearest(self.pos, nearby_threats)
            if threat is not None:
                self.direction = unit_vector(self.pos - threat.pos)  # type: ignore[attr-defined]
                self.turn_timer = 0.25
        elif self.turn_timer <= 0:
            angle = random.uniform(-1.3, 1.3)
            self.direction = self.direction.rotate_rad(angle)
            self.turn_timer = random.uniform(0.5, 1.8)

        self.pos += self.direction * 48 * dt
        keep_in_bounds(self.pos, bounds, self.size)

    def draw(self, surface: pygame.Surface) -> None:
        x, y = round(self.pos.x), round(self.pos.y)
        pygame.draw.rect(surface, GOLD, (x - 3, y - 3, self.size, self.size))
        pygame.draw.rect(surface, (160, 112, 35), (x - 3, y - 3, self.size, self.size), 1)


@dataclass
class Predator:
    pos: pygame.Vector2
    direction: pygame.Vector2
    turn_timer: float = 0.0
    size: int = 19

    def update(self, dt: float, bounds: pygame.Rect, worms: list[Worm]) -> None:
        target, distance = nearest(self.pos, worms, 230)
        if target is not None:
            desired = unit_vector(target.pos - self.pos)  # type: ignore[attr-defined]
            self.direction = unit_vector(self.direction * 0.35 + desired * 0.65)
        else:
            self.turn_timer -= dt
            if self.turn_timer <= 0:
                self.direction = self.direction.rotate_rad(random.uniform(-1.1, 1.1))
                self.turn_timer = random.uniform(0.6, 1.7)

        speed = 61 if target is not None and distance < 145 else 38
        self.pos += self.direction * speed * dt
        keep_in_bounds(self.pos, bounds, self.size)

    def draw(self, surface: pygame.Surface) -> None:
        x, y = round(self.pos.x), round(self.pos.y)
        points = [(x, y - 11), (x + 11, y), (x, y + 11), (x - 11, y)]
        pygame.draw.polygon(surface, RED, points)
        pygame.draw.polygon(surface, (166, 59, 54), points, 2)


class Worm:
    def __init__(
        self,
        pos: pygame.Vector2,
        color: tuple[int, int, int] = GREEN,
        is_partner: bool = False,
    ) -> None:
        self.pos = pygame.Vector2(pos)
        self.heading = pygame.Vector2(1, 0)
        self.body = [
            self.pos - self.heading * (SEGMENT_GAP * index)
            for index in range(10)
        ]
        self.color = color
        self.is_partner = is_partner
        self.age = 0.0
        self.hunger = 14.0
        self.energy = 100.0
        self.health = 100.0
        self.happiness = 74.0
        self.curiosity = 50.0
        self.fear = 0.0
        self.affection = 0.0
        self.state = "Exploring"
        self.brain = NeuralBrain()
        self.brain_timer = 0.0
        self.brain_state: list[float] | None = None
        self.brain_action = 0
        self.previous_senses: list[float] | None = None
        self.previous_hunger = self.hunger
        self.previous_health = self.health
        self.previous_energy = self.energy
        self.previous_affection = self.affection

    def eat(self) -> None:
        self.hunger = clamp(self.hunger - 38, 0, 100)
        self.energy = clamp(self.energy + 13, 0, 100)
        self.happiness = clamp(self.happiness + 8, 0, 100)
        self.state = "Eating"

    def update(
        self,
        dt: float,
        bounds: pygame.Rect,
        insects: list[Insect],
        predators: list[Predator],
        worms: list[Worm],
    ) -> None:
        self.age += dt
        self.hunger = clamp(self.hunger + 1.8 * dt, 0, 100)
        self.energy = clamp(self.energy - 1.4 * dt, 0, 100)

        predator, predator_distance = nearest(self.pos, predators, 205)
        insect, _ = nearest(self.pos, insects, 250)
        companion = next(
            (worm for worm in worms if worm is not self and worm.is_partner != self.is_partner),
            None,
        )
        companion_distance = (
            self.pos.distance_to(companion.pos) if companion is not None else float("inf")
        )

        def local_sense(target: pygame.Vector2 | None, distance_limit: float) -> tuple[float, float]:
            if target is None:
                return 0.0, 0.0
            offset = target - self.pos
            forward = self.heading
            right = self.heading.rotate(90)
            scale = max(distance_limit, 1)
            return (
                clamp(offset.dot(forward) / scale, -1, 1),
                clamp(offset.dot(right) / scale, -1, 1),
            )

        food_sense = local_sense(insect.pos if insect is not None else None, 250)
        danger_sense = local_sense(predator.pos if predator is not None else None, 205)
        companion_sense = local_sense(
            companion.pos if companion is not None and companion_distance < 300 else None,
            300,
        )
        senses = [
            *food_sense,
            *danger_sense,
            *companion_sense,
            self.hunger / 50 - 1,
            self.energy / 50 - 1,
            self.fear / 50 - 1,
            self.affection / 50 - 1,
        ]

        self.brain_timer -= dt
        if self.brain_timer <= 0:
            if self.brain_state is not None and self.previous_senses is not None:
                reward = (self.previous_hunger - self.hunger) * 0.03
                reward += (self.health - self.previous_health) * 0.05
                reward += (self.energy - self.previous_energy) * 0.008
                reward += (self.affection - self.previous_affection) * 0.01

                old_food_distance = math.hypot(*self.previous_senses[:2])
                new_food_distance = math.hypot(*food_sense)
                if self.hunger > 25 and insect is not None:
                    reward += (old_food_distance - new_food_distance) * 0.22

                old_danger_distance = math.hypot(*self.previous_senses[2:4])
                new_danger_distance = math.hypot(*danger_sense)
                if predator is not None and old_danger_distance > 0.02:
                    reward += (new_danger_distance - old_danger_distance) * 0.5

                old_companion_distance = math.hypot(*self.previous_senses[4:6])
                new_companion_distance = math.hypot(*companion_sense)
                if companion is not None and self.affection > 10:
                    reward += (old_companion_distance - new_companion_distance) * 0.12

                self.brain.learn(
                    self.brain_state,
                    self.brain_action,
                    clamp(reward, -1.5, 1.5),
                    senses,
                )

            self.brain_state = senses[:]
            self.brain_action = self.brain.choose(senses)
            self.previous_senses = senses[:]
            self.previous_hunger = self.hunger
            self.previous_health = self.health
            self.previous_energy = self.energy
            self.previous_affection = self.affection
            self.brain_timer = 0.25

        action = self.brain_action
        action_name = ACTION_NAMES[action]
        if action_name == "Turn left":
            desired = self.heading.rotate(-65)
        elif action_name == "Turn right":
            desired = self.heading.rotate(65)
        elif action_name == "Seek food" and insect is not None:
            desired = unit_vector(insect.pos - self.pos)
        elif action_name == "Flee danger" and predator is not None:
            desired = unit_vector(self.pos - predator.pos)
        elif action_name == "Seek companion" and companion is not None:
            desired = unit_vector(companion.pos - self.pos)
        else:
            desired = self.heading.rotate_rad(math.sin(self.age * 0.8) * 0.12)

        self.state = action_name
        if predator is not None:
            self.fear = clamp(self.fear + 38 * dt, 0, 100)
        else:
            self.fear = clamp(self.fear - 12 * dt, 0, 100)
        if insect is not None:
            self.curiosity = clamp(self.curiosity + 3 * dt, 0, 100)

        if companion is not None and companion_distance < 80 and action_name == "Seek companion":
            self.affection = clamp(self.affection + 4.2 * dt, 0, 100)
            self.happiness = clamp(self.happiness + 1.3 * dt, 0, 100)
            self.state = "Bonding"

        turn_rate = 2.8 * dt
        angle = self.heading.angle_to(desired)
        self.heading = self.heading.rotate(clamp(angle, -math.degrees(turn_rate), math.degrees(turn_rate)))
        speed = 72 * (0.48 + 0.52 * self.energy / 100)
        if action_name == "Flee danger" and predator is not None:
            speed *= 1.3
        if action_name == "Rest":
            speed *= 0.45
            self.energy = clamp(self.energy + 7 * dt, 0, 100)

        self.pos += self.heading * speed * dt
        keep_in_bounds(self.pos, bounds, SEGMENT_SIZE)
        self.body[0] = pygame.Vector2(self.pos)
        for index in range(1, len(self.body)):
            offset = self.body[index - 1] - self.body[index]
            distance = offset.length()
            if distance > SEGMENT_GAP:
                self.body[index] += offset * ((distance - SEGMENT_GAP) / distance)

        for food in insects[:]:
            if self.pos.distance_to(food.pos) < 14:
                insects.remove(food)
                self.eat()
                break

        if predator is not None and predator_distance < 22:
            self.health = clamp(self.health - 13 * dt, 0, 100)
            self.happiness = clamp(self.happiness - 7 * dt, 0, 100)
        elif self.health < 100:
            self.health = clamp(self.health + 1.2 * dt, 0, 100)

        if self.hunger > 86:
            self.health = clamp(self.health - 1.7 * dt, 0, 100)
            self.happiness = clamp(self.happiness - 2 * dt, 0, 100)
        if self.health <= 0:
            self.state = "Needs care"

    def draw(self, surface: pygame.Surface) -> None:
        for index, segment in enumerate(reversed(self.body)):
            shade = max(0.65, 1 - index * 0.035)
            color = tuple(round(channel * shade) for channel in self.color)
            rect = pygame.Rect(0, 0, SEGMENT_SIZE, SEGMENT_SIZE)
            rect.center = (round(segment.x), round(segment.y))
            pygame.draw.rect(surface, color, rect, border_radius=3)
            pygame.draw.rect(surface, (42, 115, 77), rect, 1, border_radius=3)

        eye_offset = self.heading.rotate(45) * 4
        eye = self.pos + eye_offset
        pygame.draw.circle(surface, WHITE, (round(eye.x), round(eye.y)), 2)
        pygame.draw.circle(
            surface,
            INK,
            (round(eye.x + self.heading.x), round(eye.y + self.heading.y)),
            1,
        )
        if self.is_partner:
            pygame.draw.circle(
                surface,
                (229, 130, 157),
                (round(self.pos.x), round(self.pos.y)),
                11,
                1,
            )


@dataclass
class WorldResource:
    pos: pygame.Vector2
    kind: str
    amount: int
    maximum: int
    regrow_timer: float = 0.0


@dataclass
class Territory:
    owner_id: int
    clan_id: int
    pos: pygame.Vector2
    radius: int = 125
    home_level: int = 0
    fortification: int = 0
    durability: float = 100.0
    buildings: dict[str, int] | None = None
    farm_food: float = 0.0
    gang_id: int | None = None
    settlement_level: int = 0
    vault_cash: int = 0
    powered: bool = False
    boundary: list[pygame.Vector2] | None = None
    territory_id: int = 0


@dataclass
class Country:
    clan_id: int
    name: str
    religion: str
    tenet: str
    president_id: int
    founded_at: float
    next_election: float


@dataclass
class ConstructionRequest:
    person_id: int
    country_id: int
    territory_owner_id: int
    building: str
    requested_at: float
    status: str = "pending"


@dataclass
class SocialEvent:
    kind: str
    title: str
    pos: pygame.Vector2
    person_id: int | None
    timer: float
    attendees: set[int] | None = None


@dataclass
class Gang:
    gang_id: int
    name: str
    clan_id: int
    member_ids: set[int]
    cash: int = 0
    reputation: float = 0.0
    cartel: bool = False


@dataclass
class NewsItem:
    world_time: float
    category: str
    text: str


@dataclass
class PowerLine:
    start: pygame.Vector2
    end: pygame.Vector2
    installer_id: int


@dataclass
class Delivery:
    start: pygame.Vector2
    end: pygame.Vector2
    source_owner_id: int
    target_owner_id: int
    courier_id: int
    cargo: str
    amount: int
    progress: float = 0.0


@dataclass
class ClanWar:
    attacker_clan: int
    defender_clan: int
    started_at: float
    ends_at: float
    captures: int = 0


def resize_saved_world(state: dict[str, object]) -> None:
    old_bounds = state.get("world_bounds")
    if not isinstance(old_bounds, pygame.Rect):
        state["world_bounds"] = pygame.Rect(0, 0, *HUMAN_WORLD_SIZE)
        return
    scale_x = HUMAN_WORLD_SIZE[0] / max(old_bounds.width, 1)
    scale_y = HUMAN_WORLD_SIZE[1] / max(old_bounds.height, 1)
    state["world_bounds"] = pygame.Rect(0, 0, *HUMAN_WORLD_SIZE)

    def scale_position(position: object) -> pygame.Vector2 | None:
        if not isinstance(position, pygame.Vector2):
            return None
        return pygame.Vector2(position.x * scale_x, position.y * scale_y)

    def scale_attribute(item: object, name: str) -> None:
        scaled = scale_position(getattr(item, name, None))
        if scaled is not None:
            setattr(item, name, scaled)

    camera = scale_position(state.get("camera"))
    if camera is not None:
        state["camera"] = camera
    for collection_name in (
        "humans", "resources", "territories", "wildlife", "social_events",
        "power_lines", "deliveries",
    ):
        collection = state.get(collection_name)
        if not isinstance(collection, list):
            continue
        for item in collection:
            if isinstance(item, Human):
                scale_attribute(item, "pos")
                item.claim_goal = scale_position(item.claim_goal)
            elif isinstance(item, (WorldResource, Territory, WildAnimal, SocialEvent)):
                scale_attribute(item, "pos")
                if isinstance(item, Territory) and item.boundary:
                    scaled_boundary = []
                    for point in item.boundary:
                        scaled_point = scale_position(point)
                        scaled_boundary.append(
                            scaled_point if scaled_point is not None else point
                        )
                    item.boundary = scaled_boundary
            elif isinstance(item, PowerLine):
                scale_attribute(item, "start")
                scale_attribute(item, "end")
            elif isinstance(item, Delivery):
                scale_attribute(item, "start")
                scale_attribute(item, "end")


def building_costs(building_name: str) -> dict[str, int]:
    if building_name in BUILDING_COSTS:
        return BUILDING_COSTS[building_name]
    building_type, tier = BUILDING_CATALOG[building_name]
    type_index = BUILDING_TYPES.index(building_type)
    costs = {
        "wood": 2 + tier // 3 + type_index % 3,
        "stone": 1 + tier // 4 + type_index % 2,
    }
    if type_index % 4 == 0:
        costs["ore"] = max(1, tier // 4)
    if type_index % 7 == 0:
        costs["gold"] = max(1, tier // 6)
    if building_type in ("research lab", "factory", "power plant") and tier >= 5:
        costs["silicon"] = max(1, tier // 5)
    return costs


def building_category(building_name: str) -> str | None:
    variant = BUILDING_CATALOG.get(building_name)
    if variant:
        return variant[0]
    aliases = {
        "craft table": "workshop",
        "company": "factory",
        "electronics lab": "research lab",
        "heater": "power plant",
        "lamp": "power plant",
        "torch": "power plant",
        "sofa": "inn",
        "cottage": "house",
        "cabin": "house",
        "townhouse": "house",
        "manor": "house",
        "villa": "house",
        "farmhouse": "house",
        "longhouse": "house",
        "barn": "ranch",
        "black market": "data center",
        "wind turbine": "wind farm",
        "medical center": "hospital",
    }
    return aliases.get(building_name, building_name if building_name in BUILDING_TYPES else None)


def territory_contains(territory: Territory, position: pygame.Vector2) -> bool:
    if territory.boundary and len(territory.boundary) >= 3:
        inside = False
        previous = territory.boundary[-1]
        for current in territory.boundary:
            edge_x = current.x - previous.x
            edge_y = current.y - previous.y
            relative_x = position.x - previous.x
            relative_y = position.y - previous.y
            on_edge = (
                abs(relative_x * edge_y - relative_y * edge_x) < 0.001
                and min(previous.x, current.x) - 0.001
                <= position.x
                <= max(previous.x, current.x) + 0.001
                and min(previous.y, current.y) - 0.001
                <= position.y
                <= max(previous.y, current.y) + 0.001
            )
            if on_edge:
                return True
            if (current.y > position.y) != (previous.y > position.y):
                crossing_x = (
                    (previous.x - current.x)
                    * (position.y - current.y)
                    / (previous.y - current.y)
                    + current.x
                )
                if position.x < crossing_x:
                    inside = not inside
            previous = current
        return inside
    return position.distance_to(territory.pos) <= territory.radius


def expand_territory(territory: Territory, amount: int) -> None:
    old_radius = max(territory.radius, 1)
    territory.radius = min(
        MAX_TERRITORY_RADIUS,
        max(60, territory.radius + max(0, amount)),
    )
    if territory.boundary:
        scale = territory.radius / old_radius
        territory.boundary = [
            territory.pos + (point - territory.pos) * scale
            for point in territory.boundary
        ]


def shrink_territory(territory: Territory, amount: int) -> bool:
    new_radius = max(60, territory.radius - max(1, amount))
    if new_radius >= territory.radius:
        return False
    scale = new_radius / max(territory.radius, 1)
    if territory.boundary:
        territory.boundary = [
            territory.pos + (point - territory.pos) * scale
            for point in territory.boundary
        ]
    territory.radius = new_radius
    return True


def generate_country_name(
    territories: list[Territory],
    used_names: set[str],
) -> str:
    biome_counts: dict[str, int] = {}
    for territory in territories:
        biome = biome_at(territory.pos)
        if biome not in ("ocean", "coast"):
            biome_counts[biome] = biome_counts.get(biome, 0) + 1
    roots_by_biome = {
        "forest": ("Alder", "Bracken", "Cedar", "Moss", "Pine"),
        "mountains": ("Stone", "High", "Iron", "Granite", "Frost"),
        "desert": ("Amber", "Sun", "Saffron", "Copper", "Dune"),
        "wetlands": ("Willow", "Reed", "Mire", "Fen", "Rain"),
        "plains": ("West", "Green", "Meadow", "Clover", "Field"),
    }
    roots = roots_by_biome.get(
        max(biome_counts, key=biome_counts.get) if biome_counts else "plains",
        roots_by_biome["plains"],
    )
    endings = ("reach", "mere", "holm", "vale", "haven", "march", "coast", "land")
    polities = ("Republic", "Federation", "Union", "Commonwealth")
    options = [
        f"{root}{ending} {polity}"
        for root in roots
        for ending in endings
        for polity in polities
    ]
    random.shuffle(options)
    for name in options:
        if name not in used_names:
            return name
    suffix = 2
    name = f"{random.choice(roots)}{random.choice(endings)} {random.choice(polities)}"
    while name in used_names:
        name = (
            f"{random.choice(roots)}{random.choice(endings)} "
            f"{random.choice(polities)} {suffix}"
        )
        suffix += 1
    return name


def choose_strategic_war_target(
    origin: pygame.Vector2,
    territories: list[Territory],
    target_clan: int,
    resources: list[WorldResource],
) -> tuple[Territory | None, float]:
    candidates = [
        territory for territory in territories if territory.clan_id == target_clan
    ]
    if not candidates:
        return None, math.inf

    def score(territory: Territory) -> float:
        radius = max(territory.radius, 60)
        resource_value = 0.0
        for resource in resources:
            distance = territory.pos.distance_to(resource.pos)
            reach = min(radius + 180, 520)
            if resource.amount <= 0 or distance >= reach:
                continue
            value = (
                3.0
                if resource.kind in ("gold", "ore", "silicon")
                else 1.5
                if resource.kind in ("wood", "stone", "water")
                else 0.8
            )
            resource_value += value * (1 - distance / reach)

        water_access = 0.0
        sample_distance = radius + 100
        for angle in range(0, 360, 30):
            sample = territory.pos + pygame.Vector2(sample_distance, 0).rotate(angle)
            if biome_at(sample) in ("coast", "ocean"):
                water_access = 18.0
                break
        distance = origin.distance_to(territory.pos)
        return (
            water_access
            + min(resource_value, 24.0)
            + min(territory.home_level, 5) * 0.8
            - distance * 0.003
            - territory.fortification * 0.5
        )

    target = max(candidates, key=score)
    return target, origin.distance_to(target.pos)


@dataclass
class WildAnimal:
    species: str
    pos: pygame.Vector2
    heading: pygame.Vector2
    health: float = 100.0
    hunger: float = 15.0
    turn_timer: float = 0.0
    scared_timer: float = 0.0

    @property
    def is_predator(self) -> bool:
        return self.species in ("wolf", "fox", "bear")

    def update(
        self,
        dt: float,
        bounds: pygame.Rect,
        humans: list[Human],
        wildlife: list[WildAnimal],
    ) -> None:
        self.hunger = clamp(self.hunger + dt * 0.7, 0, 100)
        self.scared_timer = max(0, self.scared_timer - dt)
        if self.is_predator:
            if self.scared_timer > 0:
                human, _ = nearest_human(self.pos, humans)
                if human is not None:
                    self.heading = unit_vector(self.pos - human.pos)
                self.pos += self.heading * 75 * dt
                keep_in_bounds(self.pos, bounds, 12)
                return
            prey = [
                animal for animal in wildlife
                if animal is not self and not animal.is_predator
                and self.pos.distance_to(animal.pos) < 280
            ]
            prey_target = min(
                prey,
                key=lambda animal: self.pos.distance_to(animal.pos),
                default=None,
            )
            human_target, human_distance = nearest_human(self.pos, humans)
            if human_distance > 260:
                human_target = None
                human_distance = float("inf")
            prey_distance = (
                self.pos.distance_to(prey_target.pos)
                if prey_target is not None
                else float("inf")
            )
            target: Human | WildAnimal | None = prey_target
            distance = prey_distance
            if (
                prey_target is None
                and self.hunger > 60
                and human_target is not None
            ):
                target = human_target
                distance = human_distance
            if target is not None:
                self.heading = unit_vector(target.pos - self.pos)
                self.pos += self.heading * 52 * dt
                if distance < 20:
                    target.health -= (0.65 if isinstance(target, Human) else 28) * dt
                    if target.health <= 0:
                        self.hunger = clamp(self.hunger - 48, 0, 100)
            else:
                self._wander(dt)
        else:
            threats: list[object] = [
                entity
                for entity in [*humans, *(a for a in wildlife if a.is_predator)]
                if self.pos.distance_to(entity.pos) < 150
            ]
            if threats:
                threat, _ = nearest(self.pos, threats)
                if threat is not None:
                    self.heading = unit_vector(self.pos - threat.pos)  # type: ignore[attr-defined]
            else:
                self._wander(dt)
            self.pos += self.heading * (30 if self.species == "deer" else 38) * dt
        keep_in_bounds(self.pos, bounds, 12)

    def _wander(self, dt: float) -> None:
        self.turn_timer -= dt
        if self.turn_timer <= 0:
            self.heading = self.heading.rotate_rad(random.uniform(-1.0, 1.0))
            self.turn_timer = random.uniform(0.7, 2.2)
        self.pos += self.heading * (35 if self.is_predator else 22) * dt

    def draw(self, surface: pygame.Surface, screen_pos: pygame.Vector2) -> None:
        center = (round(screen_pos.x), round(screen_pos.y))
        if self.is_predator:
            color = {
                "wolf": (119, 87, 77),
                "fox": (183, 118, 63),
                "bear": (103, 76, 62),
            }[self.species]
            if self.species == "bear":
                pygame.draw.ellipse(surface, color, (center[0] - 12, center[1] - 8, 24, 17))
                pygame.draw.circle(surface, color, (center[0] + 8, center[1] - 5), 7)
                pygame.draw.circle(surface, (63, 49, 42), (center[0] - 7, center[1] + 8), 3)
                pygame.draw.circle(surface, (63, 49, 42), (center[0] + 7, center[1] + 8), 3)
                return
            points = [
                (center[0], center[1] - 11),
                (center[0] + 10, center[1] + 8),
                (center[0] - 10, center[1] + 8),
            ]
            pygame.draw.polygon(surface, color, points)
            pygame.draw.polygon(surface, (73, 56, 49), points, 2)
        else:
            animal_colors = {
                "deer": (155, 112, 75),
                "rabbit": (139, 128, 105),
                "boar": (89, 84, 74),
                "goat": (218, 218, 204),
            }
            color = animal_colors.get(self.species, (139, 128, 105))
            pygame.draw.ellipse(
                surface,
                color,
                (center[0] - 9, center[1] - 6, 18, 12),
            )
            pygame.draw.circle(
                surface,
                color,
                (center[0] + 7, center[1] - 5),
                5,
            )
            if self.species == "boar":
                pygame.draw.polygon(
                    surface,
                    (235, 225, 195),
                    [(center[0] + 8, center[1] - 3),
                     (center[0] + 13, center[1] - 1),
                     (center[0] + 8, center[1] + 1)],
                )
            elif self.species == "goat":
                pygame.draw.line(
                    surface, (85, 79, 68),
                    (center[0] + 3, center[1] - 8),
                    (center[0] + 1, center[1] - 13), 2,
                )



class Human:
    """A simulated person whose action choices come from an evolving Q-network."""

    def __init__(
        self,
        person_id: int,
        pos: pygame.Vector2,
        clan_id: int,
        color: tuple[int, int, int],
        parent: Human | None = None,
        other_parent: Human | None = None,
        gender: str | None = None,
        name: str | None = None,
        nickname: str | None = None,
    ) -> None:
        self.person_id = person_id
        self.pos = pygame.Vector2(pos)
        self.heading = pygame.Vector2(1, 0).rotate(random.randrange(360))
        self.clan_id = clan_id
        self.country_id = (
            getattr(parent, "country_id", None) if parent is not None else None
        )
        self.home_id = (
            getattr(parent, "home_id", None) if parent is not None else None
        )
        self.gender = gender or random.choice(("girl", "boy"))
        self.color = GIRL_COLOR if self.gender == "girl" else BOY_COLOR
        generated_name, generated_nickname = human_identity(person_id)
        self.name = name or generated_name
        self.nickname = nickname or generated_nickname
        self.age = 0.0
        self.generation = max(
            parent.generation if parent else 0,
            other_parent.generation if other_parent else 0,
        ) + (1 if parent or other_parent else 0)
        if parent:
            self.metabolism_gene = clamp(
                (parent.metabolism_gene + (other_parent.metabolism_gene if other_parent else parent.metabolism_gene)) / 2
                + random.gauss(0, 0.04),
                0.75,
                1.25,
            )
            self.strength_gene = clamp(
                (parent.strength_gene + (other_parent.strength_gene if other_parent else parent.strength_gene)) / 2
                + random.gauss(0, 0.06),
                0.7,
                1.3,
            )
            self.speed_gene = clamp(
                (parent.speed_gene + (other_parent.speed_gene if other_parent else parent.speed_gene)) / 2
                + random.gauss(0, 0.06),
                0.7,
                1.3,
            )
            self.brain = parent.brain.mutated_copy(
                other_parent.brain if other_parent is not None else None
            )
            self.focus_trait = clamp(
                (
                    parent.focus_trait
                    + (other_parent.focus_trait if other_parent else parent.focus_trait)
                ) / 2 + random.gauss(0, 0.08),
                0.2,
                1.8,
            )
            self.independence_trait = clamp(
                (
                    parent.independence_trait
                    + (other_parent.independence_trait if other_parent else parent.independence_trait)
                ) / 2 + random.gauss(0, 0.08),
                0.2,
                1.8,
            )
            self.sociability_trait = clamp(
                (
                    parent.sociability_trait
                    + (other_parent.sociability_trait if other_parent else parent.sociability_trait)
                ) / 2 + random.gauss(0, 0.08),
                0.2,
                1.8,
            )
            self.sensory_trait = clamp(
                (
                    parent.sensory_trait
                    + (other_parent.sensory_trait if other_parent else parent.sensory_trait)
                ) / 2 + random.gauss(0, 0.08),
                0.2,
                1.8,
            )
            self.aggression_trait = clamp(
                (parent.aggression_trait + (other_parent.aggression_trait if other_parent else parent.aggression_trait)) / 2
                + random.gauss(0, 0.1),
                0.1,
                1.9,
            )
            self.criminality_trait = clamp(
                (parent.criminality_trait + (other_parent.criminality_trait if other_parent else parent.criminality_trait)) / 2
                + random.gauss(0, 0.1),
                0.0,
                1.9,
            )
        else:
            self.speed_gene = random.uniform(0.9, 1.1)
            self.metabolism_gene = random.uniform(0.9, 1.1)
            self.strength_gene = random.uniform(0.9, 1.1)
            self.focus_trait = random.uniform(0.5, 1.5)
            self.sociability_trait = random.uniform(0.5, 1.5)
            self.sensory_trait = random.uniform(0.5, 1.5)
            self.independence_trait = random.uniform(0.5, 1.5)
            self.aggression_trait = random.uniform(0.1, 1.6)
            self.criminality_trait = random.uniform(0.0, 1.2)
            self.brain = NeuralBrain(39, HUMAN_ACTION_NAMES)

        condition_names = ("ADHD", "Anxiety", "Dyslexia")
        if parent is None:
            self.syndromes = [
                name for name in condition_names if random.random() < 0.18
            ]
        else:
            parents = (parent, other_parent) if other_parent is not None else (parent,)
            self.syndromes = [
                name for name in condition_names
                if (
                    any(name in ancestor.syndromes for ancestor in parents)
                    and random.random() < 0.35
                )
                or random.random() < 0.06
            ]
        self.is_president = False
        self.hunger = random.uniform(8, 24) if parent is None else 8
        self.energy = 100.0
        self.health = 100.0
        self.happiness = 60.0
        self.fear = 0.0
        self.affection = 0.0
        self.wood = 0
        self.stone = 0
        self.ore = 0
        self.gold = 0
        self.silicon = 0
        self.food = 2 if parent is None else 0
        self.cash = random.randint(3, 10) if parent is None else 0
        self.gang_id: int | None = None
        self.crimes_committed = 0
        self.last_birthday = int(self.age // 60)
        self.items: dict[str, int] = {}
        self.inventory: dict[str, int] = {}
        self.job = "Student"
        self.job_review_timer = 0.0
        self.work_timer = 0.0
        self.work_experience = 0.0
        self.claim_goal: pygame.Vector2 | None = None
        self.rejected_people: set[int] = set()
        self.romantic_interest: dict[int, float] = {}
        self.relationships: dict[int, float] = {}
        self.state = "Exploring"
        self.action_index = 0
        self.action_timer = 0.0
        self.action_used = False
        self.senses: list[float] | None = None
        self.previous_senses: list[float] | None = None
        self.previous_hunger = self.hunger
        self.previous_health = self.health
        self.previous_energy = self.energy
        self.previous_affection = self.affection
        self.previous_wood = self.wood
        self.previous_stone = self.stone
        self.previous_claims = 0
        self.children_count = 0
        self.previous_children_count = 0
        self.previous_build_levels = 0
        self.bonds: dict[int, float] = {}
        self.cooldowns: dict[str, float] = {}
        self.pending_reward = 0.0

    def amount(self, resource: str) -> int:
        if resource in ("wood", "stone", "ore", "gold", "silicon", "food"):
            return int(getattr(self, resource))
        return self.inventory.get(resource, 0)

    def weapon_strength(self) -> float:
        if self.items.get("spear", 0):
            return 1.65
        if self.items.get("bow", 0):
            return 1.45
        return 1.0

    def weapon_reach(self) -> float:
        return 76.0 if self.items.get("bow", 0) else 38.0

    def add_resource(self, resource: str, amount: int) -> None:
        if resource in ("wood", "stone", "ore", "gold", "silicon", "food"):
            setattr(self, resource, self.amount(resource) + amount)
        else:
            self.inventory[resource] = self.amount(resource) + amount

    def can_afford(self, costs: dict[str, int]) -> bool:
        return all(self.amount(resource) >= amount for resource, amount in costs.items())

    def spend(self, costs: dict[str, int]) -> None:
        for resource, amount in costs.items():
            self.add_resource(resource, -amount)

    def construction_permitted(
        self,
        territory: Territory,
        building: str,
        countries: dict[int, Country],
        requests: list[ConstructionRequest],
        world_time: float,
    ) -> bool:
        country_id = getattr(self, "country_id", None)
        if country_id is None:
            country_id = territory.clan_id
        country = countries.get(country_id)
        if country is None:
            return True
        request = next(
            (
                item for item in requests
                if item.person_id == self.person_id
                and item.country_id == country.clan_id
                and item.territory_owner_id == territory.owner_id
                and item.building == building
            ),
            None,
        )
        if request is None:
            requests.append(
                ConstructionRequest(
                    self.person_id,
                    country.clan_id,
                    territory.owner_id,
                    building,
                    world_time,
                )
            )
            return False
        if request.status == "approved":
            requests.remove(request)
            return True
        if request.status == "denied" and world_time - request.requested_at >= 180:
            requests.remove(request)
            return self.construction_permitted(
                territory, building, countries, requests, world_time
            )
        return False

    def choose_building(
        self,
        home: Territory,
        black_market_unlocked: bool = False,
        major_only: bool = False,
    ) -> str | None:
        buildings = home.buildings if home.buildings is not None else {}
        if home.home_level == 0:
            return None
        has_power_generator = any(
            amount > 0
            and building_category(name)
            in ("power station", "power plant", "solar farm", "wind farm")
            for name, amount in buildings.items()
        )
        has_medical_facility = any(
            amount > 0
            and building_category(name) in ("clinic", "hospital", "pharmacy")
            for name, amount in buildings.items()
        )
        if (
            black_market_unlocked
            and home.home_level >= 4
            and home.powered
            and has_power_generator
            and any(
                buildings.get(technology, 0)
                for technology in ("server farm", "data center", "cloud company")
            )
            and not buildings.get("black market", 0)
            and self.can_afford(building_costs("black market"))
        ):
            return "black market"
        if home.home_level >= 2 and not has_power_generator:
            for building in ("wind turbine", "wind farm", "solar farm", "power station"):
                if self.can_afford(building_costs(building)):
                    return building
        if home.home_level >= 2 and not has_medical_facility:
            for building in ("clinic", "medical center", "hospital"):
                if self.can_afford(building_costs(building)):
                    return building
        for building in BUILDING_COSTS:
            if (
                (
                    building not in BUILDING_TYPES
                    and building not in ("barn", "wind turbine", "medical center")
                )
                or buildings.get(building, 0)
                or building == "company"
                or building == "black market"
                or major_only and building in SMALL_BUILDINGS
            ):
                continue
            if building in ("server farm", "data center", "cloud company") and (
                home.home_level < 4 or not has_power_generator or not home.powered
            ):
                continue
            if building == "factory" and (
                home.home_level < 3 or not buildings.get("electronics lab", 0)
            ):
                continue
            if self.can_afford(building_costs(building)):
                return building

        tier = min(max(1, home.home_level), len(BUILDING_LEVEL_NAMES))
        level_name = BUILDING_LEVEL_NAMES[tier - 1]
        for building_type in BUILDING_TYPES:
            building = f"{level_name} {building_type.title()}"
            if buildings.get(building, 0):
                continue
            if building_type in ("server farm", "data center", "cloud company") and (
                home.home_level < 4
                or not has_power_generator
                or not home.powered
            ):
                continue
            if self.can_afford(building_costs(building)):
                return building
        return None

    def choose_craft(self, home: Territory) -> str | None:
        buildings = home.buildings if home.buildings is not None else {}
        if buildings.get("craft table", 0) == 0:
            return None
        for item, costs in CRAFT_COSTS.items():
            if item in ("electronics", "spear", "bow", "car", "cart"):
                continue
            if self.can_afford(costs) and self.inventory.get(item, 0) < 2:
                return item
        return None

    def choose_weapon(self) -> str | None:
        for weapon in ("spear", "bow"):
            if self.items.get(weapon, 0) == 0 and self.can_afford(CRAFT_COSTS[weapon]):
                return weapon
        return None

    def assign_job(
        self,
        home: Territory | None,
        territories: list[Territory] | None = None,
    ) -> str:
        workplaces = territories if territories is not None else ([home] if home else [])
        work_categories: list[tuple[float, str]] = []
        for workplace in workplaces:
            if workplace is None:
                continue
            for name, amount in (workplace.buildings or {}).items():
                category = building_category(name)
                if amount <= 0 or category is None:
                    continue
                if name in ("torch", "lamp", "heater"):
                    continue
                work_categories.append((self.pos.distance_to(workplace.pos), category))
        work_categories.sort()
        available_categories = {category for _, category in work_categories}
        families = [
            entry for entry in JOB_FAMILIES
            if entry[1] in available_categories
            and (
                entry[0] != "Black Market Broker"
                or any(
                    (workplace.buildings or {}).get("black market", 0)
                    for workplace in workplaces
                    if workplace is not None
                )
            )
        ]
        rank = min(len(JOB_RANKS) - 1, int(self.work_experience // 60))
        if not families:
            return f"{JOB_RANKS[rank]} Forager"
        closest_category = next(
            category for _, category in work_categories
            if any(family[1] == category for family in families)
        )
        matching = [family for family in families if family[1] == closest_category]
        family = matching[self.person_id % len(matching)]
        return f"{JOB_RANKS[rank]} {family[0]}"

    def work_shift(
        self,
        territories: list[Territory],
        workplace: Territory | None,
        food_source: WorldResource | None,
        wood_source: WorldResource | None,
        stone_source: WorldResource | None,
        power_source: Territory | None,
        power_target: Territory | None,
        power_lines: list[PowerLine],
        deliveries: list[Delivery],
        world_news: list[tuple[str, str]],
    ) -> bool:
        if self.age < ADULT_AGE:
            return False
        if workplace is None:
            if (
                food_source is not None
                and food_source.amount > 0
                and self.pos.distance_to(food_source.pos) < 38
            ):
                food_source.amount -= 1
                self.hunger = clamp(self.hunger - 22, 0, 100)
                self.cash += 1
                self.work_experience += 1
                return True
            if (
                wood_source is not None
                and wood_source.amount > 0
                and self.pos.distance_to(wood_source.pos) < 38
            ):
                wood_source.amount -= 1
                self.add_resource("wood", 1)
                self.cash += 1
                self.work_experience += 1
                return True
            if (
                stone_source is not None
                and stone_source.amount > 0
                and self.pos.distance_to(stone_source.pos) < 38
            ):
                stone_source.amount -= 1
                self.add_resource("stone", 1)
                self.cash += 1
                self.work_experience += 1
                return True
            return False
        if self.pos.distance_to(workplace.pos) >= 55:
            return False

        profession = self.job.split(" ", 1)[-1]
        if profession in ("Electrician", "Power Line Installer", "Line Engineer"):
            if power_source is None or power_target is None:
                return False
            if self.wood < 1 or self.ore < 1:
                return False
            self.wood -= 1
            self.ore -= 1
            power_lines.append(
                PowerLine(
                    pygame.Vector2(power_source.pos),
                    pygame.Vector2(power_target.pos),
                    self.person_id,
                )
            )
            world_news.append(
                (
                    f"{self.name} connected plot #{power_target.owner_id} "
                    f"to the grid from power station #{power_source.owner_id}.",
                    "Industry",
                )
            )
            self.work_experience += 6
            return True

        if profession in ("Delivery Driver", "Delivery Coordinator", "Courier", "Postal Worker"):
            source_options = [
                plot for plot in territories
                if plot.farm_food >= 2 and plot is not workplace
            ]
            target_options = [
                plot for plot in territories
                if plot is not workplace
                and any(
                    amount > 0 and building_category(name) in (
                        "market", "shop", "hospital", "restaurant", "distribution center"
                    )
                    for name, amount in (plot.buildings or {}).items()
                )
            ]
            if source_options and target_options:
                source, _ = nearest(workplace.pos, source_options)
                available_targets = [plot for plot in target_options if plot is not source]
                target: Territory | None = None
                if available_targets:
                    candidate, _ = nearest(
                        source.pos if isinstance(source, Territory) else workplace.pos,
                        available_targets,
                    )
                    target = candidate if isinstance(candidate, Territory) else None
                if isinstance(source, Territory) and target is not None:
                    route_exists = any(
                        delivery.courier_id == self.person_id
                        for delivery in deliveries
                    )
                    if not route_exists:
                        source.farm_food -= 2
                        deliveries.append(
                            Delivery(
                                pygame.Vector2(source.pos),
                                pygame.Vector2(target.pos),
                                source.owner_id,
                                target.owner_id,
                                self.person_id,
                                "food",
                                2,
                            )
                        )
                        world_news.append(
                            (
                                f"{self.name} dispatched a food delivery from "
                                f"plot #{source.owner_id} to plot #{target.owner_id}.",
                                "Industry",
                            )
                        )
                        self.work_experience += 6
                        self.cash += 2
                        return True
            self.cash += 1
            self.work_experience += 2
            return True

        if profession in ("Server Engineer", "Server Technician", "Network Administrator", "Data Center Operator", "Cloud Systems Engineer"):
            if not workplace.powered:
                self.happiness = clamp(self.happiness - 0.1, 0, 100)
                return False
            self.add_resource("compute", 2)
            self.cash += 3
            self.work_experience += 6
            world_news.append(
                (f"{self.name} processed data at the powered {profession.lower()} site.", "Industry")
            )
            return True

        if profession == "Black Market Broker":
            if (
                not workplace.powered
                or not (workplace.buildings or {}).get("black market", 0)
                or self.amount("compute") < 2
                or self.amount("electronics") < 1
            ):
                return False
            self.add_resource("compute", -2)
            self.add_resource("electronics", -1)
            self.add_resource("gold", 4)
            self.cash += 5
            self.crimes_committed += 1
            self.work_experience += 6
            world_news.append(
                (f"{self.name} completed a discreet black-market trade.", "Crime")
            )
            return True

        category = next(
            (building for title, building in JOB_FAMILIES if title == profession),
            None,
        )
        experience_gain = (
            4 if "Dyslexia" in self.syndromes
            and category in ("school", "library", "university", "research lab")
            else 6
        )
        if category in (
            "farm", "orchard", "ranch", "bakery", "butcher", "mill",
            "kitchen", "granary", "apartment", "house", "restaurant",
            "hotel", "stable", "windmill", "greenhouse", "fishery",
        ):
            workplace.farm_food += 1.5
        elif category in (
            "market", "shop", "inn", "depot", "rail station", "harbor",
            "delivery depot", "distribution center", "post office", "courier hub",
            "logistics center",
        ):
            self.add_resource("food", 1)
            self.cash += 2
        elif category == "bank":
            workplace.vault_cash += 2
            self.cash += 2
        elif category in ("mine", "smithy", "armory", "weaponsmith", "vehicle workshop", "garage", "steel mill", "battery plant"):
            self.add_resource("ore", 1)
            self.cash += 1
        elif category in ("quarry", "brickworks", "cement works"):
            self.add_resource("stone", 1)
        elif category in (
            "research lab", "factory", "power plant", "university",
            "observatory", "radio station", "server farm", "data center",
            "cloud company", "communications tower", "broadcast studio",
        ):
            if category in ("server farm", "data center", "cloud company") and not workplace.powered:
                return False
            self.add_resource("compute" if category in ("server farm", "data center", "cloud company") else "silicon", 2)
            self.cash += 3
        elif category in ("lumberyard", "sawmill", "woodcutter"):
            self.add_resource("wood", 2)
            self.cash += 1
        elif category in ("well", "water treatment"):
            self.add_resource("water", 2)
            self.happiness = clamp(self.happiness + 0.5, 0, 100)
        elif category in ("clinic", "hospital", "pharmacy"):
            self.health = clamp(self.health + 2, 0, 100)
            self.add_resource("medicine", 1)
        elif category in ("school", "library"):
            self.add_resource("knowledge", 2)
        elif category in ("textile mill", "tailor"):
            self.add_resource("clothes", 1)
        elif category in ("electric workshop", "repair shop"):
            self.add_resource("electronics", 1)
            self.add_resource("ore", 1)
        elif category == "recycling center":
            self.add_resource("wood", 1)
            self.add_resource("stone", 1)
        elif category in ("sewage plant", "cold storage"):
            workplace.farm_food += 0.5
        elif category in ("substation", "solar farm", "wind farm"):
            if category == "substation" and not workplace.powered:
                return False
            self.add_resource("energy", 2)
            self.cash += 2
        elif category in ("delivery depot", "distribution center", "freight yard", "courier hub", "logistics center"):
            self.add_resource("logistics", 1)
            self.cash += 2
        else:
            self.cash += 2
        self.work_experience += experience_gain
        self.pending_reward += 0.08
        return True

    def update(
        self,
        dt: float,
        world_bounds: pygame.Rect,
        humans: list[Human],
        resources: list[WorldResource],
        territories: list[Territory],
        wildlife: list[WildAnimal],
        births: list[tuple[Human, Human, pygame.Vector2]],
        night_level: float,
        social_events: list[SocialEvent] | None = None,
        gangs: list[Gang] | None = None,
        world_news: list[tuple[str, str]] | None = None,
        power_lines: list[PowerLine] | None = None,
        deliveries: list[Delivery] | None = None,
        wars: list[ClanWar] | None = None,
        countries: dict[int, Country] | None = None,
        construction_requests: list[ConstructionRequest] | None = None,
        world_time: float = 0.0,
    ) -> None:
        self.age += dt
        self.job_review_timer = max(0, self.job_review_timer - dt)
        self.hunger = clamp(
            self.hunger + HUMAN_HUNGER_RATE * self.metabolism_gene * dt, 0, 100
        )
        if self.hunger >= 38 and self.food > 0:
            self.food -= 1
            self.hunger = clamp(self.hunger - 28, 0, 100)
            self.happiness = clamp(self.happiness + 1.5, 0, 100)
        clothing_energy_cost = 0.58 if self.inventory.get("clothes", 0) else 0.75
        self.energy = clamp(self.energy - clothing_energy_cost * dt, 0, 100)
        for key in list(self.cooldowns):
            self.cooldowns[key] = max(0.0, self.cooldowns[key] - dt)

        food, food_distance = nearest_resource(self.pos, resources, "berries", 5000)
        wood_source, wood_distance = nearest_resource(self.pos, resources, "wood", 5000)
        stone_source, stone_distance = nearest_resource(self.pos, resources, "stone", 5000)
        ore_source, ore_distance = nearest_resource(self.pos, resources, "ore", 5000)
        gold_source, gold_distance = nearest_resource(self.pos, resources, "gold", 5000)
        silicon_source, silicon_distance = nearest_resource(self.pos, resources, "silicon", 5000)
        nearby_humans = [
            other for other in humans
            if other is not self and self.pos.distance_to(other.pos) < 500
        ]
        friend, friend_distance = nearest_human(
            self.pos, [p for p in nearby_humans if p.clan_id == self.clan_id]
        )
        potential_mates = [
            person for person in humans
            if person is not self and person.gender != self.gender
            and person.age >= ADULT_AGE
            and self.age >= ADULT_AGE and person.health > 30
        ]
        mate, mate_distance = nearest_human(self.pos, potential_mates)
        if mate is not None and mate.person_id in self.rejected_people:
            potential_mates = [
                person for person in potential_mates
                if person.person_id not in self.rejected_people
            ]
            mate, mate_distance = nearest_human(self.pos, potential_mates)
        rival, rival_distance = nearest_human(
            self.pos,
            [
                person for person in nearby_humans
                if person.clan_id != self.clan_id
                or (
                    self.gang_id is not None
                    and person.gang_id is not None
                    and person.gang_id != self.gang_id
                )
            ],
        )
        wars = wars if wars is not None else []
        countries = countries if countries is not None else {}
        construction_requests = (
            construction_requests if construction_requests is not None else []
        )
        active_war = next(
            (
                war for war in wars
                if self.clan_id in (war.attacker_clan, war.defender_clan)
            ),
            None,
        )
        war_enemy_clan = None
        if active_war is not None:
            war_enemy_clan = (
                active_war.defender_clan
                if self.clan_id == active_war.attacker_clan
                else active_war.attacker_clan
            )
            rival, rival_distance = nearest_human(
                self.pos,
                [
                    person for person in nearby_humans
                    if person.clan_id == war_enemy_clan
                ],
            )
        prey, prey_distance = nearest_wildlife(
            self.pos, wildlife, predators=False, maximum_distance=520
        )
        predator, predator_distance = nearest_wildlife(
            self.pos, wildlife, predators=True, maximum_distance=520
        )
        home, home_distance = nearest_owned_territory(self.pos, territories, self.person_id)
        if (
            home is not None
            and home_distance < 55
            and self.hunger >= 38
            and home.farm_food >= 1
        ):
            harvest = min(3, int(home.farm_food))
            home.farm_food -= harvest
            self.food += harvest
            if self.food > 0:
                self.food -= 1
                self.hunger = clamp(self.hunger - 28, 0, 100)
        is_forager = self.job.split(" ", 1)[-1] == "Forager"
        can_upgrade_forager_job = is_forager and self.job_review_timer <= 0 and any(
            amount > 0
            and building_category(name) == building
            and title != "Forager"
            for territory in territories
            for name, amount in (territory.buildings or {}).items()
            for title, building in JOB_FAMILIES
        )
        if self.age >= ADULT_AGE and (
            self.job in ("Student", "unassigned") or can_upgrade_forager_job
        ):
            self.job = self.assign_job(home, territories)
            self.job_review_timer = 30
        elif self.age < ADULT_AGE:
            self.job = "Student"
        profession = self.job.split(" ", 1)[-1]
        job_building = next(
            (building for title, building in JOB_FAMILIES if title == profession),
            None,
        )
        matching_workplaces = [
            territory for territory in territories
            if any(
                amount > 0 and building_category(name) == job_building
                and name not in ("torch", "lamp", "heater")
                and (
                    profession != "Black Market Broker"
                    or name == "black market"
                )
                for name, amount in (territory.buildings or {}).items()
            )
        ] if job_building else []
        workplace, workplace_distance = nearest(self.pos, matching_workplaces)
        workplace = workplace if isinstance(workplace, Territory) else None
        scheduled_work_shift = (
            self.age % HUMAN_WORKDAY_LENGTH < HUMAN_WORK_SHIFT_LENGTH
            and night_level < 0.75
        )
        if self.hunger >= 38:
            food_plot = next(
                (
                    plot for plot, distance in (
                        (home, home_distance),
                        (workplace, workplace_distance),
                    )
                    if plot is not None and distance < 55 and plot.farm_food >= 1
                ),
                None,
            )
            if food_plot is not None:
                harvested = min(3, int(food_plot.farm_food))
                food_plot.farm_food -= harvested
                self.hunger = clamp(self.hunger - 28, 0, 100)
                self.happiness = clamp(self.happiness + 1, 0, 100)
        power_lines = power_lines if power_lines is not None else []
        deliveries = deliveries if deliveries is not None else []
        power_source = None
        power_target = None
        if profession in ("Electrician", "Power Line Installer", "Line Engineer"):
            sources = [
                territory for territory in territories
                if territory.powered or any(
                    amount > 0 and building_category(name) in (
                        "power station", "power plant", "solar farm", "wind farm"
                    )
                    for name, amount in (territory.buildings or {}).items()
                )
            ]
            source, _ = nearest(self.pos, sources)
            power_source = source if isinstance(source, Territory) else None
            if power_source is not None:
                targets = [
                    territory for territory in territories
                    if territory.home_level > 0
                    and territory is not power_source
                    and not territory.powered
                    and self.pos.distance_to(territory.pos) < 900
                    and not any(
                        line.start.distance_to(power_source.pos) < 2
                        and line.end.distance_to(territory.pos) < 2
                        for line in power_lines
                    )
                ]
                target, _ = nearest(self.pos, targets)
                power_target = target if isinstance(target, Territory) else None
                if power_target is not None:
                    workplace = power_target
                    workplace_distance = self.pos.distance_to(power_target.pos)
        social_events = social_events if social_events is not None else []
        gangs = gangs if gangs is not None else []
        world_news = world_news if world_news is not None else []
        available_events = [
            event for event in social_events
            if self.person_id not in (event.attendees or set())
        ]
        social_event, social_distance = nearest(
            self.pos,
            available_events,
            420,
        )
        social_event = social_event if isinstance(social_event, SocialEvent) else None
        nearest_gang_member, gang_member_distance = nearest_human(
            self.pos,
            [
                person for person in humans
                if person.gang_id is not None and person.gang_id != self.gang_id
            ],
        )
        gang_target = next(
            (gang for gang in gangs if gang.gang_id == (nearest_gang_member.gang_id if nearest_gang_member else None)),
            None,
        )
        if gang_member_distance > 240:
            nearest_gang_member = None
            gang_target = None
        rob_target, rob_distance = nearest_human(
            self.pos,
            [
                person for person in nearby_humans
                if person.cash > 0 or person.food > 0 or person.wood > 0 or person.stone > 0
            ],
        )
        current_gang = next(
            (gang for gang in gangs if gang.gang_id == self.gang_id),
            None,
        )
        bank_candidate, bank_distance = nearest(
            self.pos,
            [
                territory for territory in territories
                if territory.owner_id != self.person_id
                and territory.vault_cash > 0
                and any(
                    amount > 0 and building_category(name) == "bank"
                    for name, amount in (territory.buildings or {}).items()
                )
            ],
        )
        bank_land = (
            bank_candidate if isinstance(bank_candidate, Territory) else None
        )
        claim_site = nearest_claim_site(self.pos, world_bounds, territories        )
        enemy_land, enemy_land_distance = nearest_enemy_territory(
            self.pos, territories, self.clan_id
        )
        if war_enemy_clan is not None:
            enemy_land, enemy_land_distance = choose_strategic_war_target(
                self.pos,
                territories,
                war_enemy_clan,
                resources,
            )

        def sense_vector(
            target: pygame.Vector2 | None, distance: float, range_limit: float
        ) -> tuple[float, float]:
            range_limit *= clamp(self.sensory_trait, 0.5, 1.5)
            if target is None or distance >= range_limit:
                return 0.0, 0.0
            offset = target - self.pos
            if offset.length_squared() < 0.001:
                return 0.0, 0.0
            proximity = 1 - distance / range_limit
            return (
                clamp(offset.normalize().dot(self.heading) * proximity, -1, 1),
                clamp(offset.normalize().dot(self.heading.rotate(90)) * proximity, -1, 1),
            )

        food_sense = sense_vector(food.pos if food else None, food_distance, 600)
        wood_sense = sense_vector(
            wood_source.pos if wood_source else None, wood_distance, 500
        )
        stone_sense = sense_vector(
            stone_source.pos if stone_source else None, stone_distance, 500
        )
        ore_sense = sense_vector(
            ore_source.pos if ore_source else None, ore_distance, 600
        )
        gold_sense = sense_vector(
            gold_source.pos if gold_source else None, gold_distance, 650
        )
        silicon_sense = sense_vector(
            silicon_source.pos if silicon_source else None, silicon_distance, 650
        )
        friend_sense = sense_vector(
            friend.pos if friend else None, friend_distance, 500
        )
        mate_sense = sense_vector(
            mate.pos if mate and mate_distance < 520 else None,
            mate_distance,
            520,
        )
        rival_sense = sense_vector(
            rival.pos if rival else None, rival_distance, 500
        )
        prey_sense = sense_vector(
            prey.pos if prey else None, prey_distance, 520
        )
        predator_sense = sense_vector(
            predator.pos if predator else None, predator_distance, 520
        )
        home_sense = sense_vector(
            home.pos if home and home_distance < 600 else None,
            home_distance,
            600,
        )
        enemy_land_sense = sense_vector(
            enemy_land.pos if enemy_land else None,
            enemy_land_distance,
            600,
        )
        senses = [
            *food_sense,
            *wood_sense,
            *stone_sense,
            *ore_sense,
            *gold_sense,
            *silicon_sense,
            *friend_sense,
            *rival_sense,
            *mate_sense,
            *prey_sense,
            *predator_sense,
            *home_sense,
            *enemy_land_sense,
            self.hunger / 50 - 1,
            self.energy / 50 - 1,
            self.health / 50 - 1,
            self.fear / 50 - 1,
            self.affection / 50 - 1,
            min(self.wood, 10) / 5 - 1,
            min(self.stone, 10) / 5 - 1,
            min(sum(1 for t in territories if t.clan_id == self.clan_id), 8) / 4 - 1,
            self.focus_trait - 1,
            self.sociability_trait - 1,
            self.sensory_trait - 1,
            (home.home_level / 3 - 1) if home else -1,
            (home.fortification / 3 - 1) if home else -1,
        ]

        preferences = [0.0] * len(HUMAN_ACTION_NAMES)

        def prefer(action_name: str, amount: float) -> None:
            preferences[HUMAN_ACTION_NAMES.index(action_name)] += amount

        line_crew = profession in (
            "Electrician", "Power Line Installer", "Line Engineer"
        ) and power_target is not None
        if line_crew and self.wood < 1 and wood_source is not None:
            prefer("Gather wood", 7.0)
        if line_crew and self.ore < 1 and ore_source is not None:
            prefer("Mine ore", 7.0)

        prefer("Forage", 0.9 + self.hunger / 35 if food is not None else -2.0)
        prefer("Gather wood", 1.25 if wood_source is not None and self.wood < 5 else -1.5)
        prefer("Gather stone", 1.25 if stone_source is not None and self.stone < 4 else -1.5)
        prefer("Bond", 0.3 if friend is not None else -1.0)
        mutual_interest = (
            mate is not None
            and self.romantic_interest.get(mate.person_id, 0) > 0
            and mate.romantic_interest.get(self.person_id, 0) > 0
            and mate.person_id not in self.rejected_people
            and self.person_id not in mate.rejected_people
        )
        prefer(
            "Love",
            (
                3.2 if mutual_interest else 0.7
            ) * self.sociability_trait
            if mate is not None and mate_distance < 80
            else -1.5,
        )
        prefer(
            "Reject advance",
            1.3 * self.independence_trait
            if mate is not None and mate.romantic_interest.get(self.person_id, 0) > 0
            and not mutual_interest
            else -2.0,
        )
        can_have_child = (
            mate is not None
            and self.bonds.get(mate.person_id, 0) >= LOVE_THRESHOLD
            and mate.bonds.get(self.person_id, 0) >= LOVE_THRESHOLD
            and self.hunger < 72
            and mate.hunger < 72
            and self.cooldowns.get("parenthood", 0) == 0
            and mate.cooldowns.get("parenthood", 0) == 0
        )
        prefer("Have child", 2.6 if can_have_child and mutual_interest else -2.0)

        has_claim = home is not None
        owned_land_count = sum(
            territory.owner_id == self.person_id for territory in territories
        )
        can_claim = (
            home is None
            and owned_land_count < MAX_TERRITORIES_PER_PERSON
            and self.wood >= 2
            and self.stone >= 1
        )
        if self.claim_goal is None and can_claim:
            self.claim_goal = claim_site
        elif self.claim_goal is not None and any(
            self.claim_goal.distance_to(territory.pos) <= territory.radius + 55
            for territory in territories
        ):
            self.claim_goal = claim_site
        prefer("Claim land", 3.0 if can_claim and self.claim_goal is not None else -2.0)
        prefer(
            "Build home",
            2.8 if home is not None and home.home_level == 0 and self.wood >= 5 and self.stone >= 2 else -2.0,
        )
        prefer(
            "Upgrade home",
            2.4 if home is not None and 0 < home.home_level < len(BUILDING_LEVEL_NAMES)
            and self.wood >= 3 + home.home_level * 2
            and self.stone >= 2 + home.home_level else -2.0,
        )
        prefer(
            "Fortify",
            0.9 if home is not None and home.fortification < 3 and self.wood >= 3 and self.stone >= 3 else -2.0,
        )
        prefer(
            "Expand territory",
            1.8 if home is not None and self.wood >= 3 and self.stone >= 2
            and home.radius < MAX_TERRITORY_RADIUS
            else -2.0,
        )
        prefer("Fight rival", 0.25 if rival is not None else -1.5)
        prefer(
            "Brawl",
            1.8 * self.aggression_trait
            if rival is not None and rival_distance < 130
            else -1.8,
        )
        prefer("Flee", 1.0 if rival is not None or predator is not None else -1.5)
        can_defend_predator = (
            predator is not None
            and predator_distance < 85
            and self.health > 40
            and self.energy > 22
            and (self.aggression_trait > 0.75 or predator_distance < 55)
        )
        urgent_danger = (
            (predator_distance < 150 and not can_defend_predator)
            or (rival_distance < 80 and active_war is None)
        )
        if urgent_danger:
            prefer("Flee", 4.5)
            self.action_timer = min(self.action_timer, 0.15)
        prefer("Hunt animal", 1.4 * self.hunger / 100 if prey is not None else -2.0)
        prefer(
            "Threaten predator",
            4.2 if can_defend_predator and predator_distance >= 34
            else 0.7 if predator is not None else -2.0,
        )
        prefer(
            "Fight predator",
            4.5 if can_defend_predator and predator_distance < 34
            and self.aggression_trait > 0.9
            else 0.4 if predator is not None else -2.0,
        )
        prefer(
            "Raid land",
            7.5
            if active_war is not None
            and enemy_land is not None
            and owned_land_count < MAX_TERRITORIES_PER_PERSON
            else -1.5,
        )
        if active_war is not None and rival is not None and rival_distance < 110:
            prefer("Fight rival", 6.5 if self.health > 30 else -1.0)
        prefer(
            "Rob",
            1.6 * self.criminality_trait
            if (
                rob_target is not None and rob_distance < 300
                or bank_land is not None and bank_distance < 300
            )
            else -2.0,
        )
        prefer(
            "Join gang",
            1.2 * self.criminality_trait
            if self.gang_id is None and gang_target is not None
            else -2.0,
        )
        prefer(
            "Form gang",
            1.5 * self.criminality_trait
            if self.gang_id is None and self.criminality_trait > 0.75
            and self.aggression_trait > 0.65
            else -2.0,
        )
        prefer(
            "Extort",
            1.8 * self.criminality_trait
            if current_gang is not None and rob_target is not None
            and rob_distance < 180
            else -2.0,
        )
        if social_event is not None:
            prefer(
                "Mourn" if social_event.kind == "funeral" else "Celebrate",
                1.1 if social_distance < 300 else 0.4,
            )
        prefer(
            "Rest",
            (100 - self.energy) / 55 + night_level * 0.35
            + (3.0 if self.energy < 25 else 0),
        )
        buildings = home.buildings if home and home.buildings is not None else {}
        has_farm = any(
            amount > 0 and building_category(name) in ("farm", "orchard", "ranch")
            for name, amount in buildings.items()
        )
        craft_choice = self.choose_craft(home) if home is not None else None
        weapon_choice = self.choose_weapon() if home is not None and (
            buildings.get("armory", 0) or buildings.get("weaponsmith", 0)
        ) else None
        vehicle_choice = None
        if home is not None and not (
            self.inventory.get("car", 0) or self.inventory.get("cart", 0)
        ):
            if (
                buildings.get("garage", 0)
                or buildings.get("vehicle workshop", 0)
            ) and self.can_afford(CRAFT_COSTS["car"]):
                vehicle_choice = "car"
            elif buildings.get("stable", 0) and self.can_afford(CRAFT_COSTS["cart"]):
                vehicle_choice = "cart"
        prefer("Build", -1000.0)
        prefer("Craft", 1.8 if craft_choice is not None else -2.0)
        prefer(
            "Farm",
            1.5 if home is not None and has_farm and home.farm_food >= 1 else -2.0,
        )
        prefer(
            "Work",
            0.3 if line_crew and (self.wood < 1 or self.ore < 1)
            else 8.0 if self.age >= ADULT_AGE and workplace is not None and scheduled_work_shift
            else 1.5 if self.age >= ADULT_AGE and workplace is not None
            else 0.25 if self.age >= ADULT_AGE else -2.0,
        )
        prefer(
            "Build power line",
            4.5 if line_crew and self.wood >= 1 and self.ore >= 1 else -2.0,
        )
        prefer("Craft weapon", 2.8 if weapon_choice is not None else -2.0)
        prefer("Build vehicle", 3.0 if vehicle_choice is not None else -2.0)
        prefer("Produce electronics", 1.0 if home is not None and buildings.get("electronics lab", 0) and self.can_afford(CRAFT_COSTS["electronics"]) else -2.0)
        prefer(
            "Start company",
            1.8 if home is not None
            and home.home_level >= 3
            and buildings.get("electronics lab", 0)
            and self.can_afford(BUILDING_COSTS["company"])
            else -2.0,
        )
        prefer("Mine ore", 0.9 if ore_source is not None and self.ore < 10 else -1.5)
        prefer("Mine gold", 1.0 if gold_source is not None and self.gold < 8 else -1.5)
        prefer("Mine silicon", 0.8 if silicon_source is not None and self.silicon < 8 else -1.5)
        prefer("Return home", 1.8 if home is not None and (self.fear > 15 or night_level > 0.7) and home_distance > 60 else -1.5)

        # Give unfinished survival and settlement tasks a concrete target.
        if self.age >= ADULT_AGE and home is None:
            if self.wood < 2 and wood_source is not None:
                prefer("Gather wood", 12.0)
            elif self.stone < 1 and stone_source is not None:
                prefer("Gather stone", 12.0)
            elif self.wood >= 2 and self.stone >= 1:
                prefer("Claim land", 14.0)
        elif self.age >= ADULT_AGE and home is not None and home.home_level == 0:
            if self.wood < 5 and wood_source is not None:
                prefer("Gather wood", 12.0)
            elif self.stone < 2 and stone_source is not None:
                prefer("Gather stone", 12.0)
            elif self.wood >= 5 and self.stone >= 2:
                prefer("Build home", 14.0)
        elif self.age >= ADULT_AGE and home is not None and home.home_level > 0:
            if self.wood < 5 and wood_source is not None:
                prefer("Gather wood", 7.0)
            if self.stone < 3 and stone_source is not None:
                prefer("Gather stone", 7.0)

        if self.hunger > 80:
            prefer("Forage", 0.8)
            prefer("Hunt animal", 0.8 if prey is not None else 0)
        if self.hunger > 55 and food is not None:
            prefer("Forage", 10.0)
        if has_claim and not any(
            territory.home_level for territory in territories
            if territory.owner_id == self.person_id
        ):
            prefer("Build home", 0.4)

        self.action_timer -= dt
        if self.action_timer <= 0:
            old_action_name = HUMAN_ACTION_NAMES[self.action_index]
            if self.previous_senses is not None:
                reward = (self.previous_hunger - self.hunger) * 0.025
                reward += (self.health - self.previous_health) * 0.05
                reward += (self.energy - self.previous_energy) * 0.01
                reward += (self.affection - self.previous_affection) * 0.012
                reward += (self.wood - self.previous_wood) * max(
                    0.01, 0.16 - self.previous_wood * 0.025
                )
                reward += (self.stone - self.previous_stone) * max(
                    0.01, 0.16 - self.previous_stone * 0.025
                )
                claims_now = sum(1 for t in territories if t.owner_id == self.person_id)
                reward += (claims_now - self.previous_claims) * 0.8
                build_levels = sum(
                    territory.home_level + territory.fortification
                    for territory in territories
                    if territory.clan_id == self.clan_id
                )
                reward += (build_levels - self.previous_build_levels) * 0.35
                reward += (self.children_count - self.previous_children_count) * 0.5
                previous_action = old_action_name
                reward += self.pending_reward
                self.pending_reward = 0.0
                reward += (self.health - self.previous_health) * 0.08
                reward += (self.hunger - self.previous_hunger) * -0.035
                goals = (
                    (0, food, "Forage", 0.55 + self.hunger / 45),
                    (2, wood_source, "Gather wood", 0.35),
                    (4, stone_source, "Gather stone", 0.35),
                    (6, ore_source, "Mine ore", 0.35),
                    (8, gold_source, "Mine gold", 0.35),
                    (10, silicon_source, "Mine silicon", 0.35),
                    (12, friend, "Bond", 0.3),
                    (16, mate, "Love", 0.35 * self.sociability_trait),
                    (18, prey, "Hunt animal", 0.35),
                    (20, predator, "Threaten predator", 0.35),
                    (22, home, "Build home", 0.25),
                    (24, enemy_land, "Raid land", 0.25),
                )
                for start, target, goal_action, weight in goals:
                    if target is not None and previous_action == goal_action:
                        old_proximity = math.hypot(*self.previous_senses[start:start + 2])
                        new_proximity = math.hypot(*senses[start:start + 2])
                        reward += (new_proximity - old_proximity) * weight
                if rival is not None:
                    old_danger = math.hypot(*self.previous_senses[14:16])
                    new_danger = math.hypot(*senses[14:16])
                    if previous_action == "Flee":
                        reward += (old_danger - new_danger) * 0.35
                    elif previous_action == "Fight rival":
                        reward += (new_danger - old_danger) * 0.18
                if self.previous_hunger > self.hunger:
                    reward += 0.12
                if self.health <= 0:
                    reward -= 1.0

                self.brain.learn(
                    self.previous_senses,
                    self.action_index,
                    clamp(reward, -2, 2),
                    senses,
                )

            self.senses = senses[:]
            self.action_index = self.brain.choose(
                senses,
                explore=False,
                preferences=preferences,
            )
            active_action = HUMAN_ACTION_NAMES[self.action_index]
            if urgent_danger:
                active_action = "Flee"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif self.energy < 12:
                active_action = "Rest"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif self.hunger > 55 and food is not None:
                active_action = "Forage"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif power_target is not None and self.wood >= 1 and self.ore >= 1 and profession in (
                "Electrician", "Power Line Installer", "Line Engineer"
            ):
                active_action = "Build power line"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif can_defend_predator:
                active_action = (
                    "Fight predator"
                    if predator_distance < 34 and self.aggression_trait > 0.9
                    else "Threaten predator"
                )
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif (
                self.age >= ADULT_AGE
                and workplace is not None
                and scheduled_work_shift
                and self.hunger <= 55
                and self.energy >= 12
            ):
                active_action = "Work"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif self.claim_goal is not None and self.wood >= 2 and self.stone >= 1:
                active_action = "Claim land"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif home is not None and home_distance > 55 and (
                self.fear > 35 or night_level > 0.8
            ):
                active_action = "Return home"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif (
                self.age >= ADULT_AGE
                and home is not None
                and home.home_level == 0
                and self.wood >= 5
                and self.stone >= 2
            ):
                active_action = "Build home"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif (
                self.age >= ADULT_AGE
                and home is not None
                and home.home_level > 0
                and self.wood < 5
                and wood_source is not None
            ):
                active_action = "Gather wood"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif (
                self.age >= ADULT_AGE
                and home is not None
                and home.home_level > 0
                and self.stone < 3
                and stone_source is not None
            ):
                active_action = "Gather stone"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif old_action_name == "Claim land" and self.claim_goal is not None:
                active_action = "Claim land"
                self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            elif old_action_name in ("Gather wood", "Gather stone", "Mine ore", "Mine gold", "Mine silicon"):
                source_by_action = {
                    "Gather wood": wood_source,
                    "Gather stone": stone_source,
                    "Mine ore": ore_source,
                    "Mine gold": gold_source,
                    "Mine silicon": silicon_source,
                }
                target = source_by_action[old_action_name]
                if target is not None and self.pos.distance_to(target.pos) > 34:
                    active_action = old_action_name
                    self.action_index = HUMAN_ACTION_NAMES.index(active_action)
            self.previous_senses = senses[:]
            self.previous_hunger = self.hunger
            self.previous_health = self.health
            self.previous_energy = self.energy
            self.previous_affection = self.affection
            self.previous_wood = self.wood
            self.previous_stone = self.stone
            self.previous_claims = sum(
                1 for t in territories if t.owner_id == self.person_id
            )
            self.previous_build_levels = sum(
                territory.home_level + territory.fortification
                for territory in territories
                if territory.clan_id == self.clan_id
            )
            self.previous_children_count = self.children_count
            focus = self.focus_trait * (0.8 if "ADHD" in self.syndromes else 1.0)
            self.action_timer = HUMAN_DECISION_INTERVAL / clamp(focus, 0.5, 1.5)
            self.action_used = False

        if (
            HUMAN_ACTION_NAMES[self.action_index] == "Work"
            and workplace is None
        ):
            fallback_action = (
                "Forage" if self.hunger > 40 and food is not None
                else "Gather wood" if self.wood < 5 and wood_source is not None
                else "Gather stone" if self.stone < 3 and stone_source is not None
                else "Explore"
            )
            self.action_index = HUMAN_ACTION_NAMES.index(fallback_action)

        action = HUMAN_ACTION_NAMES[self.action_index]
        self.state = action
        direction = self.heading
        if action == "Turn left":
            direction = self.heading.rotate(-65)
        elif action == "Turn right":
            direction = self.heading.rotate(65)
        elif action == "Forage" and food is not None:
            direction = food.pos - self.pos
        elif action == "Gather wood" and wood_source is not None:
            direction = wood_source.pos - self.pos
        elif action == "Gather stone" and stone_source is not None:
            direction = stone_source.pos - self.pos
        elif action == "Bond" and friend is not None:
            direction = friend.pos - self.pos
        elif action == "Fight rival" and rival is not None:
            direction = rival.pos - self.pos
        elif action == "Flee" and (rival is not None or predator is not None):
            threat = min(
                ((rival, rival_distance), (predator, predator_distance)),
                key=lambda pair: pair[1],
            )[0]
            if threat is not None:
                direction = self.pos - threat.pos
        elif action == "Love" and mate is not None and mate_distance < 80:
            direction = mate.pos - self.pos
        elif action in ("Celebrate", "Mourn") and social_event is not None:
            direction = social_event.pos - self.pos
        elif action == "Brawl" and rival is not None:
            direction = rival.pos - self.pos
        elif (
            action == "Rob"
            and bank_land is not None
            and bank_distance < rob_distance
        ):
            direction = bank_land.pos - self.pos
        elif action in ("Rob", "Extort") and rob_target is not None:
            direction = rob_target.pos - self.pos
        elif action == "Join gang" and nearest_gang_member is not None:
            direction = nearest_gang_member.pos - self.pos
        elif action == "Reject advance" and mate is not None and mate_distance < 80:
            direction = mate.pos - self.pos
        elif action == "Have child" and mate is not None and mate_distance < 45:
            direction = mate.pos - self.pos
        elif action == "Hunt animal" and prey is not None:
            direction = prey.pos - self.pos
        elif action in ("Threaten predator", "Fight predator") and predator is not None:
            direction = predator.pos - self.pos
        elif action in (
            "Build home", "Upgrade home", "Fortify", "Expand territory"
        ) and home is not None:
            direction = home.pos - self.pos
        elif action == "Raid land" and enemy_land is not None:
            direction = enemy_land.pos - self.pos
        elif action == "Return home" and home is not None:
            direction = home.pos - self.pos
        elif action == "Mine ore" and ore_source is not None:
            direction = ore_source.pos - self.pos
        elif action == "Mine gold" and gold_source is not None:
            direction = gold_source.pos - self.pos
        elif action == "Mine silicon" and silicon_source is not None:
            direction = silicon_source.pos - self.pos
        elif action in ("Build", "Craft", "Farm", "Produce electronics", "Start company") and home is not None:
            direction = home.pos - self.pos
        elif action in ("Craft weapon", "Build vehicle") and home is not None:
            direction = home.pos - self.pos
        elif action == "Work":
            if workplace is not None:
                direction = workplace.pos - self.pos
            elif profession in ("Forager", "Fisher", "Fishery Worker"):
                direction = food.pos - self.pos if food is not None else self.heading
            elif profession in ("Lumberjack", "Sawmill Worker"):
                direction = wood_source.pos - self.pos if wood_source is not None else self.heading
            elif profession in ("Quarry Worker", "Miner"):
                direction = stone_source.pos - self.pos if stone_source is not None else self.heading
        elif action == "Build power line" and power_target is not None:
            direction = power_target.pos - self.pos
        elif action == "Claim land":
            if self.claim_goal is not None:
                direction = self.claim_goal - self.pos
            else:
                direction = self.heading.rotate(math.sin(self.age * 0.31) * 30)
        else:
            direction = self.heading.rotate_rad(math.sin(self.age * 0.7) * 0.1)

        if direction.length_squared() > 0.001:
            desired = unit_vector(direction)
            if action == "Flee":
                self.heading = desired
            else:
                angle = self.heading.angle_to(desired)
                self.heading = self.heading.rotate(clamp(angle, -120 * dt, 120 * dt))

        if action == "Rest":
            self.energy = clamp(self.energy + 5.5 * dt, 0, 100)
        speed = 42 * self.speed_gene
        if self.inventory.get("car", 0):
            speed *= 1.8
        elif self.inventory.get("cart", 0):
            speed *= 1.35
        if action == "Rest":
            speed *= 0.28
        elif action in ("Flee", "Threaten predator"):
            speed *= 1.5 if action == "Flee" else 1.3
        if (
            home is not None
            and home_distance < 42
            and action in (
                "Build home", "Upgrade home", "Fortify", "Build", "Craft",
                    "Expand territory", "Farm", "Produce electronics", "Start company",
                "Craft weapon", "Build vehicle",
            )
        ):
            speed = 0
        if action == "Work" and workplace is not None and workplace_distance < 42:
            speed = 0
        elif action == "Forage" and food is not None and food_distance < 18:
            speed = 0
        elif action in (
            "Gather wood", "Gather stone", "Mine ore", "Mine gold", "Mine silicon"
        ):
            target = {
                "Gather wood": wood_source,
                "Gather stone": stone_source,
                "Mine ore": ore_source,
                "Mine gold": gold_source,
                "Mine silicon": silicon_source,
            }[action]
            if target is not None and self.pos.distance_to(target.pos) < 18:
                speed = 0
        next_position = self.pos + self.heading * speed * dt
        if biome_at(next_position) == "ocean":
            self.heading = unit_vector(
                pygame.Vector2(HUMAN_WORLD_SIZE) / 2 - self.pos
            )
        else:
            self.pos = next_position
        keep_in_bounds(self.pos, world_bounds, 15)

        if (
            action == "Forage" and food is not None and food_distance < 26
            and not self.action_used and food.amount > 0
        ):
            food.amount -= 1
            self.hunger = clamp(self.hunger - 30, 0, 100)
            self.happiness = clamp(self.happiness + 3, 0, 100)
            self.action_used = True

        if (
            action == "Expand territory"
            and home is not None
            and home_distance < 55
            and home.radius < MAX_TERRITORY_RADIUS
            and self.wood >= 3
            and self.stone >= 2
            and self.construction_permitted(
                home, "territory expansion", countries,
                construction_requests, world_time,
            )
        ):
            self.wood -= 3
            self.stone -= 2
            expand_territory(
                home,
                min(20, MAX_TERRITORY_RADIUS - home.radius),
            )
            self.action_used = True
            world_news.append(
                (
                    f"Territory expansion: person #{self.person_id} enlarged their claimed land.",
                    "Development",
                )
            )
        elif (
            action in ("Gather wood", "Gather stone", "Mine ore", "Mine gold", "Mine silicon")
            and not self.action_used
        ):
            source = {
                "Gather wood": wood_source,
                "Gather stone": stone_source,
                "Mine ore": ore_source,
                "Mine gold": gold_source,
                "Mine silicon": silicon_source,
            }[action]
            if source is not None and self.pos.distance_to(source.pos) < 30 and source.amount:
                source.amount -= 1
                resource_name = {
                    "Gather wood": "wood",
                    "Gather stone": "stone",
                    "Mine ore": "ore",
                    "Mine gold": "gold",
                    "Mine silicon": "silicon",
                }[action]
                self.add_resource(resource_name, 1)
                self.action_used = True

        if action == "Bond" and friend is not None and friend_distance < 48:
            bond = min(100, self.bonds.get(friend.person_id, 0) + dt * 6)
            self.bonds[friend.person_id] = bond
            self.affection = clamp(self.affection + dt * 1.8, 0, 100)
            self.happiness = clamp(self.happiness + dt * 2, 0, 100)

        if action == "Love" and mate is not None and mate_distance < 48:
            self.romantic_interest[mate.person_id] = 1.0
            if mate.romantic_interest.get(self.person_id, 0) > 0:
                bond = min(
                    100,
                    self.bonds.get(mate.person_id, 0)
                    + dt * 7 * min(self.sociability_trait, mate.sociability_trait),
                )
                self.bonds[mate.person_id] = bond
                mate.bonds[self.person_id] = bond
                self.affection = clamp(self.affection + dt * 2.2, 0, 100)
                mate.affection = clamp(mate.affection + dt * 2.2, 0, 100)
                self.happiness = clamp(self.happiness + dt * 2, 0, 100)
                mate.happiness = clamp(mate.happiness + dt * 2, 0, 100)
                self.pending_reward += dt * self.sociability_trait * 0.8

        if (
            action == "Have child"
            and mate is not None
            and mate_distance < 38
            and self.bonds.get(mate.person_id, 0) >= LOVE_THRESHOLD
            and mate.bonds.get(self.person_id, 0) >= LOVE_THRESHOLD
            and self.health > 45
            and mate.health > 45
            and self.hunger < 72
            and mate.hunger < 72
            and self.cooldowns.get("parenthood", 0) == 0
            and mate.cooldowns.get("parenthood", 0) == 0
        ):
            births.append((self, mate, (self.pos + mate.pos) / 2))
            self.cooldowns["parenthood"] = 900
            mate.cooldowns["parenthood"] = 900
            self.happiness = clamp(self.happiness + 18, 0, 100)
            mate.happiness = clamp(mate.happiness + 18, 0, 100)
            self.action_used = True

        if (
            action == "Hunt animal"
            and prey is not None
            and self.pos.distance_to(prey.pos) < 30
            and self.cooldowns.get("hunt", 0) == 0
        ):
            previous_health = prey.health
            prey.health = max(0, prey.health - 24 * self.strength_gene)
            self.pending_reward += (previous_health - prey.health) * 0.025
            self.cooldowns["hunt"] = 0.8
            if prey.health <= 0:
                self.hunger = clamp(self.hunger - 48, 0, 100)
                self.happiness = clamp(self.happiness + 8, 0, 100)

        if (
            action == "Threaten predator"
            and predator is not None
            and self.pos.distance_to(predator.pos) < 62
            and self.cooldowns.get("threaten", 0) == 0
        ):
            predator.scared_timer = max(predator.scared_timer, 7)
            self.pending_reward += 0.4
            self.cooldowns["threaten"] = 2.5

        if (
            action == "Fight predator"
            and predator is not None
            and self.pos.distance_to(predator.pos) < self.weapon_reach()
            and self.cooldowns.get("attack", 0) == 0
        ):
            previous_health = predator.health
            predator.health = max(
                0,
                predator.health - 18 * self.strength_gene * self.weapon_strength(),
            )
            self.pending_reward += (previous_health - predator.health) * 0.04
            self.health = max(0, self.health - 2)
            self.cooldowns["attack"] = 1.0
            if predator.health <= 0:
                self.hunger = clamp(self.hunger - 20, 0, 100)
                self.happiness = clamp(self.happiness + 6, 0, 100)

        if (
            action == "Raid land"
            and enemy_land is not None
            and self.pos.distance_to(enemy_land.pos) < enemy_land.radius
            and self.cooldowns.get("raid", 0) == 0
            and sum(
                territory.owner_id == self.person_id for territory in territories
            ) < MAX_TERRITORIES_PER_PERSON
        ):
            damage = 18 * self.strength_gene / (1 + enemy_land.fortification * 0.45)
            enemy_land.durability = max(0, enemy_land.durability - damage)
            self.cooldowns["raid"] = 1.1
            if enemy_land.durability <= 0:
                enemy_land.owner_id = self.person_id
                enemy_land.clan_id = self.clan_id
                enemy_land.durability = 100
                enemy_land.home_level = max(0, enemy_land.home_level - 1)
                self.happiness = clamp(self.happiness + 12, 0, 100)
                if active_war is not None:
                    active_war.captures += 1
                world_news.append(
                    (
                        f"War capture: {self.name} seized a rival clan's territory.",
                        "War",
                    )
                )

        if action == "Claim land" and not self.action_used and self.cooldowns.get("claim", 0) == 0:
            clear = self.claim_goal is not None and all(
                self.claim_goal.distance_to(territory.pos) > territory.radius + 55
                for territory in territories
            )
            if (
                self.wood >= 2 and self.stone >= 1 and clear
                and self.pos.distance_to(self.claim_goal) < 42
            ):
                self.wood -= 2
                self.stone -= 1
                territory = Territory(
                    self.person_id,
                    (
                        getattr(self, "country_id", None)
                        if getattr(self, "country_id", None) is not None
                        else self.clan_id
                    ),
                    pygame.Vector2(self.claim_goal),
                    gang_id=self.gang_id,
                    territory_id=max(
                        (
                            item.territory_id
                            for item in territories
                        ),
                        default=0,
                    ) + 1,
                )
                territories.append(territory)
                self.home_id = territory.territory_id
                self.claim_goal = None
                self.cooldowns["claim"] = 25
                self.action_used = True

        if action == "Reject advance" and mate is not None and mate_distance < 48:
            self.rejected_people.add(mate.person_id)
            mate.rejected_people.add(self.person_id)
            self.romantic_interest.pop(mate.person_id, None)
            mate.romantic_interest.pop(self.person_id, None)
            self.bonds.pop(mate.person_id, None)
            mate.bonds.pop(self.person_id, None)
            self.happiness = clamp(self.happiness + 1, 0, 100)
            self.action_used = True

        if home is not None and home_distance < 55 and not self.action_used:
            if action == "Craft" and craft_choice is not None:
                self.spend(CRAFT_COSTS[craft_choice])
                self.inventory[craft_choice] = self.inventory.get(craft_choice, 0) + 1
                self.pending_reward += 0.15
                self.action_used = True
            elif action == "Craft weapon" and weapon_choice is not None:
                self.spend(CRAFT_COSTS[weapon_choice])
                self.items[weapon_choice] = 1
                self.pending_reward += 0.25
                self.action_used = True
                world_news.append(
                    (f"Person #{self.person_id} crafted a {weapon_choice}.", "Development")
                )
            elif action == "Build vehicle" and vehicle_choice is not None:
                self.spend(CRAFT_COSTS[vehicle_choice])
                self.inventory[vehicle_choice] = 1
                self.pending_reward += 0.35
                self.action_used = True
                world_news.append(
                    (f"Person #{self.person_id} built a {vehicle_choice}.", "Development")
                )
            elif action == "Farm" and has_farm and home.farm_food >= 1:
                harvested = min(3, int(home.farm_food))
                home.farm_food -= harvested
                self.food += harvested
                self.action_used = True
            elif action == "Produce electronics" and self.can_afford(CRAFT_COSTS["electronics"]):
                buildings = home.buildings or {}
                if buildings.get("electronics lab", 0):
                    self.spend(CRAFT_COSTS["electronics"])
                    self.inventory["electronics"] = self.inventory.get("electronics", 0) + 1
                    self.action_used = True
            elif action == "Start company":
                if (
                    home.home_level >= 3
                    and (home.buildings or {}).get("electronics lab", 0)
                    and self.can_afford(BUILDING_COSTS["company"])
                    and self.construction_permitted(
                        home, "company", countries,
                        construction_requests, world_time,
                    )
                ):
                    self.spend(BUILDING_COSTS["company"])
                    if home.buildings is None:
                        home.buildings = {}
                    home.buildings["company"] = 1
                    self.action_used = True

        if home is not None and home_distance < 55 and not self.action_used:
            if (
                action == "Build home"
                and home.home_level == 0
                and self.wood >= 5
                and self.stone >= 2
                and self.construction_permitted(
                    home, "house", countries,
                    construction_requests, world_time,
                )
            ):
                self.wood -= 5
                self.stone -= 2
                home.home_level = 1
                self.action_used = True
            elif (
                action == "Upgrade home"
                and 0 < home.home_level < len(BUILDING_LEVEL_NAMES)
                and self.wood >= 3 + home.home_level * 2
                and self.stone >= 2 + home.home_level
                and self.construction_permitted(
                    home, "home upgrade", countries,
                    construction_requests, world_time,
                )
            ):
                self.wood -= 3 + home.home_level * 2
                self.stone -= 2 + home.home_level
                home.home_level += 1
                self.action_used = True
                world_news.append(
                    (f"Home upgrade: person #{self.person_id} reached level {home.home_level}.", "Development")
                )
            elif (
                action == "Fortify"
                and home.fortification < 3
                and self.wood >= 3
                and self.stone >= 3
                and self.construction_permitted(
                    home, "fortification", countries,
                    construction_requests, world_time,
                )
            ):
                self.wood -= 3
                self.stone -= 3
                home.fortification += 1
                self.action_used = True

        if action in ("Work", "Build power line") and not self.action_used:
            self.work_timer += dt
            if self.work_timer >= 1.5:
                self.work_timer = 0
                if (
                    action != "Build power line"
                    or power_target is None
                    or self.construction_permitted(
                        power_target,
                        "power line",
                        countries,
                        construction_requests,
                        world_time,
                    )
                ):
                    self.action_used = self.work_shift(
                        territories,
                        workplace,
                        food,
                        wood_source,
                        stone_source,
                        power_source,
                        power_target,
                        power_lines,
                        deliveries,
                        world_news,
                    )

        if (
            action == "Fight rival" and rival is not None
            and rival_distance < self.weapon_reach()
            and self.cooldowns.get("attack", 0) == 0
        ):
            damage = 6 * self.strength_gene * self.weapon_strength()
            rival.health = max(0, rival.health - damage)
            self.pending_reward += damage * 0.04
            self.health = max(0, self.health - 0.75)
            self.happiness = clamp(self.happiness - 1, 0, 100)
            self.cooldowns["attack"] = 2.0

        if (
            action == "Brawl"
            and rival is not None
            and rival_distance < self.weapon_reach()
            and self.cooldowns.get("brawl", 0) == 0
        ):
            damage = (
                5 + 5 * self.aggression_trait * self.strength_gene
            ) * self.weapon_strength()
            rival.health = max(0, rival.health - damage)
            self.health = max(0, self.health - 1)
            self.happiness = clamp(self.happiness - 1, 0, 100)
            self.cooldowns["brawl"] = 1.5
            self.pending_reward += damage * 0.015 * self.aggression_trait
            world_news.append(
                (f"Brawl: person #{self.person_id} fought person #{rival.person_id}.", "Crime")
            )

        if (
            action == "Rob"
            and bank_land is not None
            and bank_distance < bank_land.radius
            and bank_distance <= rob_distance
            and self.cooldowns.get("rob", 0) == 0
        ):
            stolen_cash = min(bank_land.vault_cash, random.randint(2, 8))
            bank_land.vault_cash -= stolen_cash
            self.cash += stolen_cash
            self.crimes_committed += 1
            self.cooldowns["rob"] = 8
            if bank_land.gang_id is not None:
                bank_gang = next(
                    (gang for gang in gangs if gang.gang_id == bank_land.gang_id),
                    None,
                )
                if bank_gang is not None:
                    bank_gang.reputation += 2
            world_news.append(
                (f"Bank robbery: person #{self.person_id} stole {stolen_cash} coins from plot #{territories.index(bank_land) + 1}.", "Crime")
            )

        if (
            action in ("Rob", "Extort")
            and rob_target is not None
            and rob_distance < 38
            and not (
                action == "Rob"
                and bank_land is not None
                and bank_distance <= rob_distance
            )
            and self.cooldowns.get("rob", 0) == 0
        ):
            stolen_cash = min(rob_target.cash, random.randint(1, 4))
            rob_target.cash -= stolen_cash
            self.cash += stolen_cash
            if stolen_cash == 0:
                for resource_name in ("food", "wood", "stone"):
                    available = rob_target.amount(resource_name)
                    if available > 0:
                        stolen = min(available, random.randint(1, 2))
                        rob_target.add_resource(resource_name, -stolen)
                        self.add_resource(resource_name, stolen)
                        break
            if current_gang is not None:
                tribute = min(self.cash, max(1, stolen_cash // 2))
                self.cash -= tribute
                current_gang.cash += tribute
                current_gang.reputation += 1
            self.crimes_committed += 1
            self.cooldowns["rob"] = 5
            self.happiness = clamp(self.happiness + 1, 0, 100)
            label = "Extortion" if action == "Extort" else "Robbery"
            world_news.append(
                (f"{label}: person #{self.person_id} targeted person #{rob_target.person_id}.", "Crime")
            )

        if action == "Form gang" and self.gang_id is None and self.criminality_trait > 0.75:
            gang_id = max((gang.gang_id for gang in gangs), default=0) + 1
            base_name = random.choice(GANG_NAMES)
            name = base_name if not any(gang.name == base_name for gang in gangs) else f"{base_name} {gang_id}"
            gangs.append(Gang(gang_id, name, self.clan_id, {self.person_id}))
            self.gang_id = gang_id
            for territory in territories:
                if territory.owner_id == self.person_id:
                    territory.gang_id = gang_id
            world_news.append((f"New gang formed: {name} (person #{self.person_id}).", "Crime"))
            self.action_used = True

        if (
            action == "Join gang"
            and self.gang_id is None
            and gang_target is not None
            and nearest_gang_member is not None
            and gang_member_distance < 42
        ):
            self.gang_id = gang_target.gang_id
            gang_target.member_ids.add(self.person_id)
            for territory in territories:
                if territory.owner_id == self.person_id:
                    territory.gang_id = self.gang_id
            world_news.append((f"Person #{self.person_id} joined {gang_target.name}.", "Crime"))
            self.action_used = True

        if action in ("Celebrate", "Mourn") and social_event is not None:
            if self.pos.distance_to(social_event.pos) < 38:
                if social_event.attendees is None:
                    social_event.attendees = set()
                social_event.attendees.add(self.person_id)
                if action == "Celebrate":
                    self.happiness = clamp(self.happiness + 8, 0, 100)
                    self.energy = clamp(self.energy - 2, 0, 100)
                    event_name = {
                        "birthday": social_event.title,
                        "weekend": social_event.title,
                    }.get(social_event.kind, social_event.title)
                    world_news.append(
                        (
                            f"{self.name} celebrated at {event_name}.",
                            "Community",
                        )
                    )
                else:
                    self.happiness = clamp(self.happiness + 2, 0, 100)
                    world_news.append(
                        (f"{self.name} attended {social_event.title}.", "Community")
                    )
                self.action_used = True

        for gang in gangs:
            if not gang.cartel and len(gang.member_ids) >= 3 and gang.cash >= 25:
                gang.cartel = True
                world_news.append((f"{gang.name} has grown into a cartel.", "Crime"))

        if (rival is not None and rival_distance < 42) or (
            predator is not None and predator_distance < 100
        ):
            fear_rate = 16 if "Anxiety" in self.syndromes else 12
            self.fear = clamp(self.fear + fear_rate * dt, 0, 100)
        else:
            self.fear = clamp(self.fear - 5 * dt, 0, 100)

        if self.hunger > 90:
            self.health = clamp(self.health - 1.1 * dt, 0, 100)
            self.happiness = clamp(self.happiness - 1.5 * dt, 0, 100)
        if self.health < 100 and self.hunger < 70:
            recovery = 0.9 if predator_distance > 120 and rival_distance > 80 else 0.35
            self.health = clamp(self.health + recovery * dt, 0, 100)

        if self.health <= 0:
            self.state = "Dead"

    def draw(self, surface: pygame.Surface, screen_pos: pygame.Vector2) -> None:
        center = (round(screen_pos.x), round(screen_pos.y))
        forward = (
            self.heading.normalize()
            if self.heading.length_squared() > 0.001
            else pygame.Vector2(1, 0)
        )
        side = forward.rotate(90)

        def screen_point(offset: pygame.Vector2) -> tuple[int, int]:
            point = pygame.Vector2(center) + offset
            return round(point.x), round(point.y)

        vehicle = (
            "car" if self.inventory.get("car", 0)
            else "cart" if self.inventory.get("cart", 0)
            else None
        )
        if vehicle is not None:
            vehicle_center = pygame.Vector2(center) - forward * 16
            half_length = 12 if vehicle == "car" else 10
            half_width = 7
            corners = [
                vehicle_center + forward * half_length + side * half_width,
                vehicle_center + forward * half_length - side * half_width,
                vehicle_center - forward * half_length - side * half_width,
                vehicle_center - forward * half_length + side * half_width,
            ]
            pygame.draw.polygon(surface, (78, 105, 127), corners)
            pygame.draw.polygon(surface, (43, 62, 76), corners, 2)
            pygame.draw.line(
                surface,
                (193, 221, 225),
                corners[0] * 0.35 + corners[1] * 0.65,
                corners[3] * 0.35 + corners[2] * 0.65,
                2,
            )
            for wheel in (corners[0], corners[1], corners[2], corners[3]):
                pygame.draw.circle(surface, (35, 38, 42), wheel, 2)
        if self.items.get("spear", 0) or self.items.get("bow", 0):
            pygame.draw.line(
                surface,
                (112, 78, 48) if self.items.get("spear", 0) else (101, 69, 46),
                (center[0] - 8, center[1] + 8),
                (center[0] + 9, center[1] - 9),
                2,
            )
            if self.items.get("spear", 0):
                pygame.draw.polygon(
                    surface,
                    (191, 199, 205),
                    [(center[0] + 10, center[1] - 11),
                     (center[0] + 8, center[1] - 5),
                     (center[0] + 5, center[1] - 8)],
                )
            else:
                pygame.draw.arc(
                    surface,
                    (112, 78, 48),
                    (center[0] - 6, center[1] - 8, 15, 17),
                    -1.2,
                    1.2,
                    2,
                )
        coat = (27, 29, 34) if self.is_president else self.color
        trouser = (38, 42, 48) if self.is_president else (74, 79, 84)
        skin = (232, 190, 155)
        shoulder = pygame.Vector2(center) - forward * 1
        torso_points = [
            shoulder + forward * 7 + side * 6,
            shoulder + forward * 5 - side * 6,
            shoulder - forward * 5 - side * 5,
            shoulder - forward * 6 + side * 5,
        ]
        torso_points = [(round(point.x), round(point.y)) for point in torso_points]
        pygame.draw.polygon(surface, coat, torso_points)
        pygame.draw.polygon(surface, (43, 48, 53), torso_points, 1)

        for leg_side in (-1, 1):
            hip = shoulder - forward * 5 + side * (leg_side * 3)
            knee = hip - forward * 5 + side * (leg_side * 2)
            foot = knee - forward * 3
            pygame.draw.line(surface, trouser, screen_point(hip - pygame.Vector2(center)), screen_point(knee - pygame.Vector2(center)), 3)
            pygame.draw.line(surface, (48, 43, 39), screen_point(knee - pygame.Vector2(center)), screen_point(foot - pygame.Vector2(center)), 2)
            pygame.draw.circle(surface, (44, 42, 39), screen_point(foot - pygame.Vector2(center)), 2)

        for arm_side in (-1, 1):
            shoulder_point = shoulder + side * (arm_side * 5)
            elbow = shoulder_point + forward * 1 + side * (arm_side * 3)
            hand = elbow + forward * 4
            pygame.draw.line(surface, coat, screen_point(shoulder_point - pygame.Vector2(center)), screen_point(elbow - pygame.Vector2(center)), 3)
            pygame.draw.line(surface, skin, screen_point(elbow - pygame.Vector2(center)), screen_point(hand - pygame.Vector2(center)), 2)
            pygame.draw.circle(surface, skin, screen_point(hand - pygame.Vector2(center)), 2)

        head = shoulder + forward * 9
        head_center = screen_point(head - pygame.Vector2(center))
        pygame.draw.circle(surface, (103, 73, 56), head_center, 5)
        pygame.draw.circle(surface, skin, head_center, 4)
        pygame.draw.circle(
            surface,
            (60, 52, 48),
            screen_point(head - pygame.Vector2(center) + forward * 2),
            1,
        )
        if self.is_president:
            tie_start = screen_point(shoulder + forward * 4 - pygame.Vector2(center))
            tie_end = screen_point(shoulder - forward * 4 - pygame.Vector2(center))
            pygame.draw.line(surface, (197, 50, 54), tie_start, tie_end, 2)
        elif self.inventory.get("clothes", 0):
            pygame.draw.line(
                surface,
                (229, 218, 191),
                screen_point(shoulder + side * 2 - pygame.Vector2(center)),
                screen_point(shoulder - side * 2 - pygame.Vector2(center)),
                1,
            )
        if self.affection > 35:
            pygame.draw.circle(surface, (220, 80, 110), (center[0] + 7, center[1] - 8), 3)


def nearest_resource(
    position: pygame.Vector2,
    resources: list[WorldResource],
    kind: str,
    maximum_distance: float,
) -> tuple[WorldResource | None, float]:
    candidates = [
        resource for resource in resources
        if resource.kind == kind and resource.amount > 0
    ]
    result, distance = nearest(position, candidates, maximum_distance)
    return result, distance  # type: ignore[return-value]


def nearest_human(
    position: pygame.Vector2,
    humans: list[Human],
) -> tuple[Human | None, float]:
    result, distance = nearest(position, humans)
    return result, distance  # type: ignore[return-value]


def nearest_wildlife(
    position: pygame.Vector2,
    wildlife: list[WildAnimal],
    predators: bool,
    maximum_distance: float,
) -> tuple[WildAnimal | None, float]:
    candidates = [
        animal for animal in wildlife if animal.is_predator == predators
    ]
    result, distance = nearest(position, candidates, maximum_distance)
    return result, distance  # type: ignore[return-value]


def nearest_owned_territory(
    position: pygame.Vector2,
    territories: list[Territory],
    owner_id: int,
) -> tuple[Territory | None, float]:
    candidates = [
        territory for territory in territories if territory.owner_id == owner_id
    ]
    result, distance = nearest(position, candidates)
    return result, distance  # type: ignore[return-value]


def nearest_enemy_territory(
    position: pygame.Vector2,
    territories: list[Territory],
    clan_id: int,
) -> tuple[Territory | None, float]:
    candidates = [
        territory for territory in territories if territory.clan_id != clan_id
    ]
    result, distance = nearest(position, candidates)
    return result, distance  # type: ignore[return-value]


def nearest_claim_site(
    position: pygame.Vector2,
    bounds: pygame.Rect,
    territories: list[Territory],
) -> pygame.Vector2 | None:
    candidates: list[pygame.Vector2] = []
    for radius in (175, 270, 390):
        for angle in range(0, 360, 30):
            candidate = position + pygame.Vector2(radius, 0).rotate(angle)
            keep_in_bounds(candidate, bounds, 30)
            if all(
                candidate.distance_to(territory.pos) > territory.radius + 70
                for territory in territories
            ) and biome_at(candidate) != "ocean":
                candidates.append(candidate)
    if not candidates:
        return None
    return min(candidates, key=lambda candidate: position.distance_to(candidate))


def territory_population(territory: Territory, humans: list[Human]) -> int:
    return sum(
        human.health > 0
        and (
            getattr(human, "home_id", None) == territory.territory_id
            or (
                territory.territory_id == 0
                and human.person_id == territory.owner_id
            )
        )
        for human in humans
    )


def keep_in_bounds(position: pygame.Vector2, bounds: pygame.Rect, margin: int) -> None:
    left = bounds.left + margin
    right = max(left, bounds.right - margin)
    top = bounds.top + margin
    bottom = max(top, bounds.bottom - margin)
    if position.x < left or position.x > right:
        position.x = clamp(position.x, left, right)
    if position.y < top or position.y > bottom:
        position.y = clamp(position.y, top, bottom)


def biome_at(position: pygame.Vector2) -> str:
    x, y = position.x / BIOME_MAP_SCALE, position.y / BIOME_MAP_SCALE
    map_width = HUMAN_WORLD_SIZE[0] / BIOME_MAP_SCALE
    map_height = HUMAN_WORLD_SIZE[1] / BIOME_MAP_SCALE
    nx = (x - map_width / 2) / (map_width * 0.49)
    ny = (y - map_height / 2) / (map_height * 0.49)
    coast_noise = (
        math.sin(x * 0.006 + math.sin(y * 0.004) * 2)
        + math.sin(y * 0.008 - x * 0.003)
    ) * 0.025
    island_edge = nx * nx + ny * ny + coast_noise
    if island_edge > 1:
        return "ocean"
    if island_edge > 0.88:
        return "coast"

    def inside(cx: float, cy: float, rx: float, ry: float) -> bool:
        wobble = 1 + math.sin(x * 0.008 + y * 0.004) * 0.08
        return (((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2) < wobble

    if inside(600, 1780, 430, 390) or inside(2650, 620, 340, 310):
        return "mountains"
    if inside(2480, 1700, 470, 370):
        return "desert"
    if inside(1530, 1650, 590, 260):
        return "wetlands"
    if inside(850, 670, 520, 390) or inside(2260, 850, 510, 420):
        return "forest"
    return "plains"


def terrain_tile_surface(world_x: int, world_y: int, tile_size: int) -> pygame.Surface:
    key = (world_x, world_y, tile_size)
    cached = TERRAIN_TILE_CACHE.get(key)
    if cached is not None:
        return cached
    tile = pygame.Surface((tile_size, tile_size))
    biome = biome_at(
        pygame.Vector2(world_x + tile_size / 2, world_y + tile_size / 2)
    )
    tile.fill(BIOME_COLORS[biome])
    center = (tile_size // 2, tile_size // 2)
    scale = tile_size / 80
    if biome == "forest":
        for offset_x, offset_y in ((-15, -8), (9, -10), (0, 13)):
            position = (
                center[0] + round(offset_x * scale),
                center[1] + round(offset_y * scale),
            )
            pygame.draw.circle(tile, (77, 139, 84), position, max(1, round(12 * scale)))
            pygame.draw.circle(
                tile,
                (103, 158, 95),
                (position[0] - round(3 * scale), position[1] - round(4 * scale)),
                max(1, round(5 * scale)),
            )
    elif biome == "mountains":
        pygame.draw.polygon(
            tile,
            (148, 157, 157),
            [
                (center[0] - round(25 * scale), center[1] + round(20 * scale)),
                (center[0] - round(2 * scale), center[1] - round(22 * scale)),
                (center[0] + round(22 * scale), center[1] + round(20 * scale)),
            ],
        )
        pygame.draw.polygon(
            tile,
            (232, 235, 228),
            [
                (center[0] - round(8 * scale), center[1] - round(11 * scale)),
                (center[0] - round(2 * scale), center[1] - round(22 * scale)),
                (center[0] + round(5 * scale), center[1] - round(9 * scale)),
            ],
        )
    elif biome in ("ocean", "wetlands"):
        wave_color = (129, 195, 211) if biome == "ocean" else (130, 180, 164)
        pygame.draw.arc(
            tile,
            wave_color,
            (
                center[0] - round(15 * scale),
                center[1] - round(6 * scale),
                round(30 * scale),
                round(12 * scale),
            ),
            0.2,
            2.8,
            max(1, round(2 * scale)),
        )
    elif biome == "desert":
        pygame.draw.circle(
            tile,
            (198, 173, 120),
            (center[0] + round(15 * scale), center[1] - round(12 * scale)),
            max(1, round(3 * scale)),
        )
    if len(TERRAIN_TILE_CACHE) >= 2048:
        TERRAIN_TILE_CACHE.pop(next(iter(TERRAIN_TILE_CACHE)))
    TERRAIN_TILE_CACHE[key] = tile
    return tile


def nearest_land_position(position: pygame.Vector2) -> pygame.Vector2:
    if biome_at(position) != "ocean":
        return pygame.Vector2(position)
    for radius in range(24, 601, 24):
        for angle in range(0, 360, 15):
            candidate = position + pygame.Vector2(radius, 0).rotate(angle)
            if biome_at(candidate) != "ocean":
                return candidate
    return pygame.Vector2(HUMAN_WORLD_SIZE) / 2


class LifeSimulation:
    def __init__(self) -> None:
        self.worms = [Worm(pygame.Vector2(390, 350))]
        self.insects: list[Insect] = []
        self.predators: list[Predator] = []
        self.mode = "worms"
        self.sidebar_open = True
        self.message = "Your worm is exploring. Click to add food."
        self.message_timer = 4.0
        self.world_bounds = pygame.Rect(0, 0, *HUMAN_WORLD_SIZE)
        self.camera = pygame.Vector2(0, 0)
        self.zoom = 1.0
        self.camera_follow = True
        self.world_time = 0.0
        self.next_small_construction = SMALL_CONSTRUCTION_INTERVAL
        self.next_major_construction = MAJOR_CONSTRUCTION_INTERVAL
        self.next_war_time = WAR_INTERVAL
        self.small_construction_count = 0
        self.wars: list[ClanWar] = []
        self.black_market_unlocked = False
        self.news_items: list[NewsItem] = []
        self.news_open = False
        self.news_scroll = 0
        self.selected_territory_index: int | None = None
        self.land_editing = False
        self.land_edit_points: list[pygame.Vector2] = []
        self.countries: dict[int, Country] = {}
        self.social_events: list[SocialEvent] = []
        self.gangs: list[Gang] = []
        self.news_queue: list[tuple[str, str]] = []
        self.last_calendar_day = -1
        self.selected_human_id = 1
        self.next_human_id = 1
        self.humans: list[Human] = []
        self.resources: list[WorldResource] = []
        self.wildlife: list[WildAnimal] = []
        self.territories: list[Territory] = []
        self.power_lines: list[PowerLine] = []
        self.deliveries: list[Delivery] = []
        self.construction_requests: list[ConstructionRequest] = []
        self.save_path = SAVE_PATH
        self.save_timer = 0.0
        self.save_status = "Auto-save ready"
        self.save_blocked = False
        self.clan_colors = [(65, 130, 205), (205, 91, 75), (143, 104, 190)]
        for clan_id, center_x in enumerate((760, 2440)):
            for index in range(3):
                position = pygame.Vector2(
                    (center_x + random.randint(-100, 100)) * BIOME_MAP_SCALE,
                    (1200 + random.randint(-100, 100)) * BIOME_MAP_SCALE,
                )
                self.humans.append(
                    Human(
                        self.next_human_id,
                        position,
                        clan_id,
                        self.clan_colors[clan_id],
                        gender="girl" if index % 2 == 0 else "boy",
                    )
                )
                self.humans[-1].age = random.uniform(ADULT_AGE + 15, ADULT_AGE + 120)
                self.humans[-1].last_birthday = int(self.humans[-1].age // 60)
                self.next_human_id += 1

        for index in range(48):
            species = ("deer", "rabbit", "boar", "goat")[index % 4]
            biome = {
                "deer": "plains",
                "rabbit": "forest",
                "boar": "wetlands",
                "goat": "mountains",
            }[species]
            self.wildlife.append(
                WildAnimal(
                    species,
                    self.random_world_pos(biome),
                    pygame.Vector2(1, 0).rotate(random.randrange(360)),
                )
            )
        for index in range(14):
            species = ("wolf", "fox", "bear")[index % 3]
            biome = {"wolf": "plains", "fox": "forest", "bear": "mountains"}[species]
            self.wildlife.append(
                WildAnimal(
                    species,
                    self.random_world_pos(biome),
                    pygame.Vector2(1, 0).rotate(random.randrange(360)),
                )
            )

        for _ in range(85):
            self.resources.append(
                WorldResource(self.random_world_pos("forest"), "wood", random.randint(3, 8), 8)
            )
        for _ in range(65):
            self.resources.append(
                WorldResource(self.random_world_pos("mountains"), "stone", random.randint(3, 7), 7)
            )
        for kind, count, maximum, biome in (
            ("ore", 48, 5, "mountains"),
            ("gold", 24, 3, "mountains"),
            ("silicon", 30, 4, "mountains"),
        ):
            for _ in range(count):
                self.resources.append(
                    WorldResource(
                        self.random_world_pos(biome),
                        kind,
                        random.randint(1, maximum),
                        maximum,
                        random.uniform(0, 40),
                    )
                )
        for _ in range(110):
            self.resources.append(
                WorldResource(
                    self.random_world_pos(("plains", "forest", "wetlands")[_ % 3]),
                    "berries",
                    random.randint(2, 6),
                    6,
                    random.uniform(0, 15),
                )
            )

    def random_world_pos(self, preferred_biome: str | None = None) -> pygame.Vector2:
        for _ in range(250):
            position = pygame.Vector2(
                random.randint(50, HUMAN_WORLD_SIZE[0] - 50),
                random.randint(50, HUMAN_WORLD_SIZE[1] - 50),
            )
            biome = biome_at(position)
            if biome != "ocean" and (
                preferred_biome is None or biome == preferred_biome
            ):
                return position
        return pygame.Vector2(HUMAN_WORLD_SIZE) / 2

    def add_news(self, text: str, category: str = "World") -> None:
        self.news_items.append(NewsItem(self.world_time, category, text))
        if len(self.news_items) > 120:
            del self.news_items[:-120]

    def selected_territory(self) -> Territory | None:
        index = self.selected_territory_index
        if index is None or index >= len(self.territories):
            return None
        return self.territories[index]

    def country_for_human(self, human: Human) -> Country | None:
        country_id = getattr(human, "country_id", None)
        if country_id is None:
            country_id = human.clan_id
        return self.countries.get(country_id)

    def reconcile_land_ownership(self) -> None:
        legacy_territory_ids = all(
            getattr(territory, "territory_id", 0) <= 0
            for territory in self.territories
        )
        legacy_homes = {
            human.person_id: getattr(human, "home_id", None)
            for human in self.humans
        }
        used_ids: set[int] = set()
        next_id = 1
        for territory in self.territories:
            if territory.radius > MAX_TERRITORY_RADIUS:
                shrink_territory(
                    territory,
                    territory.radius - MAX_TERRITORY_RADIUS,
                )
            territory_id = getattr(territory, "territory_id", 0)
            if territory_id <= 0 or territory_id in used_ids:
                while next_id in used_ids:
                    next_id += 1
                territory_id = next_id
                next_id += 1
                territory.territory_id = territory_id
            used_ids.add(territory_id)
        if legacy_territory_ids:
            for human in self.humans:
                legacy_owner_id = legacy_homes[human.person_id]
                matching_lands = [
                    territory for territory in self.territories
                    if territory.owner_id == legacy_owner_id
                ]
                if legacy_owner_id is not None and matching_lands:
                    legacy_homes[human.person_id] = min(
                        matching_lands,
                        key=lambda territory: human.pos.distance_to(
                            territory.pos
                        ),
                    ).territory_id

        by_owner: dict[int, list[Territory]] = {}
        for territory in self.territories:
            by_owner.setdefault(territory.owner_id, []).append(territory)
        people = {human.person_id: human for human in self.humans}
        ownership_counts = {
            owner_id: len(lands) for owner_id, lands in by_owner.items()
        }
        for owner_id, lands in by_owner.items():
            if len(lands) <= MAX_TERRITORIES_PER_PERSON:
                continue
            owner = people.get(owner_id)
            lands.sort(
                key=lambda territory: (
                    territory.home_level,
                    sum((territory.buildings or {}).values()),
                    -(owner.pos.distance_to(territory.pos) if owner else 0),
                ),
                reverse=True,
            )
            for territory in lands[MAX_TERRITORIES_PER_PERSON:]:
                recipients = [
                    human for human in self.humans
                    if human.health > 0
                    and human.age >= ADULT_AGE
                    and human.person_id != owner_id
                    and ownership_counts.get(human.person_id, 0)
                    < MAX_TERRITORIES_PER_PERSON
                    and (
                        getattr(human, "country_id", None)
                        if getattr(human, "country_id", None) is not None
                        else human.clan_id
                    ) == territory.clan_id
                ]
                if not recipients:
                    continue
                recipient = min(
                    recipients,
                    key=lambda human: (
                        ownership_counts.get(human.person_id, 0),
                        human.pos.distance_to(territory.pos),
                    ),
                )
                territory.owner_id = recipient.person_id
                ownership_counts[owner_id] -= 1
                ownership_counts[recipient.person_id] = (
                    ownership_counts.get(recipient.person_id, 0) + 1
                )

        for human in self.humans:
            home_id = legacy_homes[human.person_id]
            if home_id is not None and not any(
                territory.territory_id == home_id
                for territory in self.territories
            ):
                legacy_matches = [
                    territory for territory in self.territories
                    if territory.owner_id == home_id
                ]
                if legacy_matches:
                    home_id = min(
                        legacy_matches,
                        key=lambda territory: human.pos.distance_to(territory.pos),
                    ).territory_id
                else:
                    home_id = None
            if home_id is None:
                owned = [
                    territory for territory in self.territories
                    if territory.owner_id == human.person_id
                ]
                if owned:
                    home_id = max(
                        owned,
                        key=lambda territory: (
                            territory.home_level,
                            sum((territory.buildings or {}).values()),
                        ),
                    ).territory_id
                else:
                    country_id = (
                        getattr(human, "country_id", None)
                        if getattr(human, "country_id", None) is not None
                        else human.clan_id
                    )
                    resident_lands = [
                        territory for territory in self.territories
                        if territory.clan_id == country_id
                    ]
                    if resident_lands:
                        home_id = min(
                            resident_lands,
                            key=lambda territory: human.pos.distance_to(
                                territory.pos
                            ),
                        ).territory_id
            human.home_id = home_id
    def join_selected_country(self) -> bool:
        human = self.get_selected_human()
        territory = self.selected_territory()
        if human is None or territory is None:
            self.message = "Select a person and a country's land first."
            self.message_timer = 3
            return False
        country = self.countries.get(territory.clan_id)
        if country is None:
            self.message = "That land has no established country to join yet."
            self.message_timer = 3
            return False
        if getattr(human, "country_id", None) == country.clan_id or (
            getattr(human, "country_id", None) is None
            and human.clan_id == country.clan_id
        ):
            self.message = f"{human.name} already lives in {country.name}."
            self.message_timer = 3
            return False
        old_country = self.country_for_human(human)
        human.country_id = country.clan_id
        human.home_id = territory.territory_id
        self.add_news(
            f"Migration: {human.name} chose to live in {country.name}"
            + (f", leaving {old_country.name}." if old_country else "."),
            "Community",
        )
        self.message = f"{human.name} now lives in {country.name}."
        self.message_timer = 4
        return True

    def review_construction_requests(self) -> None:
        people = {human.person_id: human for human in self.humans}
        for request in self.construction_requests:
            if request.status != "pending":
                continue
            country = self.countries.get(request.country_id)
            if country is None:
                continue
            president = people.get(country.president_id)
            applicant = people.get(request.person_id)
            owns_land = any(
                territory.owner_id == request.territory_owner_id
                for territory in self.territories
            )
            resident = (
                applicant is not None
                and (
                    getattr(applicant, "country_id", None) == country.clan_id
                    or (
                        getattr(applicant, "country_id", None) is None
                        and applicant.clan_id == country.clan_id
                    )
                )
            )
            approved = (
                president is not None
                and president.health > 0
                and applicant is not None
                and applicant.health > 0
                and applicant.age >= ADULT_AGE
                and resident
                and owns_land
            )
            request.status = "approved" if approved else "denied"
            decision = "approved" if approved else "denied"
            name = applicant.name if applicant is not None else f"Person #{request.person_id}"
            president_name = president.name if president is not None else "the government"
            self.add_news(
                f"Building permit: President {president_name} {decision} "
                f"{name}'s request for a {request.building} in {country.name}.",
                "Politics",
            )

    def refresh_power_network(self) -> None:
        generators = [
            territory for territory in self.territories
            if any(
                amount > 0 and building_category(name) in (
                    "power station", "power plant", "solar farm", "wind farm"
                )
                for name, amount in (territory.buildings or {}).items()
            )
        ]
        adjacency: list[set[int]] = [set() for _ in self.territories]
        for line in self.power_lines:
            start_index = next(
                (
                    index for index, territory in enumerate(self.territories)
                    if territory.pos.distance_to(line.start) < 3
                ),
                None,
            )
            end_index = next(
                (
                    index for index, territory in enumerate(self.territories)
                    if territory.pos.distance_to(line.end) < 3
                ),
                None,
            )
            if start_index is not None and end_index is not None:
                adjacency[start_index].add(end_index)
                adjacency[end_index].add(start_index)

        powered_indices = {
            index for index, territory in enumerate(self.territories)
            if any(territory is generator for generator in generators)
        }
        frontier = list(powered_indices)
        while frontier:
            current = frontier.pop()
            for connected in adjacency[current] - powered_indices:
                powered_indices.add(connected)
                frontier.append(connected)
        for index, territory in enumerate(self.territories):
            territory.powered = index in powered_indices

    def update_black_market_unlock(self) -> None:
        if self.black_market_unlocked:
            return
        has_powered_computing = any(
            territory.powered
            and any(
                amount > 0
                and building_category(name) in (
                    "server farm", "data center", "cloud company"
                )
                for name, amount in (territory.buildings or {}).items()
            )
            for territory in self.territories
        )
        total_compute = sum(human.amount("compute") for human in self.humans)
        total_electronics = sum(
            human.amount("electronics") for human in self.humans
        )
        if has_powered_computing and total_compute >= 30 and total_electronics >= 3:
            self.black_market_unlocked = True
            self.add_news(
                "Advanced computing unlocked the black market; powered data networks can now host discreet trades.",
                "Technology",
            )

    def update_wars(self) -> None:
        ongoing: list[ClanWar] = []
        for war in self.wars:
            if self.world_time >= war.ends_at:
                outcome = "The fighting ended in an armistice"
                if war.captures:
                    outcome = f"The attackers captured {war.captures} contested plot(s)"
                self.add_news(
                    f"War ended: {outcome} between Clan {war.attacker_clan + 1} "
                    f"and Clan {war.defender_clan + 1}.",
                    "War",
                )
            else:
                ongoing.append(war)
        self.wars = ongoing
        if self.wars or self.world_time < self.next_war_time:
            return
        eligible_clans = {
            human.clan_id
            for human in self.humans
            if human.health > 0 and human.age >= ADULT_AGE
            and any(
                territory.clan_id == human.clan_id and territory.home_level > 0
                for territory in self.territories
            )
        }
        if len(eligible_clans) < 2:
            self.next_war_time = self.world_time + 60
            return
        clan_sizes = {
            clan_id: sum(
                territory.clan_id == clan_id and territory.home_level > 0
                for territory in self.territories
            )
            for clan_id in eligible_clans
        }
        ordered_clans = sorted(
            eligible_clans,
            key=lambda clan_id: (clan_sizes[clan_id], clan_id),
        )
        attacker = ordered_clans[0]
        defender = ordered_clans[-1]
        self.wars.append(
            ClanWar(
                attacker,
                defender,
                self.world_time,
                self.world_time + WAR_DURATION,
            )
        )
        self.next_war_time = self.world_time + WAR_INTERVAL
        self.add_news(
            f"War declared: Clan {attacker + 1} launched a campaign against Clan {defender + 1}. "
            "Raiders are targeting enemy territory.",
            "War",
        )

    def build_small_structure(self) -> bool:
        candidates = sorted(
            (
                territory for territory in self.territories
                if territory.home_level > 0
            ),
            key=lambda territory: sum((territory.buildings or {}).values()),
        )
        for home in candidates:
            builder = next(
                (
                    human for human in self.humans
                    if human.person_id == home.owner_id and human.health > 0
                ),
                None,
            )
            if builder is None:
                continue
            for offset in range(len(SMALL_BUILDINGS)):
                index = (
                    self.small_construction_count + offset
                ) % len(SMALL_BUILDINGS)
                building = SMALL_BUILDINGS[index]
                costs = building_costs(building)
                if not builder.can_afford(costs):
                    continue
                if not builder.construction_permitted(
                    home,
                    building,
                    self.countries,
                    self.construction_requests,
                    self.world_time,
                ):
                    return False
                builder.spend(costs)
                if home.buildings is None:
                    home.buildings = {}
                home.buildings[building] = home.buildings.get(building, 0) + 1
                self.small_construction_count = index + 1
                self.add_news(
                    f"Small construction: {builder.name} built a {building} on their land.",
                    "Development",
                )
                return True
        return False

    def build_major_structure(self) -> bool:
        homes = sorted(
            (
                territory for territory in self.territories
                if territory.home_level > 0
            ),
            key=lambda territory: sum((territory.buildings or {}).values()),
        )
        for home in homes:
            builder = next(
                (
                    human for human in self.humans
                    if human.person_id == home.owner_id and human.health > 0
                ),
                None,
            )
            if builder is None:
                continue
            building = builder.choose_building(
                home,
                self.black_market_unlocked,
                major_only=True,
            )
            if building is None:
                continue
            if not builder.construction_permitted(
                home,
                building,
                self.countries,
                self.construction_requests,
                self.world_time,
            ):
                return False
            builder.spend(building_costs(building))
            if home.buildings is None:
                home.buildings = {}
            home.buildings[building] = 1
            old_radius = home.radius
            if home.radius < MAX_TERRITORY_RADIUS:
                expand_territory(
                    home,
                    min(16, MAX_TERRITORY_RADIUS - home.radius),
                )
            self.add_news(
                f"Major construction: {builder.name} built a {building}; "
                f"their claimed territory expanded from {old_radius} to {home.radius}.",
                "Development",
            )
            return True
        return False

    def update_construction_schedule(self) -> None:
        while self.world_time >= self.next_small_construction:
            self.next_small_construction += SMALL_CONSTRUCTION_INTERVAL
            self.build_small_structure()
        while self.world_time >= self.next_major_construction:
            self.next_major_construction += MAJOR_CONSTRUCTION_INTERVAL
            self.build_major_structure()

    def update_deliveries(self, dt: float) -> None:
        remaining: list[Delivery] = []
        for delivery in self.deliveries:
            distance = delivery.start.distance_to(delivery.end)
            delivery.progress = min(
                1.0,
                delivery.progress + dt * 150 / max(distance, 1),
            )
            if delivery.progress < 1:
                remaining.append(delivery)
                continue
            recipient = next(
                (person for person in self.humans if person.person_id == delivery.target_owner_id),
                None,
            )
            if recipient is not None:
                if delivery.cargo == "food":
                    recipient.food += delivery.amount
                else:
                    recipient.add_resource(delivery.cargo, delivery.amount)
                self.add_news(
                    f"Delivery complete: {recipient.name} received {delivery.amount} "
                    f"{delivery.cargo} from plot #{delivery.source_owner_id}.",
                    "Industry",
                )
        self.deliveries = remaining

    def inspect_territory_at(self, position: pygame.Vector2) -> bool:
        candidates = [
            territory for territory in self.territories
            if territory_contains(territory, position)
        ]
        if not candidates:
            self.selected_territory_index = None
            return False
        territory = min(candidates, key=lambda item: position.distance_to(item.pos))
        self.selected_territory_index = self.territories.index(territory)
        return True

    def update_countries(self) -> None:
        for clan_id in sorted({territory.clan_id for territory in self.territories}):
            clan_territories = [
                territory for territory in self.territories
                if territory.clan_id == clan_id
            ]
            adults = [
                human for human in self.humans
                if (
                    getattr(human, "country_id", None)
                    if getattr(human, "country_id", None) is not None
                    else human.clan_id
                ) == clan_id
                and human.age >= ADULT_AGE
                and human.health > 0
            ]
            founders = [
                human for human in adults
                if any(
                    territory.owner_id == human.person_id
                    for territory in clan_territories
                )
            ]
            country = self.countries.get(clan_id)
            if country is None:
                if len(clan_territories) < 2 or not founders:
                    continue
                faiths = (
                    "The Way of the Ancestors", "The Living Earth", "The Open Sky",
                    "The Lantern Path", "The River Covenant", "The First Garden",
                    "The Turning Seasons", "The Quiet Stars",
                )
                used_names = {item.name for item in self.countries.values()}
                used_faiths = {item.religion for item in self.countries.values()}
                name = generate_country_name(clan_territories, used_names)
                religion = next(
                    (
                        faith for faith in faiths
                        if faith not in used_faiths
                    ),
                    f"Clan {clan_id + 1} Tradition",
                )
                president = max(
                    founders,
                    key=lambda human: (
                        human.happiness + human.health * 0.4
                        + human.independence_trait * 10
                        + human.work_experience * 0.1
                    ),
                )
                country = Country(
                    clan_id,
                    name,
                    religion,
                    random.choice(
                        ("care for neighbors", "respect for nature",
                         "honor for elders", "curiosity and learning")
                    ),
                    president.person_id,
                    self.world_time,
                    self.world_time + 600,
                )
                self.countries[clan_id] = country
                self.add_news(
                    f"Nation founded: {name} formed from Clan {clan_id + 1}; "
                    f"{president.name} was elected president, and its people follow {religion}.",
                    "Politics",
                )
            candidates = [
                human for human in adults
                if any(
                    territory.owner_id == human.person_id
                    for territory in clan_territories
                )
            ]
            if not candidates:
                continue
            current_president_alive = any(
                human.person_id == country.president_id
                for human in candidates
            )
            if self.world_time >= country.next_election or not current_president_alive:
                elected = max(
                    candidates,
                    key=lambda human: (
                        human.happiness + human.health * 0.4
                        + human.independence_trait * 10
                        + human.work_experience * 0.1
                    ),
                )
                if elected.person_id != country.president_id:
                    country.president_id = elected.person_id
                    self.add_news(
                        f"Election: {elected.name} became president of {country.name}.",
                        "Politics",
                    )
                country.next_election = self.world_time + 600
        president_ids = {
            country.president_id for country in self.countries.values()
        }
        for human in self.humans:
            human.is_president = human.person_id in president_ids

    def expand_selected_territory(self) -> bool:
        territory = self.selected_territory()
        if territory is None:
            self.message = "Select land before expanding it."
            self.message_timer = 3
            return False
        if territory.radius >= MAX_TERRITORY_RADIUS:
            self.message = (
                f"This claim has reached the maximum radius "
                f"({MAX_TERRITORY_RADIUS})."
            )
            self.message_timer = 3
            return False
        owner = next(
            (
                human for human in self.humans
                if human.person_id == territory.owner_id and human.health > 0
            ),
            None,
        )
        if owner is None or owner.wood < 3 or owner.stone < 2:
            self.message = "The landowner needs 3 wood and 2 stone to expand."
            self.message_timer = 3
            return False
        owner.wood -= 3
        owner.stone -= 2
        expand_territory(
            territory,
            min(40, MAX_TERRITORY_RADIUS - territory.radius),
        )
        self.add_news(
            f"Land expansion: {owner.name} enlarged their claim to radius {territory.radius}.",
            "Development",
        )
        self.message = f"Claim expanded to radius {territory.radius}."
        self.message_timer = 3
        return True

    def shrink_selected_territory(self) -> bool:
        territory = self.selected_territory()
        if territory is None:
            self.message = "Select land before shrinking it."
            self.message_timer = 3
            return False
        if not shrink_territory(territory, 30):
            self.message = "This claim is already at its minimum size."
            self.message_timer = 3
            return False
        self.add_news(
            f"Land adjustment: plot #{self.selected_territory_index + 1} "
            f"was reduced to radius {territory.radius}.",
            "Development",
        )
        self.message = f"Claim reduced to radius {territory.radius}."
        self.message_timer = 3
        return True

    def finish_land_edit(self) -> bool:
        territory = self.selected_territory()
        points = self.land_edit_points
        if territory is None or len(points) < 3:
            self.message = "A precise parcel needs at least three boundary points."
            self.message_timer = 3
            return False
        area = sum(
            points[index].x * points[(index + 1) % len(points)].y
            - points[(index + 1) % len(points)].x * points[index].y
            for index in range(len(points))
        )
        if abs(area) < 100:
            self.message = "Those points do not enclose enough land."
            self.message_timer = 3
            return False
        territory.boundary = [pygame.Vector2(point) for point in points]
        self.land_editing = False
        self.land_edit_points.clear()
        self.add_news(
            f"Land survey: plot {self.selected_territory_index + 1} now has a precise boundary.",
            "Development",
        )
        self.message = "Precise land boundary saved."
        self.message_timer = 3
        return True

    def switch_mode(self) -> None:
        self.mode = "humans" if self.mode == "worms" else "worms"
        if self.mode == "humans" and self.humans:
            selected = self.get_selected_human()
            if selected is not None:
                self.camera = selected.pos - pygame.Vector2(400, 350)
                self.clamp_camera(pygame.Rect(0, 0, 800, 700))
        self.message = "Human world: W/A/S/D moves the camera; E adds a descendant." if self.mode == "humans" else "Worm world."
        self.message_timer = 4

    def night_level(self) -> float:
        phase = (self.world_time % DAY_LENGTH) / DAY_LENGTH * math.tau
        return (1 + math.cos(phase)) / 2

    def get_selected_human(self) -> Human | None:
        return next(
            (human for human in self.humans if human.person_id == self.selected_human_id),
            self.humans[0] if self.humans else None,
        )

    def spawn_human(self) -> bool:
        if len(self.humans) >= MAX_HUMANS:
            self.message = f"Population limit reached ({MAX_HUMANS})."
            self.message_timer = 3
            return False
        parent = self.get_selected_human()
        if parent is None:
            self.message = "There are no surviving humans to inherit from."
            self.message_timer = 3
            return False
        position = parent.pos + pygame.Vector2(
            random.randint(-35, 35), random.randint(-35, 35)
        )
        position = nearest_land_position(position)
        keep_in_bounds(position, self.world_bounds, 15)
        child = Human(
            self.next_human_id,
            position,
            parent.clan_id,
            parent.color,
            parent,
        )
        parent_home = next(
            (
                territory for territory in self.territories
                if territory.territory_id == getattr(parent, "home_id", None)
            ),
            None,
        )
        if parent_home is None:
            parent_home = next(
                (
                    territory for territory in self.territories
                    if territory.owner_id == parent.person_id
                ),
                None,
            )
        child.home_id = parent_home.territory_id if parent_home else None
        child.age = 0
        self.next_human_id += 1
        self.humans.append(child)
        self.selected_human_id = child.person_id
        self.camera_follow = True
        self.message = (
            f"Descendant #{child.person_id}, generation {child.generation}: "
            "inherited a mutated brain and traits."
        )
        self.message_timer = 4
        return True

    def spawn_child(self, parents: tuple[Human, Human, pygame.Vector2]) -> bool:
        if len(self.humans) >= MAX_HUMANS:
            return False
        first_parent, second_parent, position = parents
        child = Human(
            self.next_human_id,
            position,
            first_parent.clan_id,
            first_parent.color,
            first_parent,
            second_parent,
        )
        child.pos = nearest_land_position(child.pos)
        parent_home = next(
            (
                territory for territory in self.territories
                if territory.territory_id == getattr(first_parent, "home_id", None)
            ),
            None,
        )
        if parent_home is None:
            parent_home = next(
                (
                    territory for territory in self.territories
                    if territory.owner_id == first_parent.person_id
                ),
                None,
            )
        child.home_id = parent_home.territory_id if parent_home else None
        keep_in_bounds(child.pos, self.world_bounds, 15)
        self.next_human_id += 1
        self.humans.append(child)
        first_parent.children_count += 1
        second_parent.children_count += 1
        self.add_news(
            f"Birth: a child was born to persons #{first_parent.person_id} and #{second_parent.person_id}.",
            "Community",
        )
        self.message = (
            f"A child was born to #{first_parent.person_id} and "
            f"#{second_parent.person_id}."
        )
        self.message_timer = 4
        return True

    def spawn_wildlife(self, position: pygame.Vector2, species: str) -> None:
        keep_in_bounds(position, self.world_bounds, 12)
        position = nearest_land_position(position)
        keep_in_bounds(position, self.world_bounds, 12)
        self.wildlife.append(
            WildAnimal(
                species,
                pygame.Vector2(position),
                pygame.Vector2(1, 0).rotate(random.randrange(360)),
            )
        )
        self.message = f"A {species} entered the world."
        self.message_timer = 2.5

    def clamp_camera(self, viewport: pygame.Rect) -> None:
        visible_width = viewport.width / self.zoom
        visible_height = viewport.height / self.zoom
        self.camera.x = (
            (self.world_bounds.width - visible_width) / 2 - 1
            if visible_width >= self.world_bounds.width - 1e-3
            else clamp(
                self.camera.x, 0, self.world_bounds.width - visible_width
            )
        )
        self.camera.y = (
            (self.world_bounds.height - visible_height) / 2 - 1
            if visible_height >= self.world_bounds.height - 1e-3
            else clamp(
                self.camera.y, 0, self.world_bounds.height - visible_height
            )
        )

    def zoom_at(
        self,
        screen_position: tuple[int, int],
        viewport: pygame.Rect,
        wheel_steps: int,
    ) -> None:
        if wheel_steps == 0:
            return
        previous_zoom = self.zoom
        minimum_zoom = min(
            1.0,
            viewport.width / self.world_bounds.width,
            viewport.height / self.world_bounds.height,
        ) * 0.995
        self.zoom = clamp(
            previous_zoom * (1.15 ** wheel_steps),
            minimum_zoom,
            3.0,
        )
        local_position = pygame.Vector2(screen_position) - viewport.topleft
        self.camera += local_position * (1 / previous_zoom - 1 / self.zoom)
        self.camera_follow = False
        self.clamp_camera(viewport)

    def screen_to_world(
        self,
        screen_position: tuple[int, int],
        viewport: pygame.Rect | None = None,
    ) -> pygame.Vector2:
        local_position = pygame.Vector2(screen_position)
        if viewport is not None:
            local_position -= viewport.topleft
        return self.camera + local_position / self.zoom

    def update_camera(self, viewport: pygame.Rect, dt: float) -> None:
        if not self.camera_follow:
            return
        selected = self.get_selected_human()
        if selected is None:
            return
        target = selected.pos - pygame.Vector2(
            viewport.width / (2 * self.zoom),
            viewport.height / (2 * self.zoom),
        )
        blend = 1 - math.exp(-5 * dt)
        self.camera += (target - self.camera) * blend
        self.clamp_camera(viewport)

    def update_humans(self, dt: float) -> None:
        dt *= HUMAN_SIMULATION_SPEED
        self.world_time += dt
        self.refresh_power_network()
        self.update_countries()
        self.update_wars()
        self.update_black_market_unlock()
        self.update_deliveries(dt)
        calendar_day = int(self.world_time // DAY_LENGTH)
        if calendar_day != self.last_calendar_day:
            self.last_calendar_day = calendar_day
            if calendar_day > 0 and calendar_day % 7 == 5:
                gathering = (
                    sum((human.pos for human in self.humans), pygame.Vector2())
                    / len(self.humans)
                    if self.humans else pygame.Vector2(HUMAN_WORLD_SIZE) / 2
                )
                self.social_events.append(
                    SocialEvent(
                        "weekend",
                        "Weekend festival celebrating the start of the weekend",
                        gathering,
                        None,
                        50,
                    )
                )
                self.add_news(
                    "Weekend festival: neighbors are celebrating the weekend with a community gathering.",
                    "Community",
                )
        births: list[tuple[Human, Human, pygame.Vector2]] = []
        for animal in self.wildlife:
            animal.update(dt, self.world_bounds, self.humans, self.wildlife)
            animal.pos = nearest_land_position(animal.pos)
            keep_in_bounds(animal.pos, self.world_bounds, 12)
        self.wildlife = [
            animal for animal in self.wildlife if animal.health > 0
        ]
        for human in self.humans:
            if human.health > 0:
                human.update(
                    dt,
                    self.world_bounds,
                    self.humans,
                    self.resources,
                    self.territories,
                    self.wildlife,
                    births,
                    self.night_level(),
                    self.social_events,
                    self.gangs,
                    self.news_queue,
                    self.power_lines,
                    self.deliveries,
                    self.wars,
                    self.countries,
                    self.construction_requests,
                    self.world_time,
                )
                birthday = int(human.age // 60)
                if birthday > human.last_birthday:
                    human.last_birthday = birthday
                    if birthday > 0:
                        self.social_events.append(
                            SocialEvent(
                                "birthday",
                                f"{human.name}'s birthday party (turning {birthday})",
                                pygame.Vector2(human.pos),
                                human.person_id,
                                35,
                            )
                        )
                        self.add_news(
                            (
                                f"Birthday party: {human.name} #{human.person_id} "
                                f"is celebrating turning {birthday}; neighbors are invited."
                            ),
                            "Community",
                        )
        self.wildlife = [
            animal for animal in self.wildlife if animal.health > 0
        ]
        for birth in births:
            self.spawn_child(birth)
        dead_people = [human for human in self.humans if human.health <= 0]
        for human in dead_people:
            self.add_news(
                f"Funeral: person #{human.person_id}, {human.name} ({human.nickname}), has died.",
                "Funeral",
            )
            self.social_events.append(
                SocialEvent(
                    "funeral",
                    f"Funeral for {human.name} #{human.person_id}",
                    pygame.Vector2(human.pos),
                    human.person_id,
                    55,
                )
            )
            if human.gang_id is not None:
                gang = next((item for item in self.gangs if item.gang_id == human.gang_id), None)
                if gang is not None:
                    gang.member_ids.discard(human.person_id)
        self.humans = [human for human in self.humans if human.health > 0]
        if self.selected_human_id not in {human.person_id for human in self.humans}:
            if self.humans:
                self.selected_human_id = self.humans[0].person_id
        self.update_construction_schedule()
        self.review_construction_requests()

        for text, category in self.news_queue:
            self.add_news(text, category)
        self.news_queue.clear()
        for event in self.social_events:
            event.timer -= dt
        self.social_events = [
            event for event in self.social_events if event.timer > 0
        ]

        for resource in self.resources:
            if resource.amount < resource.maximum:
                resource.regrow_timer -= dt
                if resource.regrow_timer <= 0:
                    resource.amount += 1
                    resource.regrow_timer = {
                        "berries": 12,
                        "wood": 38,
                        "stone": 75,
                        "ore": 90,
                        "gold": 150,
                        "silicon": 115,
                    }[resource.kind]

    def spawn_position(self, bounds: pygame.Rect) -> pygame.Vector2:
        margin = 30
        return pygame.Vector2(
            random.uniform(bounds.left + margin, max(bounds.left + margin, bounds.right - margin)),
            random.uniform(bounds.top + margin, max(bounds.top + margin, bounds.bottom - margin)),
        )

    def spawn_insect(self, position: pygame.Vector2, bounds: pygame.Rect) -> None:
        if len(self.insects) >= MAX_INSECTS:
            self.message = "The meadow is full of insects already."
        else:
            keep_in_bounds(position, bounds, 12)
            direction = pygame.Vector2(1, 0).rotate(random.randrange(360))
            self.insects.append(Insect(pygame.Vector2(position), direction))
            self.message = "A little insect appeared."
        self.message_timer = 2.0

    def spawn_predator(self, position: pygame.Vector2, bounds: pygame.Rect) -> None:
        if len(self.predators) >= MAX_PREDATORS:
            self.message = "Too many predators are already in the meadow."
        else:
            keep_in_bounds(position, bounds, 20)
            direction = pygame.Vector2(1, 0).rotate(random.randrange(360))
            self.predators.append(Predator(pygame.Vector2(position), direction))
            self.message = "A predator entered the meadow!"
        self.message_timer = 2.2

    def spawn_partner(self, bounds: pygame.Rect) -> None:
        if any(worm.is_partner for worm in self.worms):
            self.message = "Your worm already has a companion."
        elif len(self.worms) >= MAX_WORMS:
            self.message = "There is no room for another worm."
        else:
            main = self.worms[0]
            pos = main.pos + pygame.Vector2(55, 30)
            keep_in_bounds(pos, bounds, SEGMENT_SIZE)
            self.worms.append(Worm(pos, (221, 130, 157), is_partner=True))
            self.message = "A companion arrived. They can grow close over time."
        self.message_timer = 3.2

    def feed_hungry_worms(self) -> int:
        hungry_worms = [
            worm for worm in self.worms if worm.hunger > HUNGRY_THRESHOLD
        ]
        for worm in hungry_worms:
            worm.eat()

        if hungry_worms:
            self.message = f"Fed {len(hungry_worms)} hungry worm(s)."
        else:
            self.message = "Neither worm is hungry right now."
        self.message_timer = 2.5
        return len(hungry_worms)

    def save_game(self, path: Path | None = None) -> bool:
        destination = path or self.save_path
        payload = {
            "version": SAVE_VERSION,
            "state": _encode_save_value(
                {
                    key: value
                    for key, value in vars(self).items()
                    if key not in {"save_path", "save_timer", "save_status"}
                }
            ),
            "random_state": _encode_save_value(random.getstate()),
        }
        temporary = destination.with_suffix(destination.suffix + ".tmp")
        try:
            temporary.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
            temporary.replace(destination)
        except (OSError, TypeError, ValueError) as error:
            self.save_status = f"Save failed: {error}"
            self.message = self.save_status
            self.message_timer = 6
            return False
        self.save_status = "Saved"
        self.save_blocked = False
        self.message = f"World saved to {destination.name}."
        self.message_timer = 3
        return True

    def load_game(self, path: Path | None = None) -> bool:
        source = path or self.save_path
        try:
            payload = json.loads(source.read_text(encoding="utf-8"))
            version = payload["version"]
            if not isinstance(version, int) or version > SAVE_VERSION or version < 1:
                raise ValueError(f"Unsupported save version: {version!r}")
            state = _decode_save_value(payload["state"])
            random_state = _decode_save_value(payload["random_state"])
            if not isinstance(state, dict):
                raise ValueError("The save state must be an object.")
            random.Random().setstate(random_state)
            if version < 2:
                resize_saved_world(state)
            _upgrade_saved_brains(state)
            if not isinstance(state, dict) or not {
                "mode", "world_time", "humans", "resources", "territories"
            }.issubset(state):
                raise ValueError("The save is missing required world data.")
            known_fields = set(vars(self)) - {"save_path", "save_timer", "save_status"}
            self.__dict__.update(
                {key: value for key, value in state.items() if key in known_fields}
            )
            if "next_small_construction" not in state:
                self.next_small_construction = (
                    int(self.world_time // SMALL_CONSTRUCTION_INTERVAL) + 1
                ) * SMALL_CONSTRUCTION_INTERVAL
            if "next_major_construction" not in state:
                self.next_major_construction = (
                    int(self.world_time // MAJOR_CONSTRUCTION_INTERVAL) + 1
                ) * MAJOR_CONSTRUCTION_INTERVAL
            if "next_war_time" not in state:
                self.next_war_time = self.world_time + WAR_INTERVAL
            random.setstate(random_state)
            self.reconcile_land_ownership()
        except FileNotFoundError:
            self.save_status = "No save found"
            self.message = f"No saved world at {source.name}."
            self.message_timer = 5
            return False
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
            self.save_status = f"Load failed: {error}"
            self.save_blocked = True
            self.message = self.save_status
            self.message_timer = 8
            return False
        self.save_timer = 0.0
        self.save_status = "Loaded"
        self.save_blocked = False
        self.message = f"Resumed saved world from {source.name}."
        self.message_timer = 4
        return True

    def _auto_save(self, dt: float) -> None:
        self.save_timer += dt
        if self.save_timer >= 15:
            self.save_timer %= 15
            if not self.save_blocked:
                self.save_game()

    def update(self, dt: float, bounds: pygame.Rect) -> None:
        self.message_timer = max(0, self.message_timer - dt)
        self._auto_save(dt)
        if self.mode == "humans":
            self.update_humans(dt)
            return
        for insect in self.insects:
            insect.update(dt, bounds, self.worms, self.predators)
        for predator in self.predators:
            predator.update(dt, bounds, self.worms)
        for worm in self.worms:
            worm.update(dt, bounds, self.insects, self.predators, self.worms)
        for worm in self.worms[:]:
            if worm.health <= 0:
                self.worms.remove(worm)
                self.message = "A worm's life ended. Press E to welcome a companion."
                self.message_timer = 4
        if not self.worms:
            self.worms.append(Worm(self.spawn_position(bounds)))
            self.message = "A new worm has arrived to keep the meadow going."
            self.message_timer = 4


SAVEABLE_TYPES = {
    item.__name__: item
    for item in (
        NeuralBrain,
        Insect,
        Predator,
        Worm,
        Human,
        WorldResource,
        Territory,
        SocialEvent,
        Gang,
        NewsItem,
        WildAnimal,
        PowerLine,
        Delivery,
        ClanWar,
        Country,
        ConstructionRequest,
    )
}


def _encode_save_value(value: object) -> object:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, pygame.Vector2):
        return {"$type": "Vector2", "x": value.x, "y": value.y}
    if isinstance(value, pygame.Rect):
        return {"$type": "Rect", "values": list(value)}
    if isinstance(value, tuple):
        return {"$type": "tuple", "items": [_encode_save_value(item) for item in value]}
    if isinstance(value, set):
        return {"$type": "set", "items": [_encode_save_value(item) for item in value]}
    if isinstance(value, list):
        return [_encode_save_value(item) for item in value]
    if isinstance(value, dict):
        return {
            "$type": "dict",
            "items": [
                [_encode_save_value(key), _encode_save_value(item)]
                for key, item in value.items()
            ],
        }
    if type(value) in SAVEABLE_TYPES.values():
        return {
            "$type": type(value).__name__,
            "attributes": _encode_save_value(vars(value)),
        }
    raise TypeError(f"Cannot save value of type {type(value).__name__}.")


def _decode_save_value(value: object) -> object:
    if isinstance(value, list):
        return [_decode_save_value(item) for item in value]
    if not isinstance(value, dict):
        return value
    value_type = value.get("$type")
    if value_type == "Vector2":
        return pygame.Vector2(value["x"], value["y"])
    if value_type == "Rect":
        return pygame.Rect(value["values"])
    if value_type == "tuple":
        return tuple(_decode_save_value(item) for item in value["items"])
    if value_type == "set":
        return {_decode_save_value(item) for item in value["items"]}
    if value_type == "dict":
        return {
            _decode_save_value(key): _decode_save_value(item)
            for key, item in value["items"]
        }
    saveable_class = SAVEABLE_TYPES.get(value_type)
    if saveable_class is None:
        raise ValueError(f"Unrecognized saved object type: {value_type!r}.")
    attributes = _decode_save_value(value["attributes"])
    if not isinstance(attributes, dict):
        raise ValueError(f"Saved {value_type} attributes are invalid.")
    if saveable_class is NeuralBrain:
        instance = NeuralBrain(
            attributes.get("input_count", 10),
            tuple(attributes.get("action_names", ACTION_NAMES)),
        )
    elif saveable_class is Worm:
        instance = Worm(
            attributes.get("pos", pygame.Vector2()),
            attributes.get("color", GREEN),
            attributes.get("is_partner", False),
        )
    elif saveable_class is Human:
        instance = Human(
            attributes.get("person_id", 0),
            attributes.get("pos", pygame.Vector2()),
            attributes.get("clan_id", 0),
            attributes.get("color", GIRL_COLOR),
            gender=attributes.get("gender"),
            name=attributes.get("name"),
            nickname=attributes.get("nickname"),
        )
    else:
        known_fields = {field.name for field in fields(saveable_class)}
        instance = saveable_class(
            **{key: item for key, item in attributes.items() if key in known_fields}
        )
    instance.__dict__.update(attributes)
    return instance


def _upgrade_saved_brains(value: object, visited: set[int] | None = None) -> None:
    if visited is None:
        visited = set()
    if id(value) in visited:
        return
    visited.add(id(value))
    if isinstance(value, NeuralBrain):
        target_actions = (
            HUMAN_ACTION_NAMES if value.input_count == 39 else ACTION_NAMES
        )
        old_actions = tuple(value.action_names)
        old_rows = value.output_weights
        old_biases = value.output_biases
        row_by_action = {
            action: old_rows[index]
            for index, action in enumerate(old_actions)
            if index < len(old_rows)
        }
        bias_by_action = {
            action: old_biases[index]
            for index, action in enumerate(old_actions)
            if index < len(old_biases)
        }
        value.output_weights = [
            row_by_action.get(action, [0.0] * value.hidden_count)[:value.hidden_count]
            for action in target_actions
        ]
        for row in value.output_weights:
            row.extend([0.0] * (value.hidden_count - len(row)))
        value.output_biases = [
            bias_by_action.get(action, 0.0) for action in target_actions
        ]
        value.action_names = target_actions
        value.output_count = len(target_actions)
        value.input_count = 39 if target_actions is HUMAN_ACTION_NAMES else 10
        for row in value.input_weights:
            row[:] = (row + [0.0] * value.input_count)[:value.input_count]
        return
    if isinstance(value, Human):
        old_brain = value.brain
        old_actions = tuple(old_brain.action_names)
        old_index = value.action_index
        old_action = (
            old_actions[old_index]
            if 0 <= old_index < len(old_actions)
            else "Explore"
        )
        _upgrade_saved_brains(old_brain, visited)
        value.action_index = (
            value.brain.action_names.index(old_action)
            if old_action in value.brain.action_names
            else 0
        )
        return
    if isinstance(value, Worm):
        old_actions = tuple(value.brain.action_names)
        old_index = value.brain_action
        old_action = (
            old_actions[old_index]
            if 0 <= old_index < len(old_actions)
            else "Explore"
        )
        _upgrade_saved_brains(value.brain, visited)
        value.brain_action = (
            value.brain.action_names.index(old_action)
            if old_action in value.brain.action_names
            else 0
        )
        return
    if isinstance(value, dict):
        for item in value.values():
            _upgrade_saved_brains(item, visited)
    elif isinstance(value, (list, tuple, set)):
        for item in value:
            _upgrade_saved_brains(item, visited)
    elif type(value) in SAVEABLE_TYPES.values():
        for item in vars(value).values():
            _upgrade_saved_brains(item, visited)


def draw_bar(
    surface: pygame.Surface,
    font: pygame.font.Font,
    label: str,
    value: float,
    y: int,
    color: tuple[int, int, int],
    x: int = 24,
) -> int:
    surface.blit(font.render(label, True, MUTED), (x, y))
    surface.blit(font.render(f"{round(value)}%", True, INK), (x + 198, y))
    pygame.draw.rect(surface, LINE, (x, y + 23, 222, 8), border_radius=4)
    pygame.draw.rect(surface, color, (x, y + 23, round(222 * value / 100), 8), border_radius=4)
    return y + 38


def feed_button_rect(surface: pygame.Surface) -> pygame.Rect:
    return pygame.Rect(surface.get_width() - 139, 74, 115, 32)


def mode_button_rect(surface: pygame.Surface) -> pygame.Rect:
    return pygame.Rect(surface.get_width() - SIDEBAR_WIDTH + 24, 74, 98, 32)


def news_button_rect(surface: pygame.Surface) -> pygame.Rect:
    return pygame.Rect(surface.get_width() - SIDEBAR_WIDTH + 132, 74, 112, 32)


def draw_sidebar(
    surface: pygame.Surface,
    font: pygame.font.Font,
    small_font: pygame.font.Font,
    simulation: LifeSimulation,
) -> None:
    panel = pygame.Rect(surface.get_width() - SIDEBAR_WIDTH, 0, SIDEBAR_WIDTH, surface.get_height())
    pygame.draw.rect(surface, PANEL, panel)
    pygame.draw.line(surface, LINE, panel.topleft, panel.bottomleft, 2)
    x = panel.left + 24
    y = 22
    title = "HUMAN WORLD" if simulation.mode == "humans" else "WORM LIFE"
    subtitle = (
        "a simulated society in a large world"
        if simulation.mode == "humans"
        else "a tiny world, learning as it lives"
    )
    surface.blit(font.render(title, True, INK), (x, y))
    surface.blit(small_font.render(subtitle, True, MUTED), (x, y + 29))

    mode_button = mode_button_rect(surface)
    pygame.draw.rect(surface, (58, 112, 165), mode_button, border_radius=6)
    mode_text = small_font.render(
        "Worms" if simulation.mode == "humans" else "Humans",
        True,
        WHITE,
    )
    surface.blit(
        mode_text,
        mode_button.center - pygame.Vector2(mode_text.get_size()) / 2,
    )

    if simulation.mode == "humans":
        news_button = news_button_rect(surface)
        pygame.draw.rect(
            surface,
            (92, 123, 151) if simulation.news_open else (223, 231, 236),
            news_button,
            border_radius=6,
        )
        news_text = small_font.render(
            f"News {len(simulation.news_items)}",
            True,
            WHITE if simulation.news_open else INK,
        )
        surface.blit(
            news_text,
            news_button.center - pygame.Vector2(news_text.get_size()) / 2,
        )
        territory = simulation.selected_territory()
        if territory is not None:
            owner = next(
                (person for person in simulation.humans if person.person_id == territory.owner_id),
                None,
            )
            gang = next(
                (group for group in simulation.gangs if group.gang_id == territory.gang_id),
                None,
            )
            country = simulation.countries.get(territory.clan_id)
            selected_human = simulation.get_selected_human()
            resident_country = (
                simulation.country_for_human(selected_human)
                if selected_human is not None
                else None
            )
            president = next(
                (
                    person for person in simulation.humans
                    if country is not None
                    and person.person_id == country.president_id
                ),
                None,
            )
            title = "LAND INSPECTION"
            surface.blit(font.render(title, True, INK), (x, 126))
            y = 161
            owner_text = (
                f"{owner.name} “{owner.nickname}” · #{owner.person_id}"
                if owner is not None
                else f"Person #{territory.owner_id} (deceased or absent)"
            )
            country_population = sum(
                (
                    getattr(person, "country_id", None)
                    if getattr(person, "country_id", None) is not None
                    else person.clan_id
                )
                == territory.clan_id
                and person.health > 0
                for person in simulation.humans
            )
            details = [
                owner_text,
                f"Clan {territory.clan_id + 1} · Plot {(simulation.selected_territory_index or 0) + 1}",
                f"Home level {territory.home_level} · Fortification {territory.fortification}",
                f"Settlement: {('camp', 'village', 'town', 'city')[territory.settlement_level]}",
                f"Durability {round(territory.durability)}% · Radius {territory.radius}",
                f"Country: {country.name if country else 'not founded yet'}",
                f"Residents: {territory_population(territory, simulation.humans)} · Country: {country_population}",
                f"Religion: {country.religion if country else 'none'}",
                f"President: {president.name if president else 'not elected'}",
                f"Selected person lives in: {resident_country.name if resident_country else 'no country'}",
                f"Permit requests: {sum(request.country_id == territory.clan_id and request.status == 'pending' for request in simulation.construction_requests)} pending",
                f"Gang control: {gang.name if gang else 'none'}",
                f"Bank vault: {territory.vault_cash} coins",
                f"Farm stores: {round(territory.farm_food)} food",
                f"Structures: {sum(territory.buildings.values()) if territory.buildings else 0}",
            ]
            for line in details:
                surface.blit(small_font.render(line, True, MUTED), (x, y))
                y += 21
            surface.blit(small_font.render("Buildings:", True, INK), (x, y))
            y += 23
            building_names = sorted(
                name for name, count in (territory.buildings or {}).items() if count
            )
            if not building_names:
                surface.blit(small_font.render("No built structures yet.", True, MUTED), (x, y))
                y += 22
            for name in building_names[:5]:
                surface.blit(small_font.render(f"• {name}", True, MUTED), (x, y))
                y += 20
            if len(building_names) > 5:
                surface.blit(
                    small_font.render(f"+ {len(building_names) - 5} more", True, MUTED),
                    (x, y),
                )
            surface.blit(
                small_font.render(
                    "Click land · J joins selected person",
                    True,
                    MUTED,
                ),
                (x, surface.get_height() - 80),
            )
            surface.blit(
                small_font.render("- shrink · G expand · P boundary", True, MUTED),
                (x, surface.get_height() - 54),
            )
            surface.blit(
                small_font.render("Enter saves boundary · Esc closes.", True, MUTED),
                (x, surface.get_height() - 32),
            )
            return
        human = simulation.get_selected_human()
        if human is None:
            surface.blit(small_font.render("No humans remain.", True, RED), (x, 126))
            return
        y = 125
        sex_color = GIRL_COLOR if human.gender == "girl" else BOY_COLOR
        pygame.draw.circle(surface, sex_color, (x + 6, y + 10), 6)
        surface.blit(
            font.render(f"{human.name} “{human.nickname}”", True, INK),
            (x + 15, y),
        )
        y += 27
        surface.blit(
            small_font.render(
                f"Person #{human.person_id} · {human.gender} · "
                f"Age {int(human.age // 60)}m {int(human.age % 60)}s",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 24
        surface.blit(
            small_font.render(
                f"{'Night' if simulation.night_level() > 0.55 else 'Day'} · "
                f"generation {human.generation}",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 24
        country = simulation.country_for_human(human)
        surface.blit(
            small_font.render(
                f"Country: {country.name if country else 'not established'}",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 24
        y = draw_bar(surface, small_font, "Hunger", human.hunger, y, GOLD, x)
        y = draw_bar(surface, small_font, "Energy", human.energy, y, (89, 160, 214), x)
        y = draw_bar(surface, small_font, "Health", human.health, y, GREEN, x)
        y = draw_bar(surface, small_font, "Happiness", human.happiness, y, (226, 130, 157), x)
        y = draw_bar(surface, small_font, "Fear", human.fear, y, RED, x)
        y = draw_bar(surface, small_font, "Affection", human.affection, y, (226, 130, 157), x)
        y += 1
        surface.blit(small_font.render(f"Doing now: {human.state}", True, INK), (x, y))
        y += 25
        surface.blit(
            small_font.render(
                f"Clan {human.clan_id + 1} · {human.job}",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 25
        surface.blit(
            small_font.render(
                f"Bag W{human.wood} S{human.stone} O{human.ore} "
                f"G{human.gold} Si{human.silicon} F{human.food} "
                f"C{human.inventory.get('clothes', 0)} "
                f"E{human.inventory.get('electronics', 0)}",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 25
        carried = ", ".join(
            item for item, amount in (*human.items.items(), *human.inventory.items())
            if amount and item in ("spear", "bow", "car", "cart")
        ) or "none"
        surface.blit(
            small_font.render(f"Equipment: {carried}", True, MUTED),
            (x, y),
        )
        y += 23
        owned = sum(1 for territory in simulation.territories if territory.owner_id == human.person_id)
        clan_land = sum(1 for territory in simulation.territories if territory.clan_id == human.clan_id)
        home_level = max(
            (territory.home_level for territory in simulation.territories
             if territory.owner_id == human.person_id),
            default=0,
        )
        fortification = max(
            (territory.fortification for territory in simulation.territories
             if territory.owner_id == human.person_id),
            default=0,
        )
        surface.blit(
            small_font.render(
                f"Land {owned} ({clan_land} clan) · Home {home_level} · Fort {fortification}",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 25
        surface.blit(
            small_font.render(f"Neural Q-network updates: {human.brain.learning_steps}", True, MUTED),
            (x, y),
        )
        y += 25
        surface.blit(
            small_font.render(
                f"Traits: focus {human.focus_trait:.1f} · social {human.sociability_trait:.1f}",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 19
        surface.blit(
            small_font.render(
                f"Sensory profile {human.sensory_trait:.1f} · not a diagnosis",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 25
        syndrome_text = ", ".join(human.syndromes) or "none"
        surface.blit(
            small_font.render(
                "Conditions (simulated):",
                True,
                MUTED,
            ),
            (x, y),
        )
        y += 19
        surface.blit(
            small_font.render(syndrome_text, True, MUTED),
            (x, y),
        )
        y += 22
        for line in (
            f"Camera: {'following' if simulation.camera_follow else 'manual'} · F: toggle",
            "WASD: move camera (manual)",
            f"Mouse wheel: zoom · {simulation.zoom:.2f}×",
            "E: descendant · M: switch · N: news",
            "Click person or land: inspect",
            "G: expand selected land · P: precise land",
            "Enter: finish border · Backspace: undo point",
            "Right-click: add a wolf",
        ):
            surface.blit(small_font.render(line, True, MUTED), (x, y))
            y += 22
        surface.blit(
            small_font.render(
                f"Population {len(simulation.humans)} / {MAX_HUMANS}  ·  "
                f"Wildlife {len(simulation.wildlife)}",
                True,
                INK,
            ),
            (x, y + 5),
        )
        return

    button = feed_button_rect(surface)
    can_feed = any(worm.hunger > HUNGRY_THRESHOLD for worm in simulation.worms)
    pygame.draw.rect(surface, GREEN if can_feed else LINE, button, border_radius=6)
    button_text = small_font.render(
        "Feed worms", True, WHITE if can_feed else MUTED
    )
    surface.blit(
        button_text,
        button.center - pygame.Vector2(button_text.get_size()) / 2,
    )
    y = 122

    worm = simulation.worms[0]
    surface.blit(font.render("Main worm", True, INK), (x, y))
    surface.blit(
        small_font.render(f"Age  {int(worm.age // 60)}m {int(worm.age % 60)}s", True, MUTED),
        (x, y + 29),
    )
    y += 68
    y = draw_bar(surface, small_font, "Hunger", worm.hunger, y, GOLD, x)
    y = draw_bar(surface, small_font, "Energy", worm.energy, y, (89, 160, 214), x)
    y = draw_bar(surface, small_font, "Health", worm.health, y, GREEN, x)
    y = draw_bar(surface, small_font, "Happiness", worm.happiness, y, (226, 130, 157), x)
    y = draw_bar(surface, small_font, "Curiosity", worm.curiosity, y, (126, 128, 209), x)
    y = draw_bar(surface, small_font, "Fear", worm.fear, y, RED, x)
    y = draw_bar(surface, small_font, "Affection", worm.affection, y, (226, 130, 157), x)

    y += 2
    surface.blit(small_font.render(f"Feeling: {worm.state}", True, INK), (x, y))
    y += 26
    partner = next((w for w in simulation.worms if w.is_partner), None)
    relationship = "No companion yet" if partner is None else (
        "Growing bond" if worm.affection > 25 else "Getting acquainted"
    )
    surface.blit(small_font.render(f"Relationship: {relationship}", True, MUTED), (x, y))
    y += 24
    surface.blit(
        small_font.render(
            f"Brain: neural Q-net · {worm.brain.learning_steps} learns",
            True,
            MUTED,
        ),
        (x, y),
    )
    y += 24
    surface.blit(small_font.render(f"Insects  {len(simulation.insects)}", True, MUTED), (x, y))
    surface.blit(small_font.render(f"Predators  {len(simulation.predators)}", True, MUTED), (x + 115, y))
    y += 14
    surface.blit(small_font.render("M: worlds · E: companion · Tab: panel", True, MUTED), (x, y))
    surface.blit(small_font.render("F11: fullscreen · Esc: exit fullscreen", True, MUTED), (x, y + 22))
    surface.blit(small_font.render("F5: save · F9: resume saved world", True, MUTED), (x, y + 44))


def draw_world(
    surface: pygame.Surface,
    simulation: LifeSimulation,
    font: pygame.font.Font,
) -> None:
    bounds = pygame.Rect(
        0,
        0,
        surface.get_width() - (SIDEBAR_WIDTH if simulation.sidebar_open else 0),
        surface.get_height(),
    )
    if simulation.mode == "humans":
        draw_human_world(surface, simulation, bounds, font)
        return

    pygame.draw.rect(surface, WHITE, bounds)
    for insect in simulation.insects:
        insect.draw(surface)
    for predator in simulation.predators:
        predator.draw(surface)
    for worm in simulation.worms:
        worm.draw(surface)

    if simulation.message_timer > 0:
        message = font.render(simulation.message, True, INK)
        background = pygame.Surface((message.get_width() + 24, 38), pygame.SRCALPHA)
        background.fill((255, 255, 255, 225))
        surface.blit(background, (16, 14))
        surface.blit(message, (28, 23))


def draw_structure_icon(
    surface: pygame.Surface,
    structure_name: str,
    category: str,
    center: tuple[int, int],
    color: tuple[int, int, int, int],
) -> None:
    x, y = center
    dark = tuple(max(0, component - 45) for component in color[:3]) + (color[3],)
    item_name = structure_name.lower()
    if item_name in ("lamp", "torch", "heater"):
        if item_name == "lamp":
            pygame.draw.line(surface, dark, (x, y + 8), (x, y - 5), 3)
            pygame.draw.line(surface, dark, (x - 6, y + 8), (x + 6, y + 8), 2)
            pygame.draw.polygon(surface, (243, 206, 93, 245), [(x - 6, y - 5), (x + 6, y - 5), (x + 3, y - 11), (x - 3, y - 11)])
            pygame.draw.circle(surface, (255, 230, 139, 90), (x, y - 3), 9)
        elif item_name == "torch":
            pygame.draw.line(surface, dark, (x + 3, y + 8), (x - 2, y - 4), 3)
            pygame.draw.ellipse(surface, (245, 146, 54, 250), (x - 7, y - 12, 10, 13))
            pygame.draw.ellipse(surface, (255, 218, 112, 250), (x - 4, y - 10, 4, 8))
        else:
            pygame.draw.rect(surface, color, (x - 7, y - 6, 14, 14))
            pygame.draw.rect(surface, dark, (x - 9, y + 6, 18, 3))
            pygame.draw.rect(surface, (245, 144, 68, 250), (x - 3, y - 2, 6, 6))
            pygame.draw.line(surface, dark, (x + 5, y - 6), (x + 8, y - 12), 2)
        return
    if item_name == "sofa":
        pygame.draw.rect(surface, dark, (x - 11, y - 4, 22, 12), border_radius=3)
        pygame.draw.rect(surface, color, (x - 9, y - 7, 18, 9), border_radius=3)
        pygame.draw.line(surface, dark, (x - 8, y + 8), (x - 8, y + 11), 2)
        pygame.draw.line(surface, dark, (x + 8, y + 8), (x + 8, y + 11), 2)
        return
    if item_name == "craft table":
        pygame.draw.rect(surface, color, (x - 11, y - 5, 22, 5))
        pygame.draw.line(surface, dark, (x - 8, y), (x - 8, y + 9), 2)
        pygame.draw.line(surface, dark, (x + 8, y), (x + 8, y + 9), 2)
        pygame.draw.line(surface, (192, 201, 202, 245), (x - 3, y - 9), (x + 4, y - 2), 2)
        return
    if category in ("farm", "orchard", "ranch", "park", "cemetery"):
        pygame.draw.ellipse(surface, (126, 91, 58, 210), (x - 11, y + 3, 22, 8))
        if category in ("orchard", "park"):
            pygame.draw.line(surface, dark, (x, y + 4), (x, y - 4), 2)
            pygame.draw.circle(surface, color, (x, y - 5), 6)
        else:
            for row in (-2, 1, 4):
                pygame.draw.line(surface, color, (x - 8, y + row), (x + 8, y + row), 2)
        return
    if category in ("bridge", "harbor"):
        pygame.draw.line(surface, (80, 155, 190, 235), (x - 12, y + 5), (x + 12, y + 5), 3)
        if category == "bridge":
            pygame.draw.arc(surface, color, (x - 9, y - 5, 18, 15), math.pi, math.tau, 3)
            pygame.draw.line(surface, dark, (x - 8, y - 5), (x - 8, y + 4), 2)
            pygame.draw.line(surface, dark, (x + 8, y - 5), (x + 8, y + 4), 2)
        else:
            pygame.draw.polygon(
                surface, color,
                [(x - 9, y + 1), (x + 9, y + 1), (x + 5, y + 6), (x - 5, y + 6)],
            )
            pygame.draw.line(surface, dark, (x, y - 8), (x, y + 1), 2)
            pygame.draw.polygon(surface, (245, 239, 213, 230), [(x, y - 8), (x + 6, y - 1), (x, y - 1)])
        return
    if category in ("windmill", "monument", "town hall", "town center", "temple"):
        if category == "windmill":
            pygame.draw.rect(surface, color, (x - 5, y - 2, 10, 11))
            for dx, dy in ((-9, -9), (9, -9), (-9, 9), (9, 9)):
                pygame.draw.line(surface, dark, (x, y - 4), (x + dx, y + dy), 2)
        elif category == "monument":
            pygame.draw.polygon(surface, color, [(x - 9, y + 7), (x + 9, y + 7), (x + 6, y - 7), (x - 6, y - 7)])
            pygame.draw.ellipse(surface, dark, (x - 9, y + 5, 18, 5))
            pygame.draw.circle(surface, color, (x, y - 8), 3)
        else:
            pygame.draw.rect(surface, color, (x - 10, y - 5, 20, 13))
            pygame.draw.polygon(surface, dark, [(x - 12, y - 5), (x, y - 12), (x + 12, y - 5)])
            for window_x in (-6, 0, 6):
                pygame.draw.rect(surface, (214, 235, 231, 245), (x + window_x - 1, y - 2, 2, 3))
            pygame.draw.rect(surface, dark, (x - 2, y + 1, 4, 7))
        return
    if category in ("market", "shop", "restaurant", "bakery"):
        pygame.draw.rect(surface, color, (x - 10, y - 2, 20, 11))
        pygame.draw.rect(surface, dark, (x - 11, y - 5, 22, 5))
        for awning_x in (-7, -1, 5):
            pygame.draw.line(surface, (245, 235, 213, 235), (x + awning_x, y - 5), (x + awning_x, y - 1), 2)
        pygame.draw.rect(surface, dark, (x - 2, y + 2, 4, 7))
        return
    if category in ("armory", "weaponsmith", "smithy", "workshop", "mine", "quarry"):
        pygame.draw.rect(surface, color, (x - 10, y - 2, 20, 11))
        pygame.draw.polygon(surface, dark, [(x - 12, y - 2), (x - 5, y - 9), (x + 7, y - 9), (x + 12, y - 2)])
        pygame.draw.rect(surface, (241, 183, 91, 245), (x - 3, y + 1, 6, 6))
        if category in ("armory", "weaponsmith"):
            pygame.draw.line(surface, (200, 202, 205, 255), (x - 8, y - 11), (x + 7, y + 4), 2)
        return
    if category in (
        "clinic", "hospital", "pharmacy", "fire station", "firehouse",
        "police station",
    ):
        pygame.draw.rect(surface, color, (x - 11, y - 5, 22, 14))
        pygame.draw.polygon(surface, dark, [(x - 13, y - 5), (x, y - 12), (x + 13, y - 5)])
        pygame.draw.rect(surface, (218, 231, 225, 240), (x - 8, y - 2, 5, 5))
        pygame.draw.rect(surface, dark, (x + 4, y - 2, 5, 11))
        if category in ("clinic", "hospital", "pharmacy"):
            pygame.draw.rect(surface, (240, 246, 232, 255), (x - 1, y - 10, 3, 8))
            pygame.draw.rect(surface, (240, 246, 232, 255), (x - 4, y - 7, 9, 3))
        elif category in ("fire station", "firehouse"):
            pygame.draw.rect(surface, (229, 91, 68, 255), (x - 2, y + 1, 7, 5))
            pygame.draw.circle(surface, (45, 50, 54, 255), (x, y + 7), 2)
            pygame.draw.circle(surface, (45, 50, 54, 255), (x + 5, y + 7), 2)
        else:
            pygame.draw.polygon(surface, (218, 196, 93, 255), [(x, y - 11), (x + 3, y - 7), (x, y - 3), (x - 3, y - 7)])
        return
    if category in ("school", "university", "library", "museum", "courthouse"):
        pygame.draw.rect(surface, color, (x - 12, y - 5, 24, 14))
        pygame.draw.polygon(surface, dark, [(x - 14, y - 5), (x, y - 12), (x + 14, y - 5)])
        pygame.draw.rect(surface, dark, (x - 3, y + 1, 6, 8))
        for column_x in (-8, 8):
            pygame.draw.line(surface, (235, 230, 211, 255), (x + column_x, y - 4), (x + column_x, y + 7), 2)
        pygame.draw.line(surface, dark, (x - 12, y + 9), (x + 12, y + 9), 2)
        if category in ("school", "university"):
            pygame.draw.circle(surface, (239, 209, 99, 255), (x, y - 8), 2)
        elif category == "library":
            pygame.draw.rect(surface, (230, 218, 185, 255), (x - 1, y - 10, 2, 5))
        return
    if category in ("bank", "town hall", "town center", "temple"):
        pygame.draw.rect(surface, color, (x - 12, y - 3, 24, 12))
        pygame.draw.polygon(surface, dark, [(x - 14, y - 3), (x, y - 12), (x + 14, y - 3)])
        for column_x in (-8, -3, 3, 8):
            pygame.draw.line(surface, (238, 231, 211, 255), (x + column_x, y - 2), (x + column_x, y + 7), 2)
        pygame.draw.line(surface, dark, (x - 13, y + 9), (x + 13, y + 9), 2)
        if category == "bank":
            pygame.draw.circle(surface, (235, 196, 81, 255), (x, y - 7), 3)
            pygame.draw.line(surface, dark, (x, y - 9), (x, y - 5), 1)
        return
    if category in ("observatory", "research lab", "radio station"):
        pygame.draw.rect(surface, color, (x - 10, y - 2, 20, 11))
        pygame.draw.rect(surface, dark, (x - 12, y + 7, 24, 2))
        if category == "observatory":
            pygame.draw.arc(surface, (220, 229, 227, 255), (x - 8, y - 11, 16, 15), 0, math.pi, 3)
            pygame.draw.line(surface, dark, (x, y - 5), (x + 6, y - 11), 2)
        else:
            pygame.draw.line(surface, dark, (x + 5, y - 3), (x + 9, y - 13), 2)
            pygame.draw.arc(surface, (226, 238, 233, 255), (x + 4, y - 14, 11, 11), 0.1, 1.7, 1)
            pygame.draw.rect(surface, (210, 230, 235, 245), (x - 6, y, 4, 4))
        return
    if category in ("apartment", "hotel"):
        pygame.draw.rect(surface, color, (x - 9, y - 11, 18, 20))
        pygame.draw.rect(surface, dark, (x - 9, y - 11, 18, 20), 1)
        for row in (-7, -2, 3):
            for col in (-5, 1, 6):
                pygame.draw.rect(surface, (219, 233, 233, 245), (x + col - 1, y + row - 1, 3, 3))
        pygame.draw.rect(surface, dark, (x - 2, y + 4, 4, 5))
        if category == "hotel":
            pygame.draw.circle(surface, (236, 195, 86, 255), (x, y - 13), 3)
        return
    if category in ("stable", "ranch"):
        pygame.draw.rect(surface, (157, 90, 62, 245), (x - 11, y - 3, 22, 12))
        pygame.draw.polygon(surface, dark, [(x - 13, y - 3), (x, y - 12), (x + 13, y - 3)])
        pygame.draw.line(surface, (231, 209, 172, 245), (x - 8, y + 2), (x + 8, y + 2), 2)
        pygame.draw.line(surface, (231, 209, 172, 245), (x - 8, y + 6), (x + 8, y + 6), 2)
        pygame.draw.line(surface, (231, 209, 172, 245), (x - 4, y), (x - 4, y + 8), 2)
        pygame.draw.line(surface, (231, 209, 172, 245), (x + 4, y), (x + 4, y + 8), 2)
        return
    if category in ("power plant", "factory", "garage", "vehicle workshop", "rail station", "depot"):
        pygame.draw.rect(surface, color, (x - 11, y - 4, 22, 13))
        pygame.draw.polygon(surface, dark, [(x - 12, y - 4), (x - 4, y - 10), (x + 3, y - 4), (x + 10, y - 10), (x + 12, y - 4)])
        pygame.draw.rect(surface, dark, (x + 5, y - 12, 4, 8))
        pygame.draw.rect(surface, (218, 227, 225, 235), (x - 7, y, 4, 4))
        pygame.draw.rect(surface, (218, 227, 225, 235), (x, y, 4, 4))
        pygame.draw.rect(surface, dark, (x - 2, y + 2, 4, 7))
        if category in ("garage", "vehicle workshop"):
            pygame.draw.rect(surface, (92, 161, 181, 250), (x + 3, y + 1, 6, 4))
            pygame.draw.circle(surface, dark, (x + 4, y + 6), 1)
            pygame.draw.circle(surface, dark, (x + 8, y + 6), 1)
        return
    if category in ("power station", "substation", "solar farm", "wind farm", "power line"):
        if category == "wind farm":
            pygame.draw.line(surface, dark, (x, y + 9), (x, y - 5), 3)
            pygame.draw.circle(surface, color, (x, y - 5), 2)
            for dx, dy in ((0, -12), (-9, 3), (9, 3)):
                pygame.draw.line(surface, color, (x, y - 5), (x + dx, y - 5 + dy), 3)
        elif category == "solar farm":
            panel = [(x - 11, y - 2), (x + 6, y - 5), (x + 10, y + 4), (x - 8, y + 7)]
            pygame.draw.polygon(surface, (63, 117, 153, 245), panel)
            pygame.draw.lines(surface, dark, True, panel, 2)
            pygame.draw.line(surface, (169, 210, 221, 255), (x - 4, y - 3), (x - 1, y + 6), 1)
            pygame.draw.line(surface, (169, 210, 221, 255), (x + 3, y - 4), (x + 6, y + 5), 1)
            pygame.draw.line(surface, dark, (x - 1, y + 7), (x - 3, y + 10), 2)
            pygame.draw.line(surface, dark, (x + 6, y + 5), (x + 7, y + 9), 2)
        elif category == "power line":
            pygame.draw.line(surface, dark, (x, y - 11), (x, y + 10), 2)
            pygame.draw.line(surface, color, (x - 9, y - 7), (x + 9, y - 7), 2)
            pygame.draw.line(surface, color, (x - 7, y - 2), (x + 7, y - 2), 2)
            for wire_x in (-8, 8):
                pygame.draw.line(surface, dark, (x + wire_x, y - 7), (x + wire_x, y - 3), 1)
            pygame.draw.line(surface, dark, (x - 10, y + 9), (x + 10, y + 9), 2)
        elif category == "substation":
            pygame.draw.rect(surface, color, (x - 11, y + 1, 22, 8))
            for coil_x in (-6, 0, 6):
                pygame.draw.rect(surface, dark, (x + coil_x - 2, y - 5, 4, 6))
                pygame.draw.line(surface, (235, 206, 117, 255), (x + coil_x, y - 9), (x + coil_x, y - 5), 2)
            pygame.draw.line(surface, dark, (x - 12, y - 9), (x + 12, y - 9), 2)
        else:
            pygame.draw.rect(surface, color, (x - 10, y - 2, 20, 11))
            pygame.draw.polygon(surface, dark, [(x - 12, y - 2), (x - 7, y - 8), (x + 5, y - 8), (x + 11, y - 2)])
            pygame.draw.rect(surface, dark, (x + 5, y - 13, 4, 8))
            pygame.draw.rect(surface, (244, 191, 101, 255), (x - 6, y + 1, 4, 4))
            pygame.draw.rect(surface, (244, 191, 101, 255), (x + 1, y + 1, 4, 4))
        return
    if category in ("server farm", "data center", "cloud company", "communications tower", "broadcast studio"):
        if category == "communications tower":
            pygame.draw.line(surface, dark, (x, y - 12), (x, y + 10), 2)
            pygame.draw.line(surface, color, (x - 8, y + 9), (x + 8, y + 9), 2)
            pygame.draw.line(surface, color, (x - 5, y + 3), (x + 5, y + 3), 2)
            pygame.draw.arc(surface, color, (x - 10, y - 12, 20, 16), 0.3, 2.8, 1)
            pygame.draw.arc(surface, color, (x - 6, y - 9, 12, 11), 0.3, 2.8, 1)
        elif category == "cloud company":
            pygame.draw.rect(surface, color, (x - 10, y, 20, 8), border_radius=3)
            for cloud_x, cloud_y, radius in ((x - 5, y - 1, 5), (x + 1, y - 4, 6), (x + 6, y, 4)):
                pygame.draw.circle(surface, color, (cloud_x, cloud_y), radius)
            pygame.draw.rect(surface, dark, (x - 4, y + 4, 8, 5))
            pygame.draw.circle(surface, (116, 188, 208, 255), (x, y + 2), 2)
        else:
            pygame.draw.rect(surface, color, (x - 11, y - 8, 22, 17))
            pygame.draw.rect(surface, dark, (x - 11, y - 8, 22, 17), 2)
            for rack_x in (-6, 0, 6):
                pygame.draw.rect(surface, (48, 65, 75, 255), (x + rack_x - 2, y - 5, 4, 11))
                for light_y in (-3, 1, 4):
                    pygame.draw.circle(surface, (114, 211, 191, 255), (x + rack_x, y + light_y), 1)
            if category == "broadcast studio":
                pygame.draw.line(surface, dark, (x + 6, y - 8), (x + 9, y - 14), 2)
                pygame.draw.circle(surface, (226, 90, 75, 255), (x + 9, y - 14), 2)
        return
    if category in ("delivery depot", "distribution center", "freight yard", "logistics center", "courier hub", "post office"):
        if category in ("delivery depot", "freight yard"):
            pygame.draw.rect(surface, color, (x - 11, y - 2, 13, 10))
            pygame.draw.rect(surface, color, (x + 2, y + 1, 9, 7))
            pygame.draw.rect(surface, dark, (x + 4, y - 1, 5, 5))
            pygame.draw.circle(surface, dark, (x - 5, y + 9), 2)
            pygame.draw.circle(surface, dark, (x + 7, y + 9), 2)
            if category == "freight yard":
                pygame.draw.rect(surface, (202, 177, 115, 255), (x - 10, y - 7, 7, 5))
        elif category in ("courier hub", "post office"):
            pygame.draw.rect(surface, color, (x - 9, y - 6, 18, 15))
            pygame.draw.polygon(surface, dark, [(x - 11, y - 6), (x, y - 12), (x + 11, y - 6)])
            pygame.draw.rect(surface, (232, 210, 151, 255), (x - 4, y - 2, 8, 6))
            pygame.draw.line(surface, dark, (x, y - 2), (x, y + 4), 1)
            if category == "post office":
                pygame.draw.rect(surface, (199, 74, 67, 255), (x + 5, y - 5, 4, 7))
        else:
            pygame.draw.rect(surface, color, (x - 12, y - 6, 24, 15))
            pygame.draw.polygon(surface, dark, [(x - 14, y - 6), (x - 9, y - 12), (x + 12, y - 12), (x + 14, y - 6)])
            for door_x in (-7, 0, 7):
                pygame.draw.rect(surface, dark, (x + door_x - 2, y, 4, 9))
            pygame.draw.line(surface, (230, 215, 164, 255), (x - 9, y - 9), (x + 10, y - 9), 1)
        return
    if category in ("water treatment", "sewage plant", "cold storage", "recycling center"):
        if category in ("water treatment", "sewage plant"):
            for tank_x, radius in ((x - 6, 5), (x + 5, 4)):
                pygame.draw.rect(surface, color, (tank_x - radius, y - 3, radius * 2, 11))
                pygame.draw.ellipse(surface, dark, (tank_x - radius, y - 6, radius * 2, 6))
                pygame.draw.line(surface, (120, 194, 206, 255), (tank_x - radius + 1, y + 2), (tank_x + radius - 1, y + 2), 2)
            pygame.draw.line(surface, dark, (x - 11, y + 8), (x + 11, y + 8), 2)
            pygame.draw.line(surface, color, (x, y - 6), (x, y - 10), 2)
        elif category == "cold storage":
            pygame.draw.rect(surface, color, (x - 10, y - 9, 20, 18))
            pygame.draw.line(surface, (228, 243, 244, 255), (x, y - 6), (x, y + 6), 2)
            pygame.draw.line(surface, (228, 243, 244, 255), (x - 5, y - 3), (x + 5, y + 3), 2)
            pygame.draw.line(surface, (228, 243, 244, 255), (x - 5, y + 3), (x + 5, y - 3), 2)
            pygame.draw.rect(surface, dark, (x - 10, y - 9, 20, 18), 2)
        else:
            pygame.draw.polygon(surface, (91, 166, 112, 255), [(x, y - 11), (x + 10, y + 7), (x - 10, y + 7)], 3)
            pygame.draw.arc(surface, (91, 166, 112, 255), (x - 7, y - 2, 14, 14), 0.2, 2.5, 2)
            pygame.draw.polygon(surface, color, [(x, y - 5), (x + 4, y + 2), (x - 4, y + 2)])
        return
    if category in ("textile mill", "tailor", "battery plant", "electric workshop"):
        pygame.draw.rect(surface, color, (x - 11, y - 3, 22, 12))
        pygame.draw.polygon(surface, dark, [(x - 12, y - 3), (x - 5, y - 10), (x + 4, y - 3), (x + 10, y - 10), (x + 12, y - 3)])
        if category == "battery plant":
            pygame.draw.rect(surface, (54, 65, 69, 255), (x - 7, y - 1, 6, 9))
            pygame.draw.rect(surface, (54, 65, 69, 255), (x + 1, y - 1, 6, 9))
            pygame.draw.rect(surface, (236, 201, 88, 255), (x - 5, y - 4, 2, 3))
            pygame.draw.rect(surface, (236, 201, 88, 255), (x + 3, y - 4, 2, 3))
        elif category == "electric workshop":
            pygame.draw.circle(surface, (224, 193, 91, 255), (x, y + 1), 5, 2)
            pygame.draw.line(surface, (224, 193, 91, 255), (x, y - 4), (x, y + 6), 1)
        elif category == "textile mill":
            for thread_x in (-6, -2, 2, 6):
                pygame.draw.line(surface, (232, 211, 172, 255), (x + thread_x, y - 1), (x + thread_x, y + 7), 1)
            pygame.draw.line(surface, (232, 211, 172, 255), (x - 7, y + 2), (x + 7, y + 2), 1)
            pygame.draw.line(surface, (232, 211, 172, 255), (x - 7, y + 5), (x + 7, y + 5), 1)
        else:
            pygame.draw.rect(surface, (232, 211, 172, 255), (x - 3, y - 1, 6, 7))
            pygame.draw.line(surface, dark, (x - 7, y - 4), (x - 3, y + 1), 2)
            pygame.draw.line(surface, dark, (x + 7, y - 4), (x + 3, y + 1), 2)
        return

    pygame.draw.rect(surface, color, (x - 9, y - 4, 18, 13))
    pygame.draw.polygon(surface, dark, [(x - 11, y - 4), (x, y - 11), (x + 11, y - 4)])
    pygame.draw.rect(surface, (218, 231, 225, 235), (x - 6, y - 2, 4, 4))
    pygame.draw.rect(surface, (218, 231, 225, 235), (x + 2, y - 2, 4, 4))
    pygame.draw.rect(surface, dark, (x - 2, y + 2, 4, 7))


def draw_house_icon(
    surface: pygame.Surface,
    center: tuple[int, int],
    structure_name: str,
    tier: int,
    style: int = 0,
    scale: float = 1.0,
) -> None:
    x, y = center
    category = building_category(structure_name) or "house"
    style_colors = (
        ((211, 183, 142, 255), (133, 74, 57, 255)),
        ((197, 205, 194, 255), (79, 101, 114, 255)),
        ((225, 203, 158, 255), (143, 93, 52, 255)),
        ((205, 179, 157, 255), (111, 73, 91, 255)),
        ((198, 208, 215, 255), (73, 115, 145, 255)),
    )
    walls_color, roof_color = style_colors[(style + tier) % len(style_colors)]
    width = max(18, round((26 + min(tier, 10)) * scale))
    wall_height = max(12, round((15 + (tier >= 4) * 3) * scale))
    wall_rect = pygame.Rect(x - width // 2, y - wall_height // 2, width, wall_height)
    dark_walls = tuple(max(0, c - 45) for c in walls_color[:3]) + (255,)
    dark_roof = tuple(max(0, c - 38) for c in roof_color[:3]) + (255,)
    foundation_y = wall_rect.bottom + max(2, round(2 * scale))
    pygame.draw.ellipse(
        surface,
        (89, 84, 69, 150),
        (x - width // 2 - 3, foundation_y - 2, width + 6, max(4, round(6 * scale))),
    )

    if category in ("cabin", "longhouse"):
        for log_y in range(wall_rect.top + 2, wall_rect.bottom, max(3, round(4 * scale))):
            pygame.draw.line(
                surface,
                dark_walls,
                (wall_rect.left + 1, log_y),
                (wall_rect.right - 1, log_y),
                1,
            )
    pygame.draw.rect(surface, walls_color, wall_rect)
    pygame.draw.rect(surface, dark_walls, wall_rect, max(1, round(scale)))

    roof_top = wall_rect.top - max(4, round(9 * scale))
    roof_left = wall_rect.left - max(3, round(4 * scale))
    roof_right = wall_rect.right + max(3, round(4 * scale))
    if category == "villa" or tier >= 7:
        roof = [
            (roof_left - 2, roof_top + 2),
            (roof_left + 2, roof_top - 2),
            (roof_right - 2, roof_top - 2),
            (roof_right + 2, roof_top + 2),
        ]
    elif category == "townhouse":
        roof = [
            (roof_left, roof_top + 3),
            (x, roof_top - max(3, round(4 * scale))),
            (roof_right, roof_top + 3),
            (roof_right - 2, wall_rect.top + 1),
            (roof_left + 2, wall_rect.top + 1),
        ]
    else:
        roof = [
            (roof_left, roof_top + 3),
            (x, roof_top - max(4, round((8 + tier % 3) * scale))),
            (roof_right, roof_top + 3),
            (roof_right - 2, wall_rect.top + 2),
            (roof_left + 2, wall_rect.top + 2),
        ]
    pygame.draw.polygon(surface, roof_color, roof)
    pygame.draw.lines(surface, dark_roof, True, roof, max(1, round(scale)))

    if category in ("manor", "townhouse", "apartment") or tier >= 5:
        upper_width = round(width * (0.66 if category == "townhouse" else 0.8))
        upper_height = max(6, round(wall_height * 0.55))
        upper = pygame.Rect(
            x - upper_width // 2,
            wall_rect.top - upper_height + 2,
            upper_width,
            upper_height,
        )
        pygame.draw.rect(surface, walls_color, upper)
        pygame.draw.rect(surface, dark_walls, upper, max(1, round(scale)))
        if category == "manor":
            pygame.draw.rect(
                surface,
                walls_color,
                (wall_rect.left - 4, wall_rect.top + 4, 5, wall_height - 3),
            )
            pygame.draw.rect(
                surface,
                walls_color,
                (wall_rect.right - 1, wall_rect.top + 4, 5, wall_height - 3),
            )

    window_color = (130, 190, 204, 255)
    pane_border = (75, 66, 57, 255)
    window_y = wall_rect.top + max(3, wall_height // 3)
    for window_x in (wall_rect.left + max(4, width // 5), wall_rect.right - max(4, width // 5)):
        pygame.draw.rect(surface, pane_border, (window_x - 2, window_y - 2, 5, 6))
        pygame.draw.rect(surface, window_color, (window_x - 1, window_y - 1, 3, 4))
        pygame.draw.line(surface, pane_border, (window_x, window_y - 1), (window_x, window_y + 3), 1)

    door_width = max(4, round(5 * scale))
    door_height = max(7, round(9 * scale))
    door = pygame.Rect(x - door_width // 2, wall_rect.bottom - door_height, door_width, door_height)
    pygame.draw.rect(surface, dark_roof, door)
    pygame.draw.circle(surface, (237, 199, 101, 255), (door.right - 1, door.centery), 1)
    if category in ("villa", "farmhouse", "manor") or tier >= 4:
        porch_y = wall_rect.bottom + 1
        pygame.draw.line(surface, dark_walls, (wall_rect.left - 3, porch_y), (wall_rect.right + 3, porch_y), 2)
        for porch_x in (wall_rect.left - 2, wall_rect.right + 2):
            pygame.draw.line(surface, (238, 225, 202, 255), (porch_x, wall_rect.top + 5), (porch_x, porch_y), 2)

    if category == "farmhouse":
        barn = pygame.Rect(wall_rect.right + 2, wall_rect.bottom - 9, max(7, round(9 * scale)), 8)
        pygame.draw.rect(surface, (153, 86, 62, 255), barn)
        pygame.draw.polygon(
            surface,
            (107, 67, 55, 255),
            [(barn.left - 1, barn.top), (barn.centerx, barn.top - 5), (barn.right + 1, barn.top)],
        )
        pygame.draw.rect(surface, (221, 193, 148, 255), (barn.centerx - 1, barn.centery, 3, 5))
    if category == "villa":
        for pillar_x in (wall_rect.left + 3, wall_rect.right - 3):
            pygame.draw.line(surface, (245, 234, 210, 255), (pillar_x, wall_rect.top + 2), (pillar_x, wall_rect.bottom), 2)
    if category == "cottage":
        pygame.draw.circle(surface, (86, 145, 86, 255), (wall_rect.left - 3, wall_rect.bottom), 4)
        pygame.draw.circle(surface, (103, 158, 95, 255), (wall_rect.right + 3, wall_rect.bottom), 4)
    if tier >= 6:
        chimney_x = wall_rect.right - max(5, width // 5)
        chimney = pygame.Rect(chimney_x, roof_top - 4, 4, max(7, round(9 * scale)))
        pygame.draw.rect(surface, dark_walls, chimney)
        pygame.draw.line(surface, (235, 231, 220, 150), (chimney.centerx, chimney.top - 3), (chimney.centerx + 2, chimney.top - 7), 1)
    if tier >= 9:
        panel = pygame.Rect(x - 4, roof_top - 3, 9, 3)
        pygame.draw.rect(surface, (54, 105, 139, 255), panel)
        pygame.draw.line(surface, (165, 208, 221, 255), (panel.left + 4, panel.top), (panel.left + 4, panel.bottom), 1)


def _draw_human_world_unzoomed(
    surface: pygame.Surface,
    simulation: LifeSimulation,
    viewport: pygame.Rect,
    font: pygame.font.Font,
) -> None:
    previous_clip = surface.get_clip()
    surface.set_clip(viewport)
    terrain_tile = 80
    first_terrain_x = int(simulation.camera.x // terrain_tile) * terrain_tile
    first_terrain_y = int(simulation.camera.y // terrain_tile) * terrain_tile
    for world_y in range(
        first_terrain_y,
        int(simulation.camera.y + viewport.height) + terrain_tile,
        terrain_tile,
    ):
        for world_x in range(
            first_terrain_x,
            int(simulation.camera.x + viewport.width) + terrain_tile,
            terrain_tile,
        ):
            tile_rect = pygame.Rect(
                round(world_x - simulation.camera.x),
                round(world_y - simulation.camera.y),
                terrain_tile + 1,
                terrain_tile + 1,
            )
            surface.blit(
                terrain_tile_surface(world_x, world_y, terrain_tile),
                tile_rect.topleft,
            )
    grid = 200
    first_x = int(simulation.camera.x // grid) * grid
    first_y = int(simulation.camera.y // grid) * grid
    for world_x in range(first_x, int(simulation.camera.x + viewport.width) + grid, grid):
        screen_x = round(world_x - simulation.camera.x)
        pygame.draw.line(surface, (215, 230, 202), (screen_x, 0), (screen_x, viewport.height))
    for world_y in range(first_y, int(simulation.camera.y + viewport.height) + grid, grid):
        screen_y = round(world_y - simulation.camera.y)
        pygame.draw.line(surface, (215, 230, 202), (0, screen_y), (viewport.width, screen_y))

    territory_layer = pygame.Surface(viewport.size, pygame.SRCALPHA)
    labeled_countries: set[int] = set()
    for territory in simulation.territories:
        screen_pos = territory.pos - simulation.camera
        clan_color = simulation.clan_colors[territory.clan_id % len(simulation.clan_colors)]
        boundary_points: list[tuple[int, int]] = []
        if territory.boundary and len(territory.boundary) >= 3:
            boundary_points = [
                (round(point.x - simulation.camera.x), round(point.y - simulation.camera.y))
                for point in territory.boundary
            ]
            pygame.draw.polygon(
                territory_layer, (*clan_color, 28), boundary_points
            )
            pygame.draw.polygon(
                territory_layer, (*clan_color, 175), boundary_points, 2
            )
        else:
            pygame.draw.circle(
                territory_layer,
                (*clan_color, 28),
                (round(screen_pos.x), round(screen_pos.y)),
                territory.radius,
            )
            pygame.draw.circle(
                territory_layer,
                (*clan_color, 145),
                (round(screen_pos.x), round(screen_pos.y)),
                territory.radius,
                2,
            )
        if territory.home_level:
            draw_house_icon(
                territory_layer,
                (round(screen_pos.x), round(screen_pos.y)),
                "House",
                territory.home_level,
                territory.owner_id,
                1.0 + min(territory.home_level, 8) * 0.045,
            )
        buildings = territory.buildings or {}
        building_colors = (
            (164, 104, 76, 240),
            (88, 147, 101, 240),
            (83, 129, 177, 240),
            (184, 145, 62, 240),
            (137, 101, 166, 240),
        )
        visible_buildings = [
            (building, instance)
            for building, amount in buildings.items()
            if amount > 0
            for instance in range(amount)
        ]
        for index, (building, _) in enumerate(visible_buildings):
            category = building_category(building)
            if category is None:
                continue
            category_index = BUILDING_TYPES.index(category)
            icon_center = (
                round(screen_pos.x) - 42 + (index % 4) * 24,
                round(screen_pos.y) + 32 + (index // 4) * 23,
            )
            if category == "house":
                tier = BUILDING_CATALOG.get(building, ("house", 1))[1]
                draw_house_icon(
                    territory_layer,
                    icon_center,
                    building,
                    tier,
                    category_index,
                    0.66 + min(tier, 10) * 0.025,
                )
            else:
                draw_structure_icon(
                    territory_layer,
                    building,
                    category,
                    icon_center,
                    building_colors[category_index % len(building_colors)],
                )
        if simulation.selected_territory() is territory:
            if territory.boundary and len(territory.boundary) >= 3:
                pygame.draw.polygon(
                    territory_layer, (249, 203, 67, 250), boundary_points, 3
                )
            else:
                pygame.draw.circle(
                    territory_layer,
                    (249, 203, 67, 250),
                    (round(screen_pos.x), round(screen_pos.y)),
                    territory.radius + 5,
                    3,
                )
        country = simulation.countries.get(territory.clan_id)
        if (
            country is not None
            and country.clan_id not in labeled_countries
            and viewport.collidepoint(round(screen_pos.x), round(screen_pos.y))
        ):
            label = font.render(country.name, True, INK)
            label_bg = pygame.Surface(
                (label.get_width() + 10, label.get_height() + 4),
                pygame.SRCALPHA,
            )
            label_bg.fill((255, 255, 255, 190))
            label_position = (round(screen_pos.x) + 10, round(screen_pos.y) - 30)
            territory_layer.blit(label_bg, label_position)
            territory_layer.blit(
                label,
                (label_position[0] + 5, label_position[1] + 2),
            )
            labeled_countries.add(country.clan_id)
    surface.blit(territory_layer, viewport.topleft)
    if simulation.land_editing and len(simulation.land_edit_points) > 0:
        edit_points = [
            (
                round(point.x - simulation.camera.x),
                round(point.y - simulation.camera.y),
            )
            for point in simulation.land_edit_points
        ]
        if len(edit_points) > 1:
            pygame.draw.lines(surface, (255, 220, 70), False, edit_points, 3)
        for point in edit_points:
            pygame.draw.circle(surface, (255, 220, 70), point, 5)

    for line in simulation.power_lines:
        start = line.start - simulation.camera
        end = line.end - simulation.camera
        pygame.draw.line(
            surface,
            (77, 76, 64),
            (round(start.x), round(start.y)),
            (round(end.x), round(end.y)),
            3,
        )
        for pole_position in (start, end):
            pole = (round(pole_position.x), round(pole_position.y))
            pygame.draw.line(
                surface, (91, 82, 63), (pole[0], pole[1] - 8), (pole[0], pole[1] + 8), 2
            )
            pygame.draw.line(
                surface, (91, 82, 63), (pole[0] - 4, pole[1] - 5), (pole[0] + 4, pole[1] - 5), 2
            )
    for delivery in simulation.deliveries:
        position = delivery.start.lerp(delivery.end, delivery.progress) - simulation.camera
        center = (round(position.x), round(position.y))
        pygame.draw.circle(surface, (238, 181, 65), center, 5)
        pygame.draw.circle(surface, (92, 75, 43), center, 5, 1)

    for animal in simulation.wildlife:
        screen_pos = animal.pos - simulation.camera
        if viewport.collidepoint(round(screen_pos.x), round(screen_pos.y)):
            animal.draw(surface, screen_pos)

    for resource in simulation.resources:
        screen_pos = resource.pos - simulation.camera
        if not viewport.collidepoint(round(screen_pos.x), round(screen_pos.y)):
            continue
        x, y = round(screen_pos.x), round(screen_pos.y)
        if resource.kind == "wood":
            pygame.draw.rect(surface, (125, 86, 54), (x - 3, y, 6, 12))
            pygame.draw.circle(surface, (69, 135, 75), (x, y - 3), 12)
            pygame.draw.circle(surface, (83, 152, 86), (x - 7, y + 1), 7)
        elif resource.kind == "stone":
            points = [(x - 11, y + 5), (x - 8, y - 6), (x + 1, y - 11), (x + 11, y - 2), (x + 9, y + 7)]
            pygame.draw.polygon(surface, (126, 135, 139), points)
            pygame.draw.polygon(surface, (92, 102, 106), points, 2)
        elif resource.kind == "berries":
            pygame.draw.circle(surface, (88, 146, 83), (x, y), 9)
            for dx, dy in ((-4, -2), (3, -3), (2, 4)):
                pygame.draw.circle(surface, (190, 66, 88), (x + dx, y + dy), 2)
        elif resource.kind == "ore":
            points = [(x - 8, y + 7), (x - 7, y - 5), (x, y - 10), (x + 9, y - 3), (x + 7, y + 7)]
            pygame.draw.polygon(surface, (112, 120, 132), points)
            pygame.draw.line(surface, (197, 200, 202), (x - 4, y - 3), (x + 3, y + 4), 2)
        elif resource.kind == "gold":
            pygame.draw.polygon(
                surface,
                (229, 183, 55),
                [(x - 8, y + 6), (x - 5, y - 6), (x + 3, y - 9), (x + 9, y - 1), (x + 6, y + 7)],
            )
            pygame.draw.circle(surface, (255, 227, 120), (x - 1, y - 2), 2)
        else:
            pygame.draw.polygon(
                surface,
                (108, 183, 204),
                [(x - 7, y + 7), (x - 5, y - 5), (x, y - 11), (x + 6, y - 4), (x + 7, y + 7)],
            )

    for human in simulation.humans:
        screen_pos = human.pos - simulation.camera
        if not viewport.collidepoint(round(screen_pos.x), round(screen_pos.y)):
            continue
        if human.person_id == simulation.selected_human_id:
            pygame.draw.circle(
                surface,
                (246, 190, 55),
                (round(screen_pos.x), round(screen_pos.y)),
                13,
                2,
            )
        human.draw(surface, screen_pos)
        label = font.render(
            f"{human.name} “{human.nickname}”",
            True,
            INK,
        )
        surface.blit(label, (round(screen_pos.x) + 10, round(screen_pos.y) - 7))

    for event in simulation.social_events:
        screen_pos = event.pos - simulation.camera
        if not viewport.collidepoint(round(screen_pos.x), round(screen_pos.y)):
            continue
        color = {
            "funeral": (89, 84, 105),
            "birthday": (228, 163, 63),
            "weekend": (71, 154, 126),
        }.get(event.kind, GOLD)
        pygame.draw.circle(
            surface,
            color,
            (round(screen_pos.x), round(screen_pos.y)),
            12,
            3,
        )

    night = simulation.night_level()
    if night > 0.02:
        tint = pygame.Surface(viewport.size, pygame.SRCALPHA)
        tint.fill((*NIGHT_COLOR, round(95 * night)))
        surface.blit(tint, viewport.topleft)

    hour = int((simulation.world_time % DAY_LENGTH) / DAY_LENGTH * 24)
    minute = int(((simulation.world_time % DAY_LENGTH) / DAY_LENGTH * 24 % 1) * 60)
    time_label = font.render(
        f"{'NIGHT' if night > 0.55 else 'DAY'}  {hour:02d}:{minute:02d}",
        True,
        WHITE,
    )
    time_bg = pygame.Surface((time_label.get_width() + 16, 30), pygame.SRCALPHA)
    time_bg.fill((25, 34, 49, 175))
    surface.blit(time_bg, (viewport.width - time_bg.get_width() - 12, 14))
    surface.blit(time_label, (viewport.width - time_label.get_width() - 20, 20))
    terrain_label = font.render(
        f"{biome_at(simulation.camera + pygame.Vector2(viewport.width / (2 * simulation.zoom), viewport.height / (2 * simulation.zoom))).title()}  ·  "
        f"Save: {simulation.save_status}  ·  F5 save / F9 load",
        True,
        INK,
    )
    terrain_backdrop = pygame.Surface(
        (terrain_label.get_width() + 16, terrain_label.get_height() + 8),
        pygame.SRCALPHA,
    )
    terrain_backdrop.fill((255, 255, 255, 210))
    surface.blit(terrain_backdrop, (12, viewport.height - terrain_backdrop.get_height() - 10))
    surface.blit(terrain_label, (20, viewport.height - terrain_backdrop.get_height() - 6))

    if simulation.message_timer > 0:
        message = font.render(simulation.message, True, INK)
        background = pygame.Surface((message.get_width() + 24, 38), pygame.SRCALPHA)
        background.fill((255, 255, 255, 225))
        surface.blit(background, (16, 14))
        surface.blit(message, (28, 23))
    surface.set_clip(previous_clip)


def _draw_human_world_overview(
    surface: pygame.Surface,
    simulation: LifeSimulation,
    viewport: pygame.Rect,
    font: pygame.font.Font,
) -> None:
    previous_clip = surface.get_clip()
    surface.set_clip(viewport)
    zoom = simulation.zoom
    surface.fill(BIOME_COLORS["ocean"], viewport)
    tile_size = 160
    visible_left = simulation.camera.x
    visible_top = simulation.camera.y
    visible_right = visible_left + viewport.width / zoom
    visible_bottom = visible_top + viewport.height / zoom
    first_x = math.floor(visible_left / tile_size) * tile_size
    first_y = math.floor(visible_top / tile_size) * tile_size
    for world_y in range(first_y, math.ceil(visible_bottom) + tile_size, tile_size):
        for world_x in range(first_x, math.ceil(visible_right) + tile_size, tile_size):
            tile_rect = pygame.Rect(
                round(viewport.x + (world_x - visible_left) * zoom),
                round(viewport.y + (world_y - visible_top) * zoom),
                max(1, math.ceil(tile_size * zoom)),
                max(1, math.ceil(tile_size * zoom)),
            )
            biome = biome_at(
                pygame.Vector2(
                    world_x + tile_size / 2,
                    world_y + tile_size / 2,
                )
            )
            pygame.draw.rect(surface, BIOME_COLORS[biome], tile_rect)

    territory_layer = pygame.Surface(viewport.size, pygame.SRCALPHA)
    labeled_countries: set[int] = set()
    for territory in simulation.territories:
        screen_pos = pygame.Vector2(
            viewport.x + (territory.pos.x - visible_left) * zoom,
            viewport.y + (territory.pos.y - visible_top) * zoom,
        )
        clan_color = simulation.clan_colors[
            territory.clan_id % len(simulation.clan_colors)
        ]
        if territory.boundary and len(territory.boundary) >= 3:
            points = [
                (
                    round(viewport.x + (point.x - visible_left) * zoom),
                    round(viewport.y + (point.y - visible_top) * zoom),
                )
                for point in territory.boundary
            ]
            pygame.draw.polygon(territory_layer, (*clan_color, 34), points)
            pygame.draw.polygon(territory_layer, (*clan_color, 190), points, 1)
            if simulation.selected_territory() is territory:
                pygame.draw.polygon(
                    territory_layer, (255, 218, 73, 255), points, 2
                )
        else:
            center = (round(screen_pos.x), round(screen_pos.y))
            radius = max(1, round(territory.radius * zoom))
            pygame.draw.circle(territory_layer, (*clan_color, 34), center, radius)
            pygame.draw.circle(
                territory_layer, (*clan_color, 190), center, radius, 1
            )
            if simulation.selected_territory() is territory:
                pygame.draw.circle(
                    territory_layer,
                    (255, 218, 73, 255),
                    center,
                    radius + 1,
                    2,
                )
        if territory.home_level and -8 < screen_pos.x < viewport.width + 8 and (
            -8 < screen_pos.y < viewport.height + 8
        ):
            pygame.draw.rect(
                territory_layer,
                (119, 78, 55, 240),
                (round(screen_pos.x) - 2, round(screen_pos.y) - 2, 5, 5),
            )
        country = simulation.countries.get(territory.clan_id)
        if (
            country is not None
            and country.clan_id not in labeled_countries
            and viewport.collidepoint(round(screen_pos.x), round(screen_pos.y))
        ):
            pygame.draw.circle(
                territory_layer,
                (250, 250, 247, 235),
                (round(screen_pos.x), round(screen_pos.y)),
                3,
            )
            labeled_countries.add(country.clan_id)
    surface.blit(territory_layer, viewport.topleft)

    if simulation.land_editing and simulation.land_edit_points:
        edit_points = [
            (
                round(viewport.x + (point.x - visible_left) * zoom),
                round(viewport.y + (point.y - visible_top) * zoom),
            )
            for point in simulation.land_edit_points
        ]
        if len(edit_points) > 1:
            pygame.draw.lines(surface, (255, 220, 70), False, edit_points, 2)
        for point in edit_points:
            pygame.draw.circle(surface, (255, 220, 70), point, 3)

    for line in simulation.power_lines:
        start = (
            round(viewport.x + (line.start.x - visible_left) * zoom),
            round(viewport.y + (line.start.y - visible_top) * zoom),
        )
        end = (
            round(viewport.x + (line.end.x - visible_left) * zoom),
            round(viewport.y + (line.end.y - visible_top) * zoom),
        )
        pygame.draw.line(surface, (65, 65, 61), start, end, 1)

    for animal in simulation.wildlife:
        screen_pos = (
            round(viewport.x + (animal.pos.x - visible_left) * zoom),
            round(viewport.y + (animal.pos.y - visible_top) * zoom),
        )
        if viewport.collidepoint(screen_pos):
            color = (
                (155, 74, 63)
                if animal.is_predator
                else (83, 107, 69)
            )
            pygame.draw.circle(surface, color, screen_pos, 2)

    for human in simulation.humans:
        screen_pos = (
            round(viewport.x + (human.pos.x - visible_left) * zoom),
            round(viewport.y + (human.pos.y - visible_top) * zoom),
        )
        if viewport.collidepoint(screen_pos):
            color = (25, 27, 31) if human.is_president else human.color
            pygame.draw.circle(surface, color, screen_pos, 2)
            if human.person_id == simulation.selected_human_id:
                pygame.draw.circle(surface, GOLD, screen_pos, 4, 1)

    night = simulation.night_level()
    if night > 0.02:
        tint = pygame.Surface(viewport.size, pygame.SRCALPHA)
        tint.fill((*NIGHT_COLOR, round(95 * night)))
        surface.blit(tint, viewport.topleft)

    hour = int((simulation.world_time % DAY_LENGTH) / DAY_LENGTH * 24)
    minute = int(((simulation.world_time % DAY_LENGTH) / DAY_LENGTH * 24 % 1) * 60)
    time_label = font.render(
        f"{'NIGHT' if night > 0.55 else 'DAY'}  {hour:02d}:{minute:02d}  "
        f"ZOOM {zoom:.2f}×",
        True,
        WHITE,
    )
    time_bg = pygame.Surface((time_label.get_width() + 16, 30), pygame.SRCALPHA)
    time_bg.fill((25, 34, 49, 190))
    surface.blit(
        time_bg,
        (viewport.right - time_bg.get_width() - 12, viewport.top + 14),
    )
    surface.blit(
        time_label,
        (
            viewport.right - time_label.get_width() - 20,
            viewport.top + 20,
        ),
    )
    if simulation.message_timer > 0:
        message = font.render(simulation.message, True, INK)
        background = pygame.Surface(
            (message.get_width() + 24, 38), pygame.SRCALPHA
        )
        background.fill((255, 255, 255, 225))
        surface.blit(background, (viewport.x + 16, viewport.y + 14))
        surface.blit(message, (viewport.x + 28, viewport.y + 23))
    surface.set_clip(previous_clip)


def draw_human_world(
    surface: pygame.Surface,
    simulation: LifeSimulation,
    viewport: pygame.Rect,
    font: pygame.font.Font,
) -> None:
    if simulation.zoom < 0.35:
        _draw_human_world_overview(surface, simulation, viewport, font)
        return
    zoom = simulation.zoom
    if zoom == 1.0:
        _draw_human_world_unzoomed(surface, simulation, viewport, font)
        return
    internal_size = (
        max(1, round(viewport.width / zoom)),
        max(1, round(viewport.height / zoom)),
    )
    world_surface = pygame.Surface(internal_size)
    _draw_human_world_unzoomed(
        world_surface,
        simulation,
        pygame.Rect(0, 0, *internal_size),
        font,
    )
    scaled_world = pygame.transform.smoothscale(world_surface, viewport.size)
    surface.blit(scaled_world, viewport.topleft)


def draw_news_panel(
    surface: pygame.Surface,
    simulation: LifeSimulation,
    viewport: pygame.Rect,
    font: pygame.font.Font,
    small_font: pygame.font.Font,
) -> None:
    if not simulation.news_open:
        return
    panel_width = min(390, max(260, viewport.width - 30))
    panel = pygame.Rect(
        viewport.right - panel_width - 16,
        56,
        panel_width,
        min(470, viewport.height - 72),
    )
    pygame.draw.rect(surface, (248, 250, 252), panel, border_radius=10)
    pygame.draw.rect(surface, (81, 103, 126), panel, 2, border_radius=10)
    surface.blit(font.render("WORLD NEWS", True, INK), (panel.x + 16, panel.y + 13))
    surface.blit(
        small_font.render("N / mouse wheel · newest first", True, MUTED),
        (panel.x + 16, panel.y + 41),
    )
    news = list(reversed(simulation.news_items))
    visible = news[simulation.news_scroll:simulation.news_scroll + 10]
    clip = surface.get_clip()
    surface.set_clip(panel)
    y = panel.y + 70
    if not visible:
        surface.blit(small_font.render("Nothing newsworthy yet.", True, MUTED), (panel.x + 16, y))
    for item in visible:
        day = int(item.world_time // DAY_LENGTH) + 1
        category_color = {
            "Crime": RED,
            "Funeral": (89, 84, 105),
            "Community": GREEN,
        }.get(item.category, (77, 120, 166))
        category = small_font.render(f"Day {day} · {item.category}", True, category_color)
        surface.blit(category, (panel.x + 16, y))
        y += 19
        text = item.text
        max_width = panel.width - 32
        while text:
            split = len(text)
            while split > 1 and small_font.size(text[:split])[0] > max_width:
                split -= 1
            if split < len(text):
                last_space = text.rfind(" ", 0, split)
                if last_space > 0:
                    split = last_space
            surface.blit(
                small_font.render(text[:split], True, INK),
                (panel.x + 16, y),
            )
            text = text[split:].lstrip()
            y += 18
        y += 8
    surface.set_clip(clip)


def main() -> None:
    pygame.init()
    pygame.display.set_caption("Worm Life - a tiny artificial-life world")
    screen = pygame.display.set_mode(WINDOW_SIZE, pygame.RESIZABLE)
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 23)
    small_font = pygame.font.Font(None, 20)
    simulation = LifeSimulation()
    if SAVE_PATH.exists():
        simulation.load_game()
    fullscreen = False
    running = True

    while running:
        dt = min(clock.tick(60) / 1000, 0.05)
        panel_width = SIDEBAR_WIDTH if simulation.sidebar_open else 0
        bounds = pygame.Rect(0, 0, screen.get_width() - panel_width, screen.get_height())

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_F11:
                    fullscreen = not fullscreen
                    if fullscreen:
                        screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
                    else:
                        screen = pygame.display.set_mode(WINDOW_SIZE, pygame.RESIZABLE)
                elif event.key == pygame.K_ESCAPE and fullscreen:
                    fullscreen = False
                    screen = pygame.display.set_mode(WINDOW_SIZE, pygame.RESIZABLE)
                elif event.key == pygame.K_F5:
                    simulation.save_game()
                elif event.key == pygame.K_F9:
                    simulation.load_game()
                elif event.key == pygame.K_TAB:
                    simulation.sidebar_open = not simulation.sidebar_open
                elif event.key == pygame.K_m:
                    simulation.switch_mode()
                elif event.key == pygame.K_f and simulation.mode == "humans":
                    simulation.camera_follow = not simulation.camera_follow
                elif event.key == pygame.K_n and simulation.mode == "humans":
                    simulation.news_open = not simulation.news_open
                    simulation.news_scroll = 0
                elif event.key == pygame.K_ESCAPE and simulation.mode == "humans":
                    if simulation.land_editing:
                        simulation.land_editing = False
                        simulation.land_edit_points.clear()
                        simulation.message = "Precise land editing cancelled."
                        simulation.message_timer = 3
                    else:
                        simulation.selected_territory_index = None
                elif event.key == pygame.K_p and simulation.mode == "humans":
                    territory = simulation.selected_territory()
                    if territory is None:
                        simulation.message = "Select a plot before drawing a precise boundary."
                        simulation.message_timer = 3
                    elif simulation.land_editing:
                        simulation.land_editing = False
                        simulation.land_edit_points.clear()
                        simulation.message = "Precise land editing cancelled."
                        simulation.message_timer = 3
                    else:
                        simulation.land_editing = True
                        simulation.land_edit_points.clear()
                        simulation.camera_follow = False
                        simulation.message = (
                            "Click at least three boundary points inside the plot, then press Enter."
                        )
                        simulation.message_timer = 5
                elif event.key == pygame.K_g and simulation.mode == "humans":
                    simulation.expand_selected_territory()
                elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS) and simulation.mode == "humans":
                    simulation.shrink_selected_territory()
                elif event.key == pygame.K_j and simulation.mode == "humans":
                    simulation.join_selected_country()
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER) and simulation.land_editing:
                    simulation.finish_land_edit()
                elif event.key == pygame.K_BACKSPACE and simulation.land_editing:
                    if simulation.land_edit_points:
                        simulation.land_edit_points.pop()
                elif event.key == pygame.K_e:
                    if simulation.mode == "humans":
                        simulation.spawn_human()
                    else:
                        simulation.spawn_partner(bounds)
            elif event.type == pygame.MOUSEWHEEL and simulation.mode == "humans":
                mouse_position = pygame.mouse.get_pos()
                pointer_over_news = False
                if simulation.news_open:
                    news_panel_width = min(390, max(260, bounds.width - 30))
                    news_panel = pygame.Rect(
                        bounds.right - news_panel_width - 16,
                        56,
                        news_panel_width,
                        min(470, bounds.height - 72),
                    )
                    pointer_over_news = news_panel.collidepoint(mouse_position)
                if pointer_over_news:
                    simulation.news_scroll = max(
                        0,
                        min(
                            max(0, len(simulation.news_items) - 1),
                            simulation.news_scroll + event.y,
                        ),
                    )
                elif bounds.collidepoint(mouse_position):
                    simulation.zoom_at(mouse_position, bounds, event.y)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1 and simulation.sidebar_open and mode_button_rect(screen).collidepoint(event.pos):
                    simulation.switch_mode()
                elif (
                    event.button == 1
                    and simulation.mode == "humans"
                    and simulation.sidebar_open
                    and news_button_rect(screen).collidepoint(event.pos)
                ):
                    simulation.news_open = not simulation.news_open
                    simulation.news_scroll = 0
                elif (
                    event.button == 1
                    and simulation.mode == "worms"
                    and simulation.sidebar_open
                    and feed_button_rect(screen).collidepoint(event.pos)
                ):
                    simulation.feed_hungry_worms()
                elif (
                    event.button == 1
                    and simulation.mode == "humans"
                    and simulation.land_editing
                    and event.pos[0] < bounds.width
                ):
                    territory = simulation.selected_territory()
                    clicked_world = simulation.screen_to_world(event.pos, bounds)
                    if (
                        territory is not None
                        and territory_contains(territory, clicked_world)
                        and biome_at(clicked_world) != "ocean"
                    ):
                        simulation.land_edit_points.append(clicked_world)
                    else:
                        simulation.message = "Place parcel points on dry land inside the selected plot."
                        simulation.message_timer = 3
                elif (
                    event.button == 3
                    and simulation.mode == "humans"
                    and simulation.land_editing
                ):
                    if simulation.land_edit_points:
                        simulation.land_edit_points.pop()
                else:
                    in_world = event.pos[0] < bounds.width
                    if in_world and simulation.mode == "worms" and event.button == 1:
                        simulation.spawn_insect(pygame.Vector2(event.pos), bounds)
                    elif in_world and simulation.mode == "worms" and event.button == 3:
                        simulation.spawn_predator(pygame.Vector2(event.pos), bounds)
                    elif in_world and simulation.mode == "humans" and event.button == 1:
                        clicked_world = simulation.screen_to_world(event.pos, bounds)
                        closest, distance = nearest_human(clicked_world, simulation.humans)
                        if closest is not None and distance < 30 / simulation.zoom:
                            simulation.selected_human_id = closest.person_id
                            simulation.camera_follow = True
                            simulation.selected_territory_index = None
                        elif simulation.inspect_territory_at(clicked_world):
                            simulation.camera_follow = False
                        else:
                            simulation.spawn_wildlife(clicked_world, "deer")
                    elif in_world and simulation.mode == "humans" and event.button == 3:
                        clicked_world = simulation.screen_to_world(event.pos, bounds)
                        simulation.spawn_wildlife(clicked_world, "wolf")

        panel_width = SIDEBAR_WIDTH if simulation.sidebar_open else 0
        bounds = pygame.Rect(0, 0, screen.get_width() - panel_width, screen.get_height())
        if simulation.mode == "humans":
            keys = pygame.key.get_pressed()
            camera_direction = pygame.Vector2(
                float(keys[pygame.K_d] or keys[pygame.K_RIGHT])
                - float(keys[pygame.K_a] or keys[pygame.K_LEFT]),
                float(keys[pygame.K_s] or keys[pygame.K_DOWN])
                - float(keys[pygame.K_w] or keys[pygame.K_UP]),
            )
            if camera_direction.length_squared() > 0 and simulation.camera_follow:
                simulation.camera_follow = False
            if camera_direction.length_squared() > 0:
                simulation.camera += (
                    unit_vector(camera_direction) * 420 * dt / simulation.zoom
                )
            simulation.clamp_camera(bounds)
        simulation.update(dt, bounds)
        if simulation.mode == "humans":
            simulation.update_camera(bounds, dt)
        draw_world(screen, simulation, font)
        if simulation.mode == "humans":
            draw_news_panel(screen, simulation, bounds, font, small_font)
        if simulation.sidebar_open:
            draw_sidebar(screen, font, small_font, simulation)
        pygame.display.flip()

    if not simulation.save_blocked:
        simulation.save_game()
    pygame.quit()


if __name__ == "__main__":
    main()